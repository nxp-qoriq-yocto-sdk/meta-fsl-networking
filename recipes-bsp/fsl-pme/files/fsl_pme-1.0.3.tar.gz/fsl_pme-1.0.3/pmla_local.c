/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmla_local.c
 *
 * Description:
 *   This file implements the Pattern Matching Loader Agent API specifically 
 *   for the Simple Locally Managed reference implementation.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <generic_types.h>
#include <pmp.h>
#include <pmci.h>
#include <pmla.h>
#include <log.h>


/**********************************************************************
 * Private types
 **********************************************************************/

/* Loader Agent object */
typedef struct
{
    handle_t pmci_handle;
    PmlaTarget_t target;
    int allocated;
    int connected;
    int timeout;
    int keepalive;
} PmlaSlmObj_t;

/* Define a log level for API entry functions */
#define PMLA_INFO LOG_TEST
#define _PMLA_PREFIX "pmla"


/**********************************************************************
 * Global variabls
 **********************************************************************/

/**********************************************************************
 * Internal function Implementation
 **********************************************************************/

static inline int pmlaSlmStubout ( PmlaSlmObj_t *obj )
{
    return (obj->target.channel == -1);
}

/**********************************************************************
 * API Implementation
 **********************************************************************/

PmlaError_t pmlaOpen ( PmlaTarget_t *target, handle_t *handle )
{
    PmlaSlmObj_t *obj;
    
    /* In the case of TransGen, the target should either be NULL or 
     * representing some kind of file name or file descriptor.
     */
    
    if ( target == NULL )
    {
        /* Target not present */
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "No target specified");
        return pmlaInvalidTarget_c;
    }
    if ( handle == NULL )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Null handle specified");        
        return pmlaNoBufferProvided_c;
    }
   
    /* Initialize the handle to null */
    *handle = HANDLE_NULL;

    /* Allocating a Loader Agent handle */
    obj = (PmlaSlmObj_t *)malloc(sizeof(PmlaSlmObj_t));
    if(obj == NULL) return pmlaOutOfMemory_c;

    obj->pmci_handle = HANDLE_NULL;
    obj->target = *target;
    obj->allocated = 1;
    obj->connected = 0;
    obj->timeout = PMCI_INFINITE;
    obj->keepalive = 0;
    /* Return the handle as an integer */
    *handle = (handle_t)obj;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, 
               "pmlaHandle  = %"PRI_HANDLE, *handle);

    return pmlaSuccess_c;
}

PmlaError_t pmlaSetOption ( handle_t pmlaHandle,
                    int optionId,
                    void *option,
                    int optionSize )
{
    PmlaSlmObj_t *obj;
    
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);
    
    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }
    
    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Sanitize the optionId */
    if ( (optionId < 0) || (optionId >= pmlaMaxOptions_c) )
    {
        return pmlaInvalidOptionCode_c;
    }
    if ( option == NULL )
    {
        return pmlaInvalidOptionValue_c;
    }
    
    /* Process the option */
    if ( optionId == pmlaOptionTimeout_c )
    {
        if ( optionSize != sizeof(int) )
        {
            return pmlaInvalidOptionSize_c;
        }
        obj->timeout = *(int *)option;
        if (obj->connected && obj->pmci_handle != HANDLE_NULL)
        {
            if(pmci_set_option(obj->pmci_handle, pmci_option_timeout_e, option, optionSize) !=
                    pmci_success_e)
            {
                return pmlaUnavailableOption_c;
            }
        }
    }
    if ( optionId == pmlaOptionKeepAlive_c )
    {
        if ( optionSize != sizeof(int) )
        {
            return pmlaInvalidOptionSize_c;
        }
        obj->keepalive = *(int *)option;
    }

    return pmlaSuccess_c;
}


PmlaError_t pmlaGetOption ( handle_t pmlaHandle,
                            int optionId,
                            void *option,
                            int *optionSize )
{
    PmlaSlmObj_t *obj;
    
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }
    
    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Sanitize the optionId */
    if ( (optionId < 0) || (optionId >= pmlaMaxOptions_c) )
    {
        return pmlaInvalidOptionCode_c;
    }
    if ( option == NULL || optionSize == NULL)
    {
        return pmlaInvalidOptionValue_c;
    }
    
    if ( optionId == pmlaOptionTimeout_c )
    {
        *(int*) option = obj->timeout;
        *optionSize = sizeof(int);
    }
    if ( optionId == pmlaOptionKeepAlive_c )
    {
        *(int*) option = obj->keepalive;
        *optionSize = sizeof(int);
    }

    return pmlaSuccess_c;
}

PmlaError_t pmlaClose ( handle_t pmlaHandle )
{
    PmlaSlmObj_t *obj;
    
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        return pmlaInvalidHandle_c;
    }

    if(obj->connected) pmlaDisconnect(pmlaHandle);

    /* Destroying the handle */
    memset(obj, 0, sizeof(PmlaSlmObj_t));

    free(obj);
    return pmlaSuccess_c;
}

PmlaError_t pmlaConnect ( handle_t pmlaHandle )
{
    PmlaSlmObj_t *obj;
    handle_t pmci_handle;
    
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        return pmlaInvalidHandle_c;
    }
    
    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    if(obj->connected) return pmlaAlreadyConnected_c;

    if(pmci_open(obj->target.channel, &pmci_handle) != pmci_success_e)
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmci_open failed");
        return pmlaConnectFailure_c;
    }
    
    obj->pmci_handle = pmci_handle;
    obj->connected = 1;

    if(pmci_set_option(pmci_handle, pmci_option_timeout_e, 
       &(obj->timeout), sizeof(obj->timeout)) != pmci_success_e)
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmci_open failed");
        return pmlaConnectFailure_c;        
    }
    return pmlaSuccess_c;
}

PmlaError_t pmlaDisconnect ( handle_t pmlaHandle )
{
    PmlaSlmObj_t *obj;
    
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        return pmlaInvalidHandle_c;
    }
    
    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    if(!obj->connected || obj->pmci_handle == HANDLE_NULL) return pmlaNotConnected_c;
   
    if(pmci_close(obj->pmci_handle) != pmci_success_e) return pmlaLostConnectivity_c;
    
    obj->pmci_handle = HANDLE_NULL;
    obj->connected = 0;
    return pmlaSuccess_c;
}

PmlaError_t pmlaSendBulkBegin ( handle_t pmlaHandle )
{
    PmlaSlmObj_t *obj;    
    /* No need to do bulk in local PMLA */
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);
    
    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        return pmlaInvalidHandle_c;
    }

    return pmlaSuccess_c;
}

PmlaError_t pmlaSendBulkEnd ( handle_t pmlaHandle )
{
    PmlaSlmObj_t *obj;    
    /* No need to do bulk in local PMLA */
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);
    
    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        return pmlaInvalidHandle_c;
    }

    return pmlaSuccess_c;
}

PmlaError_t pmlaSend ( handle_t pmlaHandle,
                       pmp_msg_t *cmd )
{
    PmlaSlmObj_t *obj;
    uint32_t cmdSize;
    pmci_error_t result;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE", cmd=%p, ",
               pmlaHandle, cmd);

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    
    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Ensure we're connected in order to send anything */
    if ( !obj->connected || obj->pmci_handle == HANDLE_NULL )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is not "
                   "connected", pmlaHandle);
        return pmlaNotConnected_c;
    }

    /* Sanitize the command */
    if ( cmd == NULL )
    {
        return pmlaNoBufferProvided_c;
    }

    if ( cmd->header.protocolVersion != PMP_CURRENT_VERSION )
    {
        return pmlaInvalidCommand_c;
    }
    cmdSize = ntohl(cmd->header.msgLength);

    /* Sanitize the command size */
    if ( cmdSize > PMLA_MAX_MSG_SIZE )
    {
        return pmlaBufferSizeError_c;
    }

    /* Send the command to target */
    result = pmci_write( obj->pmci_handle, cmd, cmdSize);
    if ( result != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "ERROR=%d:%s", 
                   result, pmci_error_string(result));
        return pmlaLostConnectivity_c;
    }

    return pmlaSuccess_c;
}

PmlaError_t pmlaRecv ( handle_t pmlaHandle,
                       pmp_msg_t *notif )
{
    PmlaSlmObj_t *obj;
    pmci_error_t result;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE", notif=%p",
               pmlaHandle, notif);

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    if ( obj == NULL || !obj->allocated )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    
    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Ensure we're connected in order to receive anything */
    if ( !obj->connected || obj->pmci_handle == HANDLE_NULL )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is not "
                   "connected", pmlaHandle);
        return pmlaNotConnected_c;
    }

    /* Sanitize the result notification buffer */
    if ( notif == NULL )
    {
        return pmlaNoBufferProvided_c;
    }
    
    result = pmci_read(obj->pmci_handle, notif);
    if ( result == pmci_empty_read_e )
    {
        return pmlaTimedOut_c;
    }
    if ( result != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "ERROR=%d:%s", 
                   result, pmci_error_string(result));
        return pmlaLostConnectivity_c;
    }

    return pmlaSuccess_c;
}

PmlaError_t pmlaFlush ( handle_t pmlaHandle )
{
    PmlaSlmObj_t *obj;
    pmci_error_t result;

    /* Sanitize the handle */
    obj = (PmlaSlmObj_t *)pmlaHandle;
    
    if ( obj == NULL || !obj->allocated)
    {
        return pmlaInvalidHandle_c;
    }

    if ( pmlaSlmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    if ( !obj->connected || obj->pmci_handle == HANDLE_NULL )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is not "
                   "connected", pmlaHandle);
        return pmlaNotConnected_c;
    }

    result = pmci_flush(obj->pmci_handle);
    if ( result != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "ERROR=%d:%s", 
                   result, pmci_error_string(result));
        return pmlaLostConnectivity_c;
    }
    
    return pmlaSuccess_c;
}

