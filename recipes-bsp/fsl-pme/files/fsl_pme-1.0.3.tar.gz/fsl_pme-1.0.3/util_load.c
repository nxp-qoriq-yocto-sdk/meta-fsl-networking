/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"
#include <driver.h>

static int usage(int verbose, int retval)
{
	fprintf(stderr, "%sload <channel-num> [-nb] [option=value] ...\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose) {
		fprintf(stderr, "%s    -nb won't wait for device-creation\n",
				USAGE_CLEAR);
		fprintf(stderr, "%s    context_table=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    residue_table=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s        If non-zero, contexts/residues are "
				"table-based\n", USAGE_CLEAR);
		fprintf(stderr, "%s    residue_size=[32|64|96|128]\n",
				USAGE_CLEAR);
		fprintf(stderr, "%s    fifo_reduced    (use 64-byte commands)\n",
				USAGE_CLEAR);
		fprintf(stderr, "%s    cmd_fifo=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    not_fifo=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fb_fifo=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s        Sets FIFO sizes\n", USAGE_CLEAR);
		fprintf(stderr, "%s    cmd_trigger=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    not_trigger=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s        Sets stats triggers\n", USAGE_CLEAR);
		fprintf(stderr, "%s    limit_deflate_blks=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    limit_report_blks=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbA_starve=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbA_low=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbA_high=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbA_max=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbA_delta=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s        Sets freebuffer parameters for "
				"virtual freelist A\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbB_starve=<num>\n", USAGE_CLEAR);
		fprintf(stderr, "%s    fbB_[...]\n", USAGE_CLEAR);
		fprintf(stderr, "%s        Sets freebuffer parameters for "
				"virtual freelist B\n", USAGE_CLEAR);
	}
	return retval;
}

static int __parse_param16(const char *s, const char *name, uint16_t *val,
				int *fail)
{
	/* NB: this fn isn't reusable *as is* because, for our purposes, we
	 * deliberately fail if the user specifies zero. */
	unsigned int __val;
	if(strncmp(s, name, strlen(name)))
		return -1;
	if(s[strlen(name)] != '=')
		return -1;
	if(parse_uint(s + (strlen(name) + 1), &__val, name) ||
				!__val || (__val > 0xffff)) {
		*fail = 1;
		usage(0, -1);
	} else
		*val = (uint16_t)__val;
	return 0;
}
static int __parse_param32(const char *s, const char *name, uint32_t *val,
				int *fail)
{
	if(strncmp(s, name, strlen(name)))
		return -1;
	if(s[strlen(name)] != '=')
		return -1;
	if(parse_uint(s + (strlen(name) + 1), val, name)) {
		*fail = 1;
		usage(0, -1);
	}
	return 0;
}
#define parse_param16(a,b) __parse_param16(*argv,a,b,&failed)
#define parse_param32(a,b) __parse_param32(*argv,a,b,&failed)
static int __parse_param8(const char *s, const char *name, uint8_t *val,
				int *fail)
{
	if(strncmp(s, name, strlen(name)))
		return -1;
	if(s[strlen(name)] != '=')
		return -1;
	if(parse_uchar(s + (strlen(name) + 1), val, name)) {
		*fail = 1;
		usage(0, -1);
	}
	return 0;
}
#define parse_param8(a,b) __parse_param8(*argv,a,b,&failed)

static int __parse_fb(const char *s, struct __pme_ctrl_load_fb *fb,
			int *fail)
{
	int ret = 0, failed = 0;
	const char **argv = &s;
	if(!parse_param32("starve", &fb->starve)) ;
	else if(!parse_param32("low", &fb->low)) ;
	else if(!parse_param32("high", &fb->high)) ;
	else if(!parse_param32("max", &fb->max)) ;
	else if(!parse_param32("delta", &fb->delta)) ;
	else {
		failed = 1;
		usage(1, -1);
		ret = -1;
	}
	if(failed) *fail = 1;
	return ret;
}
#define parse_fb(a) __parse_fb(*argv + 4,a,&failed)

#define DEFAULT_CONTEXT_TABLE	0
#define DEFAULT_RESIDUE_TABLE	0
#define DEFAULT_RESIDUE_SIZE	128
#define DEFAULT_FIFO_REDUCED	0
#define DEFAULT_CMD_FIFO	32
#define DEFAULT_NOT_FIFO	32
#define DEFAULT_FB_FIFO		16
#define DEFAULT_CMD_TRIGGER	64
#define DEFAULT_NOT_TRIGGER	0
#define DEFAULT_LIMIT_DEFLATE	0xffff
#define DEFAULT_LIMIT_REPORT	0xffff
#define DEFAULT_FB_STARVE	0
#define DEFAULT_FB_LOW		0
#define DEFAULT_FB_HIGH		0
#define DEFAULT_FB_MAX		0
#define DEFAULT_FB_DELTA	0

#define DEFAULT_BLOCKING_MAX	10	/* seconds */

int cload(int argc, char *argv[])
{
	int fd, blocking = 1, blocking_timeout = DEFAULT_BLOCKING_MAX;
	struct pme_ctrl_load l = {
		.context_table = DEFAULT_CONTEXT_TABLE,
		.residue_table = DEFAULT_RESIDUE_TABLE,
		.residue_size = DEFAULT_RESIDUE_SIZE,
		.fifo_reduced = DEFAULT_FIFO_REDUCED,
		.cmd_fifo = DEFAULT_CMD_FIFO,
		.not_fifo = DEFAULT_NOT_FIFO,
		.fb_fifo = DEFAULT_FB_FIFO,
		.cmd_trigger = DEFAULT_CMD_TRIGGER,
		.not_trigger = DEFAULT_NOT_TRIGGER,
		.limit_deflate_blks = DEFAULT_LIMIT_DEFLATE,
		.limit_report_blks = DEFAULT_LIMIT_REPORT,
		.fb = {
			{
				.starve = DEFAULT_FB_STARVE,
				.low = DEFAULT_FB_LOW,
				.high = DEFAULT_FB_HIGH,
				.max = DEFAULT_FB_MAX,
				.delta = DEFAULT_FB_DELTA
			},
			{
				.starve = DEFAULT_FB_STARVE,
				.low = DEFAULT_FB_LOW,
				.high = DEFAULT_FB_HIGH,
				.max = DEFAULT_FB_MAX,
				.delta = DEFAULT_FB_DELTA
			}
		}
	};
#define ARGINC	{argc--;argv++;}

	if(argc < 1) return usage(1, 0);
	ARGINC;
	if(!argc) return usage(1, -1);
	if(parse_uchar(*argv, &l.channel, "<channel-num>"))
		return usage(1, -1);
	ARGINC;
	if(argc && !strcmp(*argv, "-nb")) {
		blocking = 0;
		ARGINC;
	}
	while(argc) {
		int failed = 0;
		if(!parse_param32("context_table", &l.context_table)) ;
		else if(!parse_param32("residue_table", &l.residue_table)) ;
		else if(!parse_param8("residue_size", &l.residue_size)) ;
		else if(!strcmp(*argv, "fifo_reduced")) l.fifo_reduced = 1;
		else if(!parse_param32("cmd_fifo", &l.cmd_fifo)) ;
		else if(!parse_param32("not_fifo", &l.not_fifo)) ;
		else if(!parse_param32("fb_fifo", &l.fb_fifo)) ;
		else if(!parse_param32("cmd_trigger", &l.cmd_trigger)) ;
		else if(!parse_param32("not_trigger", &l.not_trigger)) ;
		else if(!parse_param16("limit_deflate_blks", &l.limit_deflate_blks)) ;
		else if(!parse_param16("limit_report_blks", &l.limit_report_blks)) ;
		else if(!strncmp(*argv, "fbA_", 4) &&
				!parse_fb(&l.fb[0])) ;
		else if(!strncmp(*argv, "fbB_", 4) &&
				!parse_fb(&l.fb[1])) ;
		else
			failed = 1;
		if(failed)
			return usage(1, -1);
		ARGINC;
	}
	fd = open(PME_CTRL_PATH, O_RDONLY);
	if(fd < 0) {
		perror("opening control device failed");
		return -1;
	}
	if(ioctl(fd, PME_CTRL_IOCTL_LOAD, &l)) {
		perror("PME_CTRL_LOAD failed");
		return -1;
	}
	close(fd);
	if(blocking) {
		char cpath[32];
		struct stat devstat;
		sprintf(cpath, PME_CHANNEL_PATH, l.channel);
		while(blocking_timeout-- && (stat(cpath, &devstat) < 0))
			sleep(1);
		if(!blocking_timeout) {
			fprintf(stderr, "ERROR, timeout waiting for creation "
					"of '%s'\n", cpath);
			return -1;
		}
		printf("channel device created: %s\n", cpath);
	}
	return 0;
}
