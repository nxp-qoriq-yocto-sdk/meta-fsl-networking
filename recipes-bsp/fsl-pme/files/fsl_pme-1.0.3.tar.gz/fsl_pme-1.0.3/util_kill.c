/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"
#include "driver.h"

static int usage(int verbose, int retval)
{
	fprintf(stderr, "%skill <channel-num> [-b]\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose) {
		fprintf(stderr, "%s    -b               (blocks until channel "
			"is clean)\n", USAGE_CLEAR);
	}
	return retval;
}

static int bad_param(const char *s, const char *arg)
{
	fprintf(stderr, "ERROR, bad parameter for %s (%s)\n", s, arg);
	return usage(1, -1);
}

int ckill(int argc, char *argv[])
{
	int fd, err;
	struct pme_ctrl_channel params = {
		.channel = 0,
		.cmd = CHANNEL_KILL,
		.block = 0
	};
#define ARGINC	{argc--;argv++;}

	if(argc < 2) return usage(1, 0);
	ARGINC;
	if(parse_uchar(*argv, &params.channel, "<channel-num>"))
		return bad_param("<channel-num>", *argv);
	ARGINC;
	while(argc) {
		if(!strcmp(*argv, "-h") || !strcmp(*argv, "-?") ||
				!strcmp(*argv, "--help"))
			return usage(1, 0);
		if(!strcmp(*argv, "-b"))
			params.block = 1;
		else
			return usage(1, -1);
		ARGINC;
	}
	fd = open(PME_CTRL_PATH, O_RDONLY);
	if(fd < 0) {
		perror("opening channel failed");
		return -1;
	}
 	if((err = ioctl(fd, PME_CTRL_IOCTL_CHANNEL, &params))) {
		perror("PM_CTRL_IOCTL_CHANNEL failed");
		return -1;
	}
	return 0;
}
