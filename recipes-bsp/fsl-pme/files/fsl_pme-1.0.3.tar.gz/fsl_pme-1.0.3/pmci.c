/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmci.c
 *
 * Description:
 *   This file holds the Pattern Matching Control Interface API implementation
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmci.h>
#include <pm_defs.h>
#include <pmp.h>
#include <pmsm.h>
#include <log.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <driver.h>

/**********************************************************************
 * Macros
 **********************************************************************/

/* Magic number */
#define PMCI_MAGIC_VALUE 0x33636907

/* This macro determines if the build should actually make the calls to the
 * PM driver.  Calls to the PM driver code is compiled anyways.  However, 
 * when not compiling on the target, a return statement is specified thus
 * preventing the call to the PM driver.  When this macro is defined, it
 * assumes it can call the PM driver (the driver is installed).  When
 * undefined, the PMCI module simply stub out all PM driver requests by
 * echoing any requests back to the originator.
 */
#define PMCI_RUNNING_ON_TARGET

/* Commands that can't be interpreted by hardware are software commands that
 * requires particular interpretation.  Sometimes, these commands translates
 * into different hardware commands.  This macro enables the decode of these
 * hardware commands.
 */
/*#define PMCI_DECODE_HW_FROM_SW_CMD*/

/* Maximum buffer size to use when proxying */
#define PMCI_PROXY_MAX_LENGTH 65536
#define PMCI_MEM_adjustment 32
#define PMCI_MAX_MSG_SIZE 0x00ffffff
#define PMCI_CMD_SCHED_INCR 256
#define PMCI_CMD_SCHED_MEM  (sizeof(pmci_cmd_sched_t)*PMCI_CMD_SCHED_INCR)

/* Module prefix to use when invoking the logging facility */
#define _PMCI_PREFIX "pmci"

/* Macro that specifies the biggest memory dump we are willing to get */
#define _PMCI_MEM_dump_max 512

/* This macro defines the number of rule context bits that can be
 * defined in a digest session context entry. */
#define pmp_rule_num_in_session_context_entry         256

/* Defines a constant describing an unknown error code */
#define PMCI_UNKNOWN_ERROR_CODE (pmci_error_first_e - 1)

/* Defines the path to get to dma module parameters */
#define PMCI_PARAM_DXE_SRE_TABLE_SIZE   "dxe_sre_table_size"
#define PMCI_PARAM_SRE_SESSION_CTX_NUM  "sre_session_ctx_num"
#define PMCI_PARAM_SRE_SESSION_CTX_SIZE "sre_session_ctx_size"
#define PMCI_PARAM_SRE_NUM_RULES        "sre_rule_num"
static FILE *PMCI_PARAM_FILE(const char *n)
{
	char buf[256];
#ifdef PLATFORM_8572_ds_git
	static char *moddef = "fsl_pme_8572";
#else
	static char *moddef = "pme_base";
#endif
	char *modname = getenv("FSL_PM_MODNAME");
	if(!modname)
		modname = moddef;
	sprintf(buf, "/sys/module/%s/parameters/%s", modname, n);
	return fopen(buf, "r");
}

/* Define the batch buffer parameters */
#define PMCI_BATCH_BUFFER_GLOW_DELTA (16*1024)


/**********************************************************************
 * Types
 **********************************************************************/

/* The proxy is used to relay information from write to read path */
typedef union
{
    struct
    {
        int producer;
        int consumer;
    };
    int pair[2];
} pmci_proxy_t;

/* Scheduling of commands */
typedef struct
{
    void *cmdPtr;
    int   cmdLen;
    bool  cmdHw;
} pmci_cmd_sched_t;

/* Handle information */
typedef struct
{
    uint32_t magic;
    pid_t pid;
    handle_t handle;
    int pmd;
    int channel;
    int scan;
    int stats;
    pmci_proxy_t proxy;
    pmci_cmd_sched_t *sched;
    int schedSize;
    int schedNum;
    int timeout;
    uint32_t exclusive;
    uint32_t batch;

    uint8_t *batch_buffer_p;
    uint32_t batch_buffer_len;
    uint32_t batch_data_len;
    uint32_t batch_buffer_threshold;
    
    /* Cached value of various configurable attributes */
    uint32_t extensionBlockNum;
    bool     extensionBlockNumValid;
    uint32_t contextMaxNum;
    bool     contextMaxNumValid;
    uint32_t contextAreaSize;
    bool     contextAreaSizeValid;
    uint32_t maxRuleNum;
    bool     maxRuleNumValid;
} pmci_obj_t;

typedef struct
{
    pmci_error_t code;
    char *string;
} pmci_error_string_t;

/**********************************************************************
 * Private declaration
 **********************************************************************/
static int  _pmci_openRetry(const char* dev_name, int flags);

static pmci_obj_t *_pmci_get_object(handle_t pmci_handle);
static void _pmci_assign_handle(pmci_obj_t *pmci);
static void _pmci_release_handle(pmci_obj_t *pmci);
static int  _pmci_is_valid(pmci_obj_t *pmci, handle_t handle);
static void _pmci_report_error(pmci_obj_t *pmci, int errorNo, char *msg);

static int  _pmci_create_control_handle(void);
static int  _pmci_create_scan_handle(void);
static int  _pmci_create_stats_handle(void);
static int  _pmci_create_proxy_handles(pmci_proxy_t *proxy);

static int  _pmci_destroy_control_handle(int pmd);
static int  _pmci_destroy_scan_handle(int scan);
static int  _pmci_destroy_stats_handle(int stats);
static int  _pmci_destroy_proxy_handles(pmci_proxy_t *proxy);

static int  _pmci_set_channel(int pmd, int channelId);
static int  _pmci_writeSchedule(pmci_obj_t *pmci, void *cmds, int cmdsSize);
static pmci_error_t _pmci_writeExecute(pmci_obj_t *pmci);
static int  _pmci_write(pmci_obj_t *pmci, pmp_header_t *header, int length);
static int  _pmci_writeReadMasquerade(pmci_obj_t *pmci, pmp_header_t *header);
#ifdef PMCI_RUNNING_ON_TARGET
static int  _pmci_readReadMasquerade(pmci_obj_t *pmci, pmp_msg_t *notif);
#endif /* PMCI_RUNNING_ON_TARGET */
static int  _pmci_reset_all_table(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_ioctl(int dma, int cmd, struct pme_ctrl_opts *opts);
static int  _pmci_get_config_attr(pmci_obj_t *pmci, uint32_t attrId, uint32_t *valuePtr);
static int  _pmci_get_attribute(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_set_attribute(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_clear_context_by_rule_id(pmci_obj_t *pmci,
                                      pmp_ctx_by_rule_id_clear_request_msg_t *req);
static int  _pmci_clear_all_context(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_set_exclusivity(pmci_obj_t *pmci, bool exclusiveState);
static int  _pmci_scan_data(pmci_obj_t *pmci, pmp_data_scan_request_msg_t *cmd);
static int  _pmci_get_hw_revision(pmp_hw_revision_t *rev);
static int  _pmci_get_protocol_revision(pmp_protocol_revision_t *rev);
static int  _pmci_get_statistics(pmci_obj_t *pmci, pmp_statistics_attr_t *stats);
static int  _pmci_reset_statistics(pmci_obj_t *pmci);
static int  _pmci_batch_buffer_add(pmci_obj_t *pmci, void* data, uint32_t length);
static uint32_t _pmci_decode_batch_attr_cmd(void* cmd, bool* batch_cmd, uint32_t* batch_attr);

static void _pmci_dump_object(pmci_obj_t *pmci, log_log_Level_t level);
static void _pmci_dump_data(log_log_Level_t level, void *data, int length);
static void _pmci_decode_msg(log_log_Level_t level, pmp_header_t *header);
#ifdef PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES
static void _pmci_decode_all_msg(log_log_Level_t level, pmp_header_t *header, 
                              int length);
#endif /* PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES */

int _pmci_max_index_get(pmci_obj_t *pmci, pmp_table_id_t tableId);
int _pmci_record_size_get(pmp_table_id_t tableId);

/**********************************************************************
 * Global variables
 **********************************************************************/

static pmci_error_string_t _pmci_error_strings[] = {
    { pmci_success_e            , "The operation completed with success" },
    { pmci_failure_e            , "The operation fail to complete" },
    { pmci_out_of_memory_e        , "Can't allocate memory" },
    { pmci_invalid_handle_e      , "Invalid PMCI handle specified" },
    { pmci_unavailable_option_e  , "The option is not implemented" },
    { pmci_unavailable_driver_e  , "The PM driver is unavailable" },
    { pmci_invalid_option_code_e  , "Invalid option code specified"},
    { pmci_invalid_option_value_e , "Invalid option value specified" },
    { pmci_invalid_option_size_e  , "Invalid option size specified" },
    { pmci_not_yet_implemented_e  , "Operation not yet implemented" },
    { pmci_invalid_parameters_e  , "One or more parameters are invalid" },
    { pmci_invalid_attribute_id_e , "Invalid attribute ID to get/set" },
    { pmci_invalid_attribute_val_e, "Invalid attribute value" },
    { pmci_invalid_attribute_len_e, "Invalid attribute length" },
    { pmci_lost_driver_e         , "Occurs when the driver locked out" },
    { pmci_unrecoverable_error_e , "Unrecoverable error" },
    { pmci_invalid_channel_e     , "Invalid channel number specified" },
    { pmci_empty_read_e          , "Read operation return empty buffer" },
    { PMCI_UNKNOWN_ERROR_CODE  , "Unknown error code" }
};

/**********************************************************************
 * Implementation
 **********************************************************************/

pmci_error_t pmci_open(int channel, handle_t *handle)
{
    pmci_obj_t *pmci;   /* Holds the control interface data */
    int pmd;           /* PM driver handle */
    int scan;          /* Handle used for scanning data */
    int stats;         /* Handle used for querying statistics */
    pmci_proxy_t proxy; /* Handles to the proxy streams */
    
    if ( handle == NULL )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL pointer");
        return pmci_invalid_parameters_e;
    }

    /* Initialize the handler pointer */
    *handle = HANDLE_NULL;

    /* Allocate memory for our object */
    pmci = (pmci_obj_t *)malloc(sizeof(pmci_obj_t));
    if ( pmci == NULL )
    {
        /* pmci_out_of_memory_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Out-of-memory for object");
        return pmci_out_of_memory_e;
    }

    /* Allocate memory for the command scheduling buffer */
    pmci->sched = (pmci_cmd_sched_t *)malloc(PMCI_CMD_SCHED_MEM);
    if ( pmci->sched == NULL )
    {
        /* pmci_out_of_memory_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Out-of-memory for buffer");
        free(pmci);
        return pmci_out_of_memory_e;
    }
    pmci->schedSize = PMCI_CMD_SCHED_INCR;
    pmci->schedNum = 0;

    /* Create the PM driver handle */
    pmd = _pmci_create_control_handle();
    if ( pmd < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Driver unavailable");
        free(pmci->sched);
        free(pmci);
        return pmci_unavailable_driver_e;
    }

    /* Create the handle used for scanning data */
    scan = _pmci_create_scan_handle();
    if ( scan < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Scan unavailable");
        _pmci_destroy_control_handle(pmd);
        free(pmci->sched);
        free(pmci);
        return pmci_unavailable_driver_e;
    }

    /* Create the handle used for querying statistics */
    stats = _pmci_create_stats_handle();
    if ( stats < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Stats unavailable");
        _pmci_destroy_scan_handle(scan);
        _pmci_destroy_control_handle(pmd);
        free(pmci->sched);
        free(pmci);
        return pmci_unavailable_driver_e;
    }

    /* Create the proxy handles */
    if ( _pmci_create_proxy_handles(&proxy) < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Proxy unavailable");
        _pmci_destroy_stats_handle(stats);
        _pmci_destroy_scan_handle(scan);
        _pmci_destroy_control_handle(pmd);
        free(pmci->sched);
        free(pmci);
        return pmci_out_of_memory_e;
    }

    /* Fill in the handle */
    pmci->magic = PMCI_MAGIC_VALUE;
    pmci->pid = getpid();
    _pmci_assign_handle(pmci);
    pmci->pmd = pmd;
    pmci->channel = channel;
    pmci->scan = scan;
    pmci->stats = stats;
    pmci->proxy = proxy;
    pmci->timeout = PMCI_INFINITE;
    pmci->exclusive = 0;
    pmci->batch = 0;
    pmci->batch_buffer_p = NULL;
    pmci->batch_buffer_len = 0;
    pmci->batch_data_len = 0;
    pmci->batch_buffer_threshold = PMCI_BATCH_BUFFER_THRESHOLD_DEFAULT;
    /* Clean up the cache */
    pmci->extensionBlockNumValid = 0;
    pmci->contextMaxNumValid = 0;
    pmci->contextAreaSizeValid = 0;
    pmci->maxRuleNumValid = 0;

    /* Dump the object */
    LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
               "pmci_handle  = %"PRI_HANDLE, (handle_t)pmci);
    _pmci_dump_object(pmci, LOG_TEST);

    /* Set the channel */
    if ( _pmci_set_channel(pmci->pmd, channel) < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't set PMD channel %d",
                   channel);
        _pmci_destroy_stats_handle(stats);
        _pmci_destroy_scan_handle(scan);
        _pmci_destroy_control_handle(pmd);
        _pmci_destroy_proxy_handles(&proxy);
        free(pmci->sched);
        free(pmci);
        return pmci_invalid_channel_e;
    }
    if ( _pmci_set_channel(pmci->scan, channel) < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't set scan channel %d",
                   channel);
        _pmci_destroy_stats_handle(stats);
        _pmci_destroy_scan_handle(scan);
        _pmci_destroy_control_handle(pmd);
        _pmci_destroy_proxy_handles(&proxy);
        free(pmci->sched);
        free(pmci);
        return pmci_invalid_channel_e;
    }
    
    /* Succeeded */
    *handle = (handle_t)pmci;
    return pmci_success_e;
}

pmci_error_t pmci_set_option(handle_t pmci_handle, pmci_option_id_t optionId, 
                             void *option, int optionSize)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
               "pmci_handle=%"PRI_HANDLE", optionId=%d, option=%p, "
               "optionSize=%d", pmci_handle, optionId, option, optionSize);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmci_handle);
        return pmci_invalid_handle_e;
    }
    
    /* Sanitize the optionId */
    if ( optionId >= pmci_num_options_e )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Invalid option code");
        return pmci_invalid_option_code_e;
    }

    /* Process the option */
    if ( optionId == pmci_option_timeout_e )
    {
        if ( option == NULL || *(int *)option < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Bad option value");
            return pmci_invalid_parameters_e;
        }

        /* Setting the timeout value for pmci_read() */
        if ( optionSize != sizeof(int) )
        {
            return pmci_invalid_option_size_e;
        }
        
        pmci->timeout = *(int *)option;
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Timeout set to %d", pmci->timeout);
        return pmci_success_e;
    }
    else if ( optionId == pmci_option_batch_buffer_threshold_e )
    {
        if ( option == NULL || *(uint32_t *)option < PMCI_BATCH_BUFFER_THRESHOLD_MIN )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Bad option value");
            return pmci_invalid_parameters_e;
        }
        
        /* Setting the batch buffer threshold value */
        if ( optionSize != sizeof(uint32_t) )
        {
            return pmci_invalid_option_size_e;
        }
        pmci->batch_buffer_threshold = *(uint32_t *) option;
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch buffer threshold set to %"PRIu32,
                   pmci->batch_buffer_threshold);
        return pmci_success_e;
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Unavailable option code");
    return pmci_unavailable_option_e;
}

pmci_error_t pmci_get_option(handle_t pmci_handle, pmci_option_id_t optionId, 
                          void *option, int *optionSize)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
               "pmci_handle=%"PRI_HANDLE", optionId=%d", pmci_handle, optionId);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }

    /* Sanitize the optionId */
    if ( optionId >= pmci_num_options_e )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Invalid option code");
        return pmci_invalid_option_code_e;
    }

    /* Process the option */
    if ( optionId == pmci_option_timeout_e )
    {
        if ( option == NULL || optionSize == NULL )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL option pointer");
            return pmci_invalid_parameters_e;
        }
        /* Getting the timeout value associated to pmci_read() */
        if ( *optionSize < (int)sizeof(int) )
        {
            return pmci_invalid_option_size_e;
        }
        
        *(int *)option = pmci->timeout;
        *optionSize = sizeof(int);
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "timeout=%d", pmci->timeout);
        return pmci_success_e;
    } 
    else if ( optionId == pmci_option_batch_buffer_threshold_e )
    {
        if ( option == NULL || optionSize == NULL )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL option pointer");
            return pmci_invalid_parameters_e;
        }
        /* Getting the batch buffer threshold. */
        if ( *optionSize < (int)sizeof(uint32_t) )
        {
            return pmci_invalid_option_size_e;
        }
        *(uint32_t *) option = pmci->batch_buffer_threshold;
        *optionSize = sizeof(uint32_t);        
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch buffer threshold set to %"PRIu32,
                   pmci->batch_buffer_threshold);
        return pmci_success_e;
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Unavailable option code");
    return pmci_unavailable_option_e;
}

pmci_error_t pmci_close(handle_t pmci_handle)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    pmci_error_t result = pmci_success_e;

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, "pmci_handle=%"PRI_HANDLE, pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }

    /* Close the PM driver handle */
    if ( _pmci_destroy_control_handle(pmci->pmd) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy pmd");
        result = pmci_failure_e;
    }

    /* Close the scan handle */
    if ( _pmci_destroy_scan_handle(pmci->scan) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy scan");
        result = pmci_failure_e;
    }

    /* Close the stats handle */
    if ( _pmci_destroy_stats_handle(pmci->stats) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy stats");
        result = pmci_failure_e;
    }

    /* Close the proxy handles */
    if ( _pmci_destroy_proxy_handles(&pmci->proxy) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy proxy");
        result = pmci_failure_e;
    }

    /* Clear out the handle assignment */
    _pmci_release_handle(pmci);

    /* Release the PMCI scheduling memory */
    free(pmci->sched);

    /* Release the PMCI memory */
    memset(pmci, 0, sizeof(pmci_obj_t));
    free(pmci);

    return result;
}

pmci_error_t pmci_write(handle_t pmci_handle, void *cmds, int cmdsSize)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    pmci_error_t result = pmci_success_e;
    void *start = cmds;
    void *end = cmds + cmdsSize;
    void *batch_start = NULL;
    void *batch_end = NULL;
    void *schedCmds = NULL;
    uint32_t schedCmdsSize = 0, length = 0;
    pmp_header_t *header = NULL;
    bool batch_cmd = false;
    bool clean_batch = false;
    uint32_t batch_attr;
        
    LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
               "pmci_handle=%"PRI_HANDLE", cmds=%p, cmdsSize=%d",
               pmci_handle, cmds, cmdsSize);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }
  
    if ( cmds == NULL || cmdsSize <= 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Bad cmds");
        return pmci_invalid_parameters_e;
    }
    
    /* Scan for batch start & end commands.  Need to handle these PMP command 
       sequence that may arrive inside one buffer:
        <cmd><cmd>...
        <batch_start>
        <batch_end>
        <batch_start><cmd><cmd>...
        <cmd><cmd>...<batch_end>
        <cmd><cmd>...<batch_end><cmd><cmd>...
        <cmd><cmd>...<batch_start>
        <cmd><cmd>...<batch_start><cmd><cmd>...
        <cmd><cmd>...<batch_start><cmd><cmd>...<batch_end><cmd><cmd>...
        <cmd><cmd>...<batch_end><cmd><cmd>...<batch_start><cmd><cmd>...
    */
    while ( start < end )
    {
        schedCmds = NULL;
        
        /* Loop through all commands for a batch start or batch end command. */
        batch_start = start;
        while ( batch_start < end )
        {
            length = _pmci_decode_batch_attr_cmd(batch_start, &batch_cmd, &batch_attr);
            if ( batch_cmd ) /* This cmd is a batch start or batch_end */
            {
                if ( batch_attr ) /* Batch start found. */
                {
                    if ( pmci->batch ) /* already have a batch start before! */
                    {
                        /* Ignores the extra batch start.  Treat it like an NOP. */
                        batch_start += length;
                        continue; /* Resume batch start or end search loop */
                    }
                    pmci->batch = batch_attr;
                    /* Search for a batch end in this cmds.  If one is found
                       then we don't need to batch the commands in between. */
                    batch_end = batch_start + length;
                    while ( batch_end < end )
                    {
                        length = _pmci_decode_batch_attr_cmd(batch_end, &batch_cmd, &batch_attr);
                        if ( batch_cmd )
                        {
                            if ( !batch_attr )
                            {
                                /* Found a batch end */
                                batch_end += length;
                                pmci->batch = batch_attr;
                                break; /* Leave batch end scan loop. */
                            }
                            /* Else ignore any other batch start. */
                        }
                        batch_end += length;
                    } /* batch end after batch start scan loop */
                    if ( pmci->batch ) /* Batch end not found in the same cmds */
                    {
                        /* <batch_start>
                           <batch_start><cmd><cmd>...
                           <cmd><cmd>...<batch_start><cmd><cmd>...
                           Need to buffer the the commands after batch start. */
                        header = (pmp_header_t *) batch_start;
                        length = ntohl(header->msgLength);

                        if ( (uint32_t)(end - (batch_start+length)) < pmci->batch_buffer_threshold )
                        {
                            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch start.  Buffering %"PRIu32" bytes",
                                       (uint32_t) (end - (batch_start+length)));
                            result = _pmci_batch_buffer_add(pmci, batch_start+length,
                                                            end - (batch_start+length));
                            if ( result != pmci_success_e ) return result;
                        }
                        else
                        {
                            /* This cmds is too big.  Don't do batch and exec all cmds instead. */
                            batch_start = end;
                        }
                        if ( start != batch_start )
                        {
                            /* <cmd><cmd>...<batch_start><cmd><cmd>... 
                               Need to exec those before <batch_start> first.
                            OR 
                               This cmds is too big to buffer in batch buffer.  */
                            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Pre batch start.  Sending %"PRIu32" bytes",
                                       (uint32_t) (batch_start - start));
                            schedCmds = start;
                            schedCmdsSize = batch_start - start;
                        }
                        batch_start = end;
                        start = end;
                        break; /* Leave batch cmd search loop. */
                    }
                    else /* Batch end found after batch start in the same cmds.
                            <cmd><cmd>...<batch_start><cmd><cmd>...<batch_end><cmd><cmd>...
                            Ignore this pair of batch start+end. 
                            Start looking for the next batch start. */
                    {
                        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch start+end pair.  Ignored.");
                        batch_start = batch_end;
                        continue; /* Resume batch cmd search loop. */
                    }
                }
                else /* Batch end found */
                {
                    if ( pmci->batch )
                    {
                        pmci->batch = batch_attr;
                        batch_end = batch_start;
                        /* <batch_end>
                           <batch_end><cmd><cmd>...
                           <cmd><cmd>...<batch_end>
                           <cmd><cmd>...<batch_end><cmd><cmd>... 
                           Put everything before batch end into batch buffer.  */
                        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch end.  Buffering %"PRIu32" bytes",
                                   (uint32_t) (batch_end - start));
                        result = _pmci_batch_buffer_add(pmci, start, batch_end-start);
                        if ( result != pmci_success_e ) return result;

                        /* Exec the batch buffer */
                        schedCmds = pmci->batch_buffer_p;
                        schedCmdsSize = pmci->batch_data_len;
                        clean_batch = true;
                        /* After exec, keep scanning for possible batch start.
                           So move start to after the batch end. */
                        start = batch_end + length;
                        break; /* Leave batch cmd search loop. */
                    }
                    /* Else if no batch start before, Treat the command as an NOP. */
                }
            } /* batch attribute check */

            /* The command wasn't a batch start or batch end.  Move to next command. */
            batch_start += length;
        } /* while ( batch_start < end ); */
        
        if ( schedCmds == NULL && batch_start >= end )
        {
            /* No batch start or end was found. */
            if ( pmci->batch ) /* In batch mode */
            {
                /* <cmds><cmds>...
                   There was a batch start in previous cmds.  So we should buffer 
                   this cmds. */
                result = _pmci_batch_buffer_add(pmci, start, end-start);
                if ( result != pmci_success_e ) return result;
                
                if ( pmci->batch_data_len > pmci->batch_buffer_threshold )
                {
                    /* Batch buffer is getting too big.  Send everything in batch buffer 
                       now without waiting for batch end. */
                    schedCmds = pmci->batch_buffer_p;
                    schedCmdsSize = pmci->batch_data_len;
                    clean_batch = true;
                    start = end;
                }
                else
                {
                    /* All cmds are stored in batch buffer.  We are done */
                    break;
                }
            }
            else
            {
                /* <cmds><cmds>...
                   No batch start or end was found. 
                OR
                   <batch_end><cmd><cmd>...
                   <cmd><cmd>...<batch_end><cmd><cmd>...
                   And all the data before <batch_end> has been taken care of.
                   Exec the remaining cmds. */
                schedCmds = start;
                schedCmdsSize = end - start;
                start = end;
            }
        }

        /* If this happens, it is single batch end */
        if ( schedCmds == NULL || schedCmdsSize == 0) break;

        /* Schedule the commands (we do this to minimize exclusive duration) */
        if ( _pmci_writeSchedule(pmci, schedCmds, schedCmdsSize) < 0 )
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to schedule the writes");
            return pmci_failure_e;
        }

        /* Apply the commands to hardware */
        result = _pmci_writeExecute(pmci);
        if ( result != pmci_success_e )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to execute the writes");
        }

        if ( clean_batch )
        {
            /* What just executed came from the batch buffer.  Now we 
               have to clean it up. */
            clean_batch = false;
            if ( pmci->batch_buffer_p && pmci->batch_buffer_len > PMCI_BATCH_BUFFER_THRESHOLD_MIN)
            {
                free(pmci->batch_buffer_p);
                pmci->batch_buffer_p = NULL;
                pmci->batch_buffer_len = 0;
            }
            pmci->batch_data_len = 0;
        }
    } /* While ( start < end ) */

    return result;
}

pmci_error_t pmci_read(handle_t pmci_handle, pmp_msg_t *notif)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    struct timeval delay;
    struct timeval *delayPtr = NULL;
    fd_set readSet;
    int length;
    int n;

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
               "pmci_handle=%"PRI_HANDLE", notif=%p",
               pmci_handle, notif);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }
    
    if ( notif == NULL)
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL pointer");
        return pmci_invalid_parameters_e;
    }

    /* Compute timeout value */
    if ( pmci->timeout != PMCI_INFINITE )
    {
        delayPtr = &delay;
        memset(&delay, 0, sizeof(delay));
        delay.tv_sec = pmci->timeout;
    }
    
    /* Compute the file descriptor set for both read and write */
    FD_ZERO(&readSet);
#ifdef PMCI_RUNNING_ON_TARGET
    FD_SET(pmci->pmd, &readSet);
#endif /* PMCI_RUNNING_ON_TARGET */
    FD_SET(pmci->proxy.consumer, &readSet);
    n = pmci->pmd;
    if ( pmci->proxy.consumer > n ) n = pmci->proxy.consumer;
    n++;
    
    /* Block for timeout seconds */
    if ( select(n, &readSet, NULL, NULL, delayPtr) < 0 )
    {
        return pmci_failure_e;
    }
    
    /* Check if there are some data available on our descriptor */
#ifdef PMCI_RUNNING_ON_TARGET
    if ( FD_ISSET(pmci->pmd, &readSet) )
    {
        /* Read the data from the PM driver handle */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Reading from pmd");

        /* Check to see if we need to interpret the data */
        length = read(pmci->pmd, notif, sizeof(pmp_header_t));
        if ( length != (sizeof(pmp_header_t)) )
        {
            if ( errno == ENODEV ) return pmci_lost_driver_e;
            return pmci_failure_e;
        }
        if ( notif->header.msgType == pmp_table_read_request_msg_type_e )
        {
            /* Need four more bytes to figure out the rest */
            length = read(pmci->pmd, notif->header.data, 
                          sizeof(pmp_table_id_field_t));
            if ( length != sizeof(sizeof(pmp_table_id_field_t)) )
            {
                if ( errno == ENODEV ) return pmci_lost_driver_e;
                return pmci_failure_e;
            }
            if ( (notif->requestMsg.tableReadRequestMsg.tableId == 
                  pmp_user_defined_group_table_id_e) ||
                 (notif->requestMsg.tableReadRequestMsg.tableId == 
                  pmp_equivalence_table_id_e) )
            {
                /* In orther to keep these table consistent with the rest,
                 * we remap the read reply into an homogenous form.
                 */
                length = _pmci_readReadMasquerade(pmci_handle, notif);
                if ( length < 0 )
                {
                    if ( errno == ENODEV ) return pmci_lost_driver_e;
                    return pmci_failure_e;
                }
            }
            else
            {
                /* Normal command */
                length = read(pmci->pmd,
                              &notif->requestMsg.tableReadRequestMsg.index,
                              notif->header.msgLength - sizeof(pmp_header_t) -
                              sizeof(pmp_table_id_field_t));
                if ( length < 0 )
                {
                    if ( errno == ENODEV ) return pmci_lost_driver_e;
                    return pmci_failure_e;
                }
                length += (sizeof(pmp_header_t) + sizeof(pmp_table_id_field_t));
            }
        }
        else if ( notif->header.msgLength > (uint32_t)length )
        {
            /* Normal command */
            length = read(pmci->pmd, 
                          notif->header.data,
                          notif->header.msgLength - length);
            if ( length < 0 )
            {
                if ( errno == ENODEV ) return pmci_lost_driver_e;
                return pmci_failure_e;
            }
            length += sizeof(pmp_header_t);
        }
    }
    else
#endif /* PMCI_RUNNING_ON_TARGET */        
    if ( FD_ISSET(pmci->proxy.consumer, &readSet) )
    {
        /* Read the data from the proxy consumer handle */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Reading from proxy");
        length = read(pmci->proxy.consumer, notif, sizeof(pmp_header_t));
        if ( length != sizeof(pmp_header_t) )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, 
                       "Failed to read PMP header from proxy (%d:%s)",
                       errno, strerror(errno));
            return pmci_failure_e;
        }

        length = read(pmci->proxy.consumer, notif->header.data, 
                      notif->header.msgLength - sizeof(pmp_header_t));
        if ( length < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, 
                       "Failed to read from proxy (%d:%s)",
                       errno, strerror(errno));
            return pmci_failure_e;
        }
        length += sizeof(pmp_header_t);

        if ( length != (int)notif->header.msgLength )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, 
                       "Error reading from proxy (%d/%d)",
                       length, notif->header.msgLength);
            return pmci_failure_e;
        }
    }
    else
    {
        /* Nothing to be retrieved */
        return pmci_empty_read_e;
    }

    /* Toggle the reply bit for each message */
    if ( notif->header.msgType != pmp_error_indication_msg_type_e )
    {
        notif->header.msgType |= PMP_REPLY_MSG_CLASS_FLAG;
    }

    /* Dump the message in the logs */
    _pmci_decode_msg(LOG_TEST, &notif->header);

    return pmci_success_e;
}

pmci_error_t pmci_flush(handle_t pmci_handle)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, "pmci_handle=%"PRI_HANDLE, pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }

#ifdef PMCI_RUNNING_ON_TARGET
    /* The flush ioctl is blocking until everything is flushed */
    if ( ioctl(pmci->pmd, PME_IOCTL_FLUSH) < 0 )
    {
        _pmci_report_error(pmci, pmci_failure_e, "Flush failed");
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }
#endif /* PMCI_RUNNING_ON_TARGET */        

    return pmci_success_e;
}

const char *pmci_error_string ( pmci_error_t code )
{
    int codeIndex;

    /* Validate the error code */
    if ( (code < pmci_error_first_e) ||
         (code > pmci_error_last_e) )
    {
        return _pmci_error_strings[abs(PMCI_UNKNOWN_ERROR_CODE)].string;
    }

    /* Here we could either walk into the table or use the absolute value of
     * the error code as an index.  For now, we just take the absolute value.
     */
    codeIndex = abs(code);

    /* Ensure the chosen index matches with the error code */
    if ( code != _pmci_error_strings[codeIndex].code )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Error code mismatch (%d/%d)",
                   code, _pmci_error_strings[codeIndex].code);
        return _pmci_error_strings[abs(pmci_unrecoverable_error_e)].string;
    }

    /* Return the corresponding error code */
    return _pmci_error_strings[codeIndex].string;
}

void PMCI_FD_SET(handle_t pmci_handle, fd_set *fdset)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return;
    }

    /* Set all PMCI file descriptor to the specified file descriptor mask */
    FD_SET(pmci->pmd, fdset);
    FD_SET(pmci->proxy.consumer, fdset);
}

void PMCI_FD_CLR(handle_t pmci_handle, fd_set *fdset)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return;
    }

    /* Clear all PMCI file descriptor to the specified file descriptor mask */
    FD_CLR(pmci->pmd, fdset);
    FD_CLR(pmci->proxy.consumer, fdset);
}

int PMCI_FD_ISSET(handle_t pmci_handle, fd_set *fdset)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return 0;
    }

    /* Test the specified file descriptor set mask against PMCI descriptors */
    return ( FD_ISSET(pmci->pmd, fdset) || 
             FD_ISSET(pmci->proxy.consumer, fdset) );
}

int PMCI_FD_GETN(handle_t pmci_handle)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    int n;

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return 0;
    }

    /* Provide the highest file descriptor used by PMCI */
    if ( pmci->pmd > pmci->proxy.consumer ) n = pmci->pmd;
    else n = pmci->proxy.consumer;

    return n;
}

/**********************************************************************
 * Private implementation
 **********************************************************************/

static int _pmci_openRetry(const char* dev_name, int flags)
{
    /* There can be a small delay between the insmod command returns and
       the /dev/ decives become available.  To make auto boot script
       easier to make we add a retry delay for opening devices. */
    int fd = -1;
    int retry = 0;
    do {
        fd = open(dev_name, flags);
        if ( fd >= 0 ) break;
        sleep(1);
    } while ( retry++ < 4 );
    return fd;
}

static pmci_obj_t *_pmci_get_object(handle_t pmci_handle)
{
    /* If need to get fancy for the handle, I put handle to obj mapping here */
    return (pmci_obj_t *)pmci_handle;
}

static void _pmci_assign_handle(pmci_obj_t *pmci)
{
    /* If need to get fancy for the handle, I put handle assigment here */
    pmci->handle = (handle_t)pmci;
}

static void _pmci_release_handle(pmci_obj_t *pmci)
{
    /* If need to get fancy for the handle, I put handle releasing here */
    pmci->handle = 0;
}

static int _pmci_is_valid(pmci_obj_t *pmci, handle_t pmci_handle)
{
    return ( (pmci != NULL) &&
             (pmci->magic == PMCI_MAGIC_VALUE) &&
#ifdef PMCI_PID_AND_THREAD_WORKING_PROPERLY
             ( (pmci->pid == getpid()) || (pmci->pid == getppid()) ) &&
#endif /* PMCI_PID_AND_THREAD_WORKING_PROPERLY */
             (pmci->handle == pmci_handle) );
}

static void _pmci_report_error(pmci_obj_t *pmci, int errorNo, char *msg)
{
    pmp_error_indication_msg_t notif;

    if ( errno != ENODEV )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Error=%d, Msg=%s", errorNo, 
                   msg);
        
        /* Build the error notification */
        notif.header.protocolVersion = PMP_CURRENT_VERSION;
        notif.header.msgType         = pmp_error_indication_msg_type_e;
        notif.header.reserved        = 0;
        notif.header.msgLength       = htonl(sizeof(notif));
        notif.header.msgId           = 0;
        notif.errorNo                = htonl((uint32_t)errorNo);
        
        /* Best effort to propagate the error back to application */
        if ( write(pmci->proxy.producer, &notif, sizeof(notif)) < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't notify error "
                       "indication");
        }
    }
}

static int _pmci_create_control_handle(void)
{
    int pmd;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    /* Grab a handle to the PM driver */
    pmd = _pmci_openRetry(PME_DEVICE_DATABASE_PATH, O_RDWR);
    if ( pmd < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't open driver");
        return -1;
    }

    /* Since we can only set the channel once, we don't give a default value */
    
    return pmd;
}

static int _pmci_create_scan_handle(void)
{
    int scan;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */
    /* Grab a handle to the scanner driver */
    scan = _pmci_openRetry(PME_SCANNER_PATH, O_RDWR);
    if ( scan < 0 )
    {
        return -1;
    }

    /* Since we can only set the channel once, we don't give a default value */

    return scan;
}

static int _pmci_create_stats_handle(void)
{
    struct sockaddr_un sun;
    int stats;
    short nop = 0;

    /* Create a socket for the statistics manager */
    stats = socket(PMSM_SOCK_FAMILY, SOCK_STREAM, 0);
    if ( stats < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't create client socket");
        return pmci_failure_e;
    }
    
    /* Connect to statistics manager */
    memset(&sun, 0, sizeof(sun));
    PMSM_SOCK_SET(sun, sizeof(sun));
    if ( connect(stats, (struct sockaddr *)&sun, sizeof(sun)) < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
                   "Can't connect to statistics manager but that's fine");
        close(stats);
        return pmci_success_e;
    }

    /* Send a NOP not to confuse him */
    if ( send(stats, &nop, sizeof(nop), 0) < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
                   "Can't send NOP but that's fine");
        close(stats);
        return pmci_success_e;
    }

    /* Close the socket */
    close(stats);

    return 1;
}

static int _pmci_create_proxy_handles(pmci_proxy_t *proxy)
{
    /* Create a UNIX socket pair */
    return socketpair(AF_UNIX, SOCK_STREAM, 0, proxy->pair);
}

static int _pmci_destroy_control_handle(int pmd)
{
#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */
    return close(pmd);
}

static int _pmci_destroy_scan_handle(int scan)
{
#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */
    return close(scan);
}

static int _pmci_destroy_stats_handle(int stats)
{
    if ( stats < 0 )
    {
        return pmci_failure_e;
    }
    return pmci_success_e;
}

static int _pmci_destroy_proxy_handles(pmci_proxy_t *proxy)
{
    int result;

    /* Destroy each socket of the pair */
    result = close(proxy->producer);
    result |= close(proxy->consumer);

    return result;
}

static int _pmci_set_channel(int pmd, int channelId)
{
    int channel;
    int result;
    char *channelPath;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    /* Build the channel device name */
    channelPath = (char *)malloc(strlen(PME_CHANNEL_PATH)*2);
    sprintf(channelPath, PME_CHANNEL_PATH, channelId);

    /* Get a handle to the specific channel */
    channel = _pmci_openRetry(channelPath, O_RDONLY);
    free(channelPath);
    
    if ( channel < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't open DMA channel %d", channelId);
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Error %d:  %s", 
                   errno, strerror(errno));
        return -1;
    }

    /* Associate the control driver with that channel */
    result = ioctl(pmd, PME_IOCTL_SET_CHANNEL, &channel);
    if ( result < 0 )
    {
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't set to channel %d (%d)", 
                   channelId, result);
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Error %d:  %s", 
                   errno, strerror(errno));
        close(channel); /* Best effort to close the channel */
        return -1;
    }

    /* Close the channel handle */
    if ( close(channel) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close %s", channelPath);
        return -1;
    }

    return result;
}

static int  _pmci_writeSchedule(pmci_obj_t *pmci, void *cmds, int cmdsSize)
{
    void *start = cmds;
    void *end = &(((uint8_t *)cmds)[cmdsSize]);
    void *hwStart = NULL;
    pmp_attribute_set_request_msg_t *hdr1;
    pmp_attribute_set_request_msg_t *hdr2;
    pmp_header_t *header;
    int length;

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Preparing commands");

    /* Walk through every single command */
    pmci->schedNum = 0;
    while ( start < end )
    {
        header = (pmp_header_t *)start;
        length = ntohl(header->msgLength);
        
        /* That's a good time to decode the message */
        _pmci_decode_msg(LOG_TEST, header);

        /* Decouple hardware from software commands */
        if ( (header->msgType == pmp_table_write_request_msg_type_e) ||
             (header->msgType == pmp_ctx_by_session_id_clear_request_msg_type_e) ||
             ( (header->msgType == pmp_table_read_request_msg_type_e) &&
               (header->data[3] != pmp_user_defined_group_table_id_e) &&
               (header->data[3] != pmp_equivalence_table_id_e) ) )
        {
            if ( hwStart == NULL )
            {
                /* First hardware command */
                pmci->sched[pmci->schedNum].cmdPtr = start;
                pmci->sched[pmci->schedNum].cmdLen = length;
                pmci->sched[pmci->schedNum].cmdHw  = true;
                pmci->schedNum++;
                hwStart = start;
            }
            else
            {
                /* Next hardware command */
                pmci->sched[pmci->schedNum-1].cmdLen += length;
            }
        }
        else
        {
            /* Software command */
            pmci->sched[pmci->schedNum].cmdPtr = start;
            pmci->sched[pmci->schedNum].cmdLen = length;
            pmci->sched[pmci->schedNum].cmdHw  = false;
            pmci->schedNum++;
            hwStart = NULL;
        }

        /* Increment the start of command */
        start += length;
        
        /* Ensure we've got sufficient space for the command blocks */
        if ( pmci->schedNum >= pmci->schedSize )
        {
            pmci->schedSize += PMCI_CMD_SCHED_INCR;
            pmci->sched = realloc(pmci->sched, 
                                  pmci->schedSize * sizeof(pmci_cmd_sched_t));
            if ( pmci->sched == NULL )
            {
                LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Out-of-memory");
                return -1;
            }
        }
    }

    /* If we have atomic start, HW chunk and atomic end, we can skip the 
     * atomic start/end message */
    if ( (pmci->schedNum == 3) && (pmci->sched[1].cmdHw == true) )
    {
        hdr1 = (pmp_attribute_set_request_msg_t *)pmci->sched[0].cmdPtr;
        hdr2 = (pmp_attribute_set_request_msg_t *)pmci->sched[2].cmdPtr;
        if ( (hdr1->header.msgType == pmp_attribute_set_request_msg_type_e) &&
             (hdr1->attributeId == pmp_atomic_attr_id_e) &&
             (hdr1->attributeValue.atomicAttr) &&
             (hdr2->header.msgType == pmp_attribute_set_request_msg_type_e) &&
             (hdr2->attributeId == pmp_atomic_attr_id_e) &&
             (hdr2->attributeValue.atomicAttr == 0) )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, 
                       "Optimize by zapping atomic operations");
            pmci->schedNum = 1;
            pmci->sched[0] = pmci->sched[1];
        }
    }

    return 0;
}

static pmci_error_t _pmci_writeExecute(pmci_obj_t *pmci)
{
    int result;
    int sindex;
    pmp_header_t *header;
    int length;

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Executing commands");

    /* Walking through command to execute */
    for ( sindex=0; sindex<pmci->schedNum; sindex++ )
    {
        header = (pmp_header_t *)pmci->sched[sindex].cmdPtr;
        length = pmci->sched[sindex].cmdLen;

#ifndef PMCI_RUNNING_ON_TARGET
        if ( true )
        {
            /* In this case, we don't have access to the PM driver.  Therefore,
             * we are echoing everything back to the pmci_read(...) path via
             * the proxy channel.
             */
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "No target, echoing it back");
            if ( write(pmci->proxy.producer, header, length) < 0 )
            {
                return pmci_failure_e;
            }
        }
        else
#endif /* PMCI_RUNNING_ON_TARGET */
        if ( pmci->sched[sindex].cmdHw )
        {
            /* Executing one or more hardware commands */
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Hardware (%d)", length);
            result = _pmci_write(pmci, header, length);
            if ( result < 0 )
            {
                _pmci_report_error(pmci, result, "Hardware command failed");
                return result;
            }
        }
        else
        {
            /* Executing one software command */
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Software (%d)", length);

            /* Take the performance hit and implement these in software */
            if ( header->msgType == pmp_table_read_request_msg_type_e )
            {
                if ( (header->data[3] != pmp_user_defined_group_table_id_e) &&
                     (header->data[3] != pmp_equivalence_table_id_e) )
                {
                    LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Should not have "
                               "reach this code.  Read in table %d is "
                               "handled by hardware", header->data[3]);
                    _pmci_report_error(pmci, pmci_failure_e, 
                                       "Bad read command");
                    return pmci_failure_e;
                }

                result = _pmci_writeReadMasquerade(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Read masquerade failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_table_reset_request_msg_type_e )
            {
                result = _pmci_reset_all_table(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Reset all table failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_attribute_get_request_msg_type_e )
            {
                result = _pmci_get_attribute(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Get attribute failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_attribute_set_request_msg_type_e )
            {
                result = _pmci_set_attribute(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Set attribute failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_ctx_by_rule_id_clear_request_msg_type_e )
            {
                result = _pmci_clear_context_by_rule_id(
                  pmci, (pmp_ctx_by_rule_id_clear_request_msg_t *)header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Clear by ruleId failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_ctx_all_clear_request_msg_type_e )
            {
                result = _pmci_clear_all_context(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Clear all context failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_data_scan_msg_type_e )
            {
                result = _pmci_scan_data(
                  pmci, (pmp_data_scan_request_msg_t *)header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Scan data failed");
                    return result;
                }
            }
            else
            {
                /* This is an invalid message, drop that one */
                _pmci_report_error(pmci, pmci_failure_e, "Invalid command");
                return pmci_failure_e;
            }
        }
    }

    return 0;
}

static int _pmci_write(pmci_obj_t *pmci, pmp_header_t *header, int length)
{
    /* The hardware can handle these commands as is */
    if ( write(pmci->pmd, header, length) < 0 )
    {
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }

    return pmci_success_e;
}

static int  _pmci_writeReadMasquerade(pmci_obj_t *pmci, pmp_header_t *header)
{
    pmp_table_read_request_msg_t  *origRequest;
    pmp_table_read_request_msg_t  *microRequest;
    int                         macroLength;
    uint8_t                    *macroBuffer;
    int                         status;
    int                         loop;

    /* This is the scenario where reading into a table is using a different
     * approach than writting.  The tables pmp_user_defined_group_table_id_e and
     * pmp_equivalence_table_id_e have asymetric reads and writes.  A write to
     * those table takes only one record containing the whole table whereas
     * the read only reads one byte at a time.  In order to hide this hardware
     * inconsistency, reading into these tables are abstracted by the PMCI
     * layer.  This way, we are exposing a consistent read and write to the
     * applications.  The abstraction takes the form of handling the read
     * request for those two tables in software.
     */

    /* Allocate memory for the proxy read */
    macroLength = 
      sizeof(pmp_table_read_request_msg_t) * PMP_EQUIVALENCE_ENTRY_SIZE;
    macroBuffer = malloc(macroLength);
    if ( macroBuffer == NULL )
    {
        return pmci_out_of_memory_e;
    }
    
    /* Fill in the proxy read requests */
    origRequest  = (pmp_table_read_request_msg_t *)header;
    microRequest = (pmp_table_read_request_msg_t *)macroBuffer;
    microRequest->header.protocolVersion = origRequest->header.protocolVersion;
    microRequest->header.msgType         = origRequest->header.msgType;
    microRequest->header.reserved        = origRequest->header.reserved;
    microRequest->header.msgLength       = sizeof(pmp_table_read_request_msg_t);
    microRequest->header.msgId           = origRequest->header.msgId;
    microRequest->tableId                = origRequest->tableId;
    microRequest->index                  = PMP_EQUIVALENCE_ENTRY_SIZE - 1;
    microRequest++;
    for (loop=PMP_EQUIVALENCE_ENTRY_SIZE - 2; loop>=0; loop--)
    {
        memcpy(microRequest, &microRequest[-1], 
               sizeof(pmp_table_read_request_msg_t));
        microRequest->index = loop;
        microRequest++;
    }

    /* Send the macro read request as one command */
    status = _pmci_write(pmci, (pmp_header_t *)macroBuffer, macroLength);

    /* Release the temporary memory */
    free(macroBuffer);

    return status;
}

#ifdef PMCI_RUNNING_ON_TARGET
static int _pmci_readReadMasquerade(pmci_obj_t *pmci, pmp_msg_t *notif)
{
#define _PMCI_READ_REPLY_SIZE \
  (sizeof(pmp_header_t) + sizeof(pmp_table_id_t) + sizeof(pmp_index_t) + \
   sizeof(uint32_t))

    pmp_table_read_reply_msg_t *reply;
    uint8_t *ptr;
    int length;
    int loop;

    /* This is the case that notifs alreay holds the first 20 bytes of the
     * first read table reply.  What's left is to complete the reading of
     * that first reply, read the other replies and build the desired 
     * resulting reply.
     */

    /* Complete the first reply */
    ptr = (uint8_t *)notif;
    ptr += (PMP_EQUIVALENCE_ENTRY_SIZE - 1);
    reply = (pmp_table_read_reply_msg_t *)ptr;
    length = read(pmci->pmd, &reply->indexedEntry.index, 2*sizeof(uint32_t));
    if ( length != (2*sizeof(uint32_t)) )
    {
        return pmci_failure_e;
    }

    /* Read the other replies.  Warning, this function makes a wrong
     * assumption that there are three spare bytes at the end of the
     * notifs buffer.  If the buffer is of type pmp_msg_t, there are no
     * problem because that structure is of a big enough size to 
     * accomodate this little trick (the use of three extra byte at
     * the end of the read reply structure).  However, if the function
     * allows to specify precisely PMP_EQUIVALENCE_TABLE_READ_REPLY_MSG_SIZE
     * or PMP_USER_DEFINED_GROUP_ENTRY_SIZE, then this function would
     * potentially scribble the memory.  Since the above assumption is
     * correct, the code below will work without a problem.
     */
    for ( loop=PMP_EQUIVALENCE_ENTRY_SIZE-2; loop>=0; loop-- )
    {
        ptr--;
        length = read(pmci->pmd, ptr, _PMCI_READ_REPLY_SIZE);
        if ( length != _PMCI_READ_REPLY_SIZE )
        {
            return pmci_failure_e;
        }
    }
    reply = (pmp_table_read_reply_msg_t *)notif;
    
    /* Need to get rid of three unused bytes between header and data.
     * Unfortunately, the read command reads one byte into a word.
     * Therefore, three bytes are not used within that word.  The
     * result is at the end, we need to move the data left by three bytes.
     */
    memmove(&reply->indexedEntry.entry, 
            &reply->indexedEntry.entry.equivalenceEntry[3], 
            PMP_EQUIVALENCE_ENTRY_SIZE);

    /* Adjust the header */
    reply->header.msgLength = PMP_EQUIVALENCE_TABLE_READ_REPLY_MSG_SIZE;
        
    return reply->header.msgLength;
}
#endif /* PMCI_RUNNING_ON_TARGET */

static int _pmci_reset_all_table(pmci_obj_t *pmci, pmp_header_t *header)
{
    int min, max, cur;
    int recordSize, msgSize;
    int result;
    pmp_table_reset_request_msg_t *resetReq = 
        (pmp_table_reset_request_msg_t *)header;
    pmp_table_write_request_msg_t *writeReq;
    uint8_t *buf;

    /* Compute the start and end index */
    min = 0;
    max = _pmci_max_index_get(pmci, resetReq->tableId);
    recordSize = _pmci_record_size_get(resetReq->tableId);
    msgSize = sizeof(pmp_table_reset_request_msg_t) + 
        ((recordSize + sizeof(pmp_index_t)) * (max+1));

    /* Allocate memory to store the write commands */
    writeReq = (pmp_table_write_request_msg_t *)malloc(msgSize);
    if ( writeReq == NULL )
    {
        return pmci_out_of_memory_e;
    }

    /* Build a generic message */
    memcpy(&writeReq->header, &resetReq->header, sizeof(pmp_header_t));
    writeReq->header.msgType = pmp_table_write_request_msg_type_e;
    writeReq->header.msgLength  = msgSize;
    writeReq->tableId = resetReq->tableId;
    buf = (uint8_t *)&writeReq->indexedEntry.index;

    /* Build a single write command for the whole table */
    for ( cur=min; cur<=max; cur++ )
    {
        *(uint32_t *)buf = cur;
        buf += sizeof(pmp_index_t);

        memset(buf, 0, recordSize);
        buf += recordSize;
    }

#ifdef PMCI_DECODE_HW_FROM_SW_CMD
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Software Command Translation");
    _pmci_decode_msg(LOG_TEST, (pmp_header_t *)writeReq);
#endif /* PMCI_DECODE_HW_FROM_SW_CMD */

    /* Apply the single message to the hardware */
    result = _pmci_write(pmci, (pmp_header_t *)writeReq, msgSize);
    if ( result != pmci_success_e )
    {
        free(writeReq);
        return result;
    }

    free(writeReq);
    return pmci_success_e;
}

static int  _pmci_ioctl(int dma, int cmd, struct pme_ctrl_opts *opts)
{
    int result = pmci_success_e;
    int rc;

    rc = ioctl(dma, cmd, opts);
    if ( rc < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "ioctl cmd=%d rc=%d", cmd, rc);
        result = pmci_invalid_attribute_val_e;
    }
    return result;
}

static int  _pmci_get_config_attr(pmci_obj_t *pmci, uint32_t attrId, uint32_t *valuePtr)
{
    /* Get the driver configured attribute values */
    int result = pmci_invalid_attribute_id_e;
    FILE *param;
    
    switch(attrId)
    {
    case pmp_extension_block_num_attr_id_e:
        if ( pmci->extensionBlockNumValid )
        {
            *valuePtr = pmci->extensionBlockNum;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_DXE_SRE_TABLE_SIZE);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->extensionBlockNum = *valuePtr;
                    pmci->extensionBlockNumValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    case pmp_context_max_num_attr_id_e:
        if ( pmci->contextMaxNumValid )
        {
            *valuePtr = pmci->contextMaxNum;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_SRE_SESSION_CTX_NUM);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->contextMaxNum = *valuePtr;
                    pmci->contextMaxNumValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    case pmp_context_area_size_attr_id_e:
        if ( pmci->contextAreaSizeValid )
        {
            *valuePtr = pmci->contextAreaSize;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_SRE_SESSION_CTX_SIZE);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->contextAreaSize = *valuePtr;
                    pmci->contextAreaSizeValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    case pmp_max_stateful_rule_num_attr_id_e:
        if ( pmci->maxRuleNumValid )
        {
            *valuePtr = pmci->maxRuleNum;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_SRE_NUM_RULES);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->maxRuleNum = *valuePtr;
                    pmci->maxRuleNumValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    default:
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        break;
    }
    return result;
}

static int  _pmci_get_attribute(pmci_obj_t *pmci, pmp_header_t *header)
{
    pmp_attribute_get_request_msg_t *getReq = 
        (pmp_attribute_get_request_msg_t *)header;
    pmp_attribute_get_reply_msg_t getReply;
    uint32_t attrId = ntohl(getReq->attributeId);
    uint32_t value = 1;
    pmp_statistics_attr_t stats;
    pmp_hw_revision_t hwRev;
    pmp_protocol_revision_t protoRev;
    int result = pmci_invalid_attribute_id_e;
    int length;
    int valueLength = sizeof(value);
    void *valuePtr = &value;
    int dma;
    struct pme_ctrl_opts options;

    /* Sanitize the attributeId */
    if ( attrId > pmp_last_attr_id_e )
    {
        return pmci_invalid_attribute_id_e;
    }

    /* Retrieve the attribute */
    switch(attrId)
    {
    case pmp_statistics_attr_id_e:
        result = _pmci_get_statistics(pmci, &stats);
        valueLength = sizeof(stats);
        valuePtr = &stats;
        break;
    case pmp_hardware_revision_attr_id_e:
        result = _pmci_get_hw_revision(&hwRev);
        valueLength = sizeof(hwRev);
        valuePtr = &hwRev;
        break;
    case pmp_protocol_revision_attr_id_e:
        result = _pmci_get_protocol_revision(&protoRev);
        valueLength = sizeof(protoRev);
        valuePtr = &protoRev;
        break;
    case pmp_atomic_attr_id_e:
        value = pmci->exclusive;
        result = pmci_success_e;
        break;
    case pmp_batch_attr_id_e:
        value = pmci->batch;
        result = pmci_success_e;
        break;
    case pmp_sre_end_of_sui_index_attr_id_e:
        dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
        if ( dma < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
            return pmci_failure_e;
        }
        options.flags = PME_CTRL_OPT_EOSRP;
        result = _pmci_ioctl(dma, PME_CTRL_IOCTL_GET_OPTS, &options);
        value = options.eosrp;
        if ( close(dma) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
        }
        break;
    case pmp_variable_trigger_size_attr_id_e:
        dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
        if ( dma < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
            return pmci_failure_e;
        }
        options.flags = PME_CTRL_OPT_KVLTS;
        result = _pmci_ioctl(dma, PME_CTRL_IOCTL_GET_OPTS, &options);
        value = options.kvlts;
        if ( close(dma) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
        }
        break;
    case pmp_confidence_chain_max_length_attr_id_e:
        dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
        if ( dma < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
            return pmci_failure_e;
        }
        options.flags = PME_CTRL_OPT_MCL;
        result = _pmci_ioctl(dma, PME_CTRL_IOCTL_GET_OPTS, &options);
        value = options.mcl;
        if ( close(dma) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
        }
        break;
    case pmp_sw_database_signature_attr_id_e:
        dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
        if ( dma < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
            return pmci_failure_e;
        }
        options.flags = PME_CTRL_OPT_SWDB;
        result = _pmci_ioctl(dma, PME_CTRL_IOCTL_GET_OPTS, &options);
        value = options.swdb;
        if ( close(dma) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
        }
        break;
    case pmp_drcc_selection_attr_id_e:
        dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
        if ( dma < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
            return pmci_failure_e;
        }
        options.flags = PME_CTRL_OPT_DRCC;
        result = _pmci_ioctl(dma, PME_CTRL_IOCTL_GET_OPTS, &options);
        value = options.drcc;
        if ( close(dma) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
        }
        break;
    case pmp_extension_block_num_attr_id_e:
    case pmp_context_max_num_attr_id_e:
    case pmp_context_area_size_attr_id_e:
    case pmp_max_stateful_rule_num_attr_id_e:
        result = _pmci_get_config_attr(pmci, attrId, &value);
        break;
    default:
        /* Due to the check at beginning, we should never get here */
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        break;
    }

    /* Verify the operation */
    if ( result < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't retrieve attribute");
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return result;
    }

    /* Reply with the attribute value */
    length = PMP_ATTRIBUTE_GET_REPLY_MSG_SIZE(valueLength);
    memcpy(&getReply, getReq, sizeof(pmp_attribute_get_request_msg_t));
    getReply.header.msgLength = htonl(length);
    memcpy(&getReply.attributeValue, valuePtr, valueLength);
    if ( write(pmci->proxy.producer, &getReply, length) < 0 )
    {
        return pmci_failure_e;
    }

    return pmci_success_e;
}

static int  _pmci_set_attribute(pmci_obj_t *pmci, pmp_header_t *header)
{
    pmp_attribute_set_request_msg_t *setReq = 
        (pmp_attribute_set_request_msg_t *)header;
    uint32_t attrId = ntohl(setReq->attributeId);
    uint32_t value;
    uint32_t valueLength = (header->msgLength - 
                            PMP_ATTRIBUTE_SET_REQUEST_EMPTY_MSG_SIZE);
    struct pme_ctrl_opts options;
    int result = pmci_invalid_attribute_len_e;
    int dma;

    /* Compute the attribute value */
    memcpy(&value, &setReq->attributeValue, sizeof(value));

    /* Prevent compiler warning */
    if ( pmci == NULL )
    {
        return pmci_invalid_handle_e;
    }

    /* Sanitize the attributeId */
    if ( attrId > pmp_last_attr_id_e )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        return pmci_invalid_attribute_id_e;
    }

    /* Assign the attribute */
    switch(attrId)
    {
    case pmp_statistics_attr_id_e:
        if ( valueLength == 0 )
        {
            result = _pmci_reset_statistics(pmci);
        }
        break;
    case pmp_hardware_revision_attr_id_e:
        /* This act as an error since can't set hardware revision */
        result = pmci_invalid_attribute_id_e;
        break;
    case pmp_protocol_revision_attr_id_e:
        /* This act as an error since can't set protocol revision */
        result = pmci_invalid_attribute_id_e;
        break;
    case pmp_atomic_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_set_exclusivity(pmci, value);
        }
        break;
    case pmp_batch_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            /* Do nothing.  pmci_write() already handled all the work for 
               this attribute. */
            result = pmci_success_e;
        }
        break;
    case pmp_sre_end_of_sui_index_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
            if ( dma < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
                return pmci_failure_e;
            }
            options.flags = PME_CTRL_OPT_EOSRP;
            options.eosrp = value;
            result = _pmci_ioctl(dma, PME_CTRL_IOCTL_SET_OPTS, &options);
            if ( close(dma) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
            }
        }
        break;
    case pmp_variable_trigger_size_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
            if ( dma < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
                return pmci_failure_e;
            }
            options.flags = PME_CTRL_OPT_KVLTS;
            options.kvlts = value;
            result = _pmci_ioctl(dma, PME_CTRL_IOCTL_SET_OPTS, &options);
            if ( close(dma) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
            }
        }
        break;
    case pmp_confidence_chain_max_length_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
            if ( dma < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
                return pmci_failure_e;
            }
            options.flags = PME_CTRL_OPT_MCL;
            options.mcl = value;
            result = _pmci_ioctl(dma, PME_CTRL_IOCTL_SET_OPTS, &options);
            if ( close(dma) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
            }
        }
        break;
    case pmp_sw_database_signature_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
            if ( dma < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
                return pmci_failure_e;
            }
            options.flags = PME_CTRL_OPT_SWDB;
            options.swdb = value;
            result = _pmci_ioctl(dma, PME_CTRL_IOCTL_SET_OPTS, &options);
            if ( close(dma) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
            }
        }
        break;
    case pmp_drcc_selection_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
            if ( dma < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
                return pmci_failure_e;
            }
            options.flags = PME_CTRL_OPT_DRCC;
            options.drcc = value;
            result = _pmci_ioctl(dma, PME_CTRL_IOCTL_SET_OPTS, &options);
            if ( close(dma) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close the DMA CTRL handle");
            }
        }
        break;
    case pmp_extension_block_num_attr_id_e:
    case pmp_context_max_num_attr_id_e:
    case pmp_context_area_size_attr_id_e:
    case pmp_max_stateful_rule_num_attr_id_e:
        /* These are read-only attributes */
        result = pmci_invalid_attribute_id_e;
        break;
    default:
        /* Due to the check at beginning, we should never get here */
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        result = pmci_invalid_attribute_id_e;
        break;
    }

    /* Verify the operation */
    if ( result < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't set attribute");
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }

    return pmci_success_e;
}

static int _pmci_clear_context_by_rule_id(pmci_obj_t *pmci,
                                     pmp_ctx_by_rule_id_clear_request_msg_t *req)
{
    struct pme_sre_reset sreReset;
    bool resetThatCacheLine;
    int ruleIndex;
    int numRules;
    int clIndex;
    int clCap;
    int bitPos;
    int dma;
    uint32_t sessionCtxSize;
    uint32_t sessionNum;
    uint32_t maxRuleNum;

    if ( _pmci_get_config_attr(pmci, pmp_context_area_size_attr_id_e, &sessionCtxSize) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionCtxSize");
        return pmci_failure_e;
    }
    if ( _pmci_get_config_attr(pmci, pmp_context_max_num_attr_id_e, &sessionNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionNum");
        return pmci_failure_e;
    }
    if ( _pmci_get_config_attr(pmci, pmp_max_stateful_rule_num_attr_id_e, &maxRuleNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get maxRuleNum");
        return pmci_failure_e;
    }


    /* Opening a handle to the DMA driver */
    dma = _pmci_openRetry(PME_CTRL_PATH, O_RDWR);
    if ( dma < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
        return pmci_failure_e;
    }

    /* Compute the number of rules and cache line to clear */
    numRules = (req->header.msgLength - 
                sizeof(pmp_ctx_by_rule_id_clear_request_msg_t) +
                sizeof(uint32_t)) / sizeof(uint32_t);
    clCap = maxRuleNum / PMP_SESSION_CONTEXT_ENTRY_SIZE;

    /* For each session digest cache line, we clear the appropriate rules */
    for ( clIndex = 0; clIndex < clCap; clIndex ++ )
    {
        /* First, we must build the mask */
        memset(&sreReset, 0, sizeof(sreReset));
        resetThatCacheLine = false;
        for ( ruleIndex = 0; ruleIndex < numRules; ruleIndex++ )
        {
            if ( ((int)req->ruleIds[ruleIndex] / 
                  pmp_rule_num_in_session_context_entry) == clIndex )
            {
                bitPos = req->ruleIds[ruleIndex] % 
                  pmp_rule_num_in_session_context_entry;
                sreReset.rule_vector[bitPos/32] |= (1 << (31 - (bitPos%32)));
                resetThatCacheLine = true;
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "   ruleId %d",
                           req->ruleIds[ruleIndex]);
            }
        }

        /* Only if at least one bit is set do we reset the cache line */
        if ( resetThatCacheLine )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Clearing context for specific "
                       "rules between %d and %d", 
                       clIndex * pmp_rule_num_in_session_context_entry,
                       ((clIndex+1) * pmp_rule_num_in_session_context_entry) 
                       - 1);
            LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, sreReset.rule_vector,
                            PMP_SESSION_CONTEXT_ENTRY_SIZE);

            sreReset.rule_index            = clIndex;
            sreReset.rule_increment        = (sessionCtxSize / 
                                              PMP_SESSION_CONTEXT_ENTRY_SIZE);
            sreReset.rule_repetitions      = sessionNum;
            sreReset.rule_reset_interval   = PMCI_SRE_CYCLE_INTERVAL;
            sreReset.rule_reset_priority   = PMCI_SRE_CLEAR_PRIORITY;
            if ( ioctl(dma, PME_CTRL_IOCTL_SRE_RESET, &sreReset) < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to clear rules "
                           "in cache line offset %d", clIndex);
                close(dma); /* Best effort for closing */
                if ( errno == ENODEV ) return pmci_lost_driver_e;
                return pmci_failure_e;
            }
        }
    }

    /* Close the DMA driver */
    if ( close(dma) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close DMA CTRL handle");
        return pmci_failure_e;
    }

    /* We might need the pmci object in the future, for now we touch it in
     * order to avoid a compiler warning.
     */
    if ( pmci == NULL )
    {
        return pmci_failure_e;
    }

    return pmci_success_e;
}

static int _pmci_clear_all_context(pmci_obj_t *pmci, pmp_header_t *header)
{
    int min, max, cur;
    int msgSize;
    int result;
    uint32_t sessionNum;
    pmp_header_t my_header;
    pmp_ctx_by_session_id_clear_request_msg_t *clearOne;
    pmp_ctx_by_session_id_clear_request_msg_t *clearAll;
    bool low_mem_mode = false;

    if ( _pmci_get_config_attr(pmci, pmp_context_max_num_attr_id_e, &sessionNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionNum");
        return pmci_failure_e;
    }

    /* Compute the start and end index */
    min = 1;  /* The first session id that has a context that needs reseting. */
    max = sessionNum-1; /* The last valid session id. */
    
    if ( max < min )
    {
        /* Only possible when sessionNum is configured to be 1.  Hence only 
           sessionId 0 is valid, and it don't need to be reset. */
        return pmci_success_e;
    }
    
    /* Allocate memory to store all commands */
    msgSize = sizeof(pmp_ctx_by_session_id_clear_request_msg_t) * ((max-min)+1);
    clearAll = malloc(msgSize);
    if ( clearAll == NULL )
    {
        /* May be we got millions of sessions.  Fall back to clear one session at
           a time mode. */
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Enter low memory mode after"
                   " failed to allocate %d bytes", msgSize);
        msgSize = sizeof(pmp_ctx_by_session_id_clear_request_msg_t);
        clearAll = malloc(msgSize);
        /* Can't do anything if we can't even allocate 24 bytes. */
        if ( clearAll == NULL ) return pmci_out_of_memory_e;
        low_mem_mode = true;
    }
    clearOne = clearAll;
    memcpy(&my_header, header, sizeof(pmp_header_t));
    my_header.msgType = pmp_ctx_by_session_id_clear_request_msg_type_e;
    my_header.msgLength = sizeof(pmp_ctx_by_session_id_clear_request_msg_t);
    
    /* Build HW commands that erase each session context. */
    for ( cur=min; cur<=max; cur++ )
    {
        memcpy(&clearOne->header, &my_header, sizeof(pmp_header_t));
        clearOne->ruleCap = 0;
        clearOne->sessionId = cur;

#ifdef PMCI_DECODE_HW_FROM_SW_CMD
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Software Command Translation");
        _pmci_decode_msg(LOG_TEST, (pmp_header_t *)clearOne);
#endif /* PMCI_DECODE_HW_FROM_SW_CMD */
        
        if ( low_mem_mode )
        {
            /* Clear one session at a time */
            result = _pmci_write(pmci, (pmp_header_t *)clearOne, msgSize);
            if ( result != pmci_success_e )
            {
                free(clearAll);
                return result;
            }
        }
        else
        {
            /* Command stored in the list. */
            clearOne++;
        }
    }

    if ( !low_mem_mode )
    {
        /* Send all commands in the list to hardware. */
        result = _pmci_write(pmci, (pmp_header_t *)clearAll, msgSize);
        if ( result != pmci_success_e )
        {
            free(clearAll);
            return result;
        }
    }
    
    free(clearAll);
    return pmci_success_e;
}

static int _pmci_set_exclusivity(pmci_obj_t *pmci, bool exclusiveState)
{
#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    if ( exclusiveState )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Setting exclusivity");
        pmci->exclusive = 1;
        if ( ioctl(pmci->pmd, PME_IOCTL_BEGIN_EXCLUSIVE) < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to set exclusivity");
            if ( errno == ENODEV ) return pmci_lost_driver_e;
            return pmci_failure_e;
        }
    }
    else
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Clearing exclusivity");
        pmci->exclusive = 0;
        if ( ioctl(pmci->pmd, PME_IOCTL_END_EXCLUSIVE) < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to clear "
                       "exclusivity");
            if ( errno == ENODEV ) return pmci_lost_driver_e;
            return pmci_failure_e;
        }
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Done.");
    return pmci_success_e;
}

static int _pmci_scan_data(pmci_obj_t *pmci, pmp_data_scan_request_msg_t *cmd)
{
    pmp_scan_report_indication_msg_t *notif;
    struct pme_parameters parms;
    struct pme_scanner_operation oper;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    notif = malloc(PMCI_MAX_MSG_SIZE);
    if ( notif == NULL )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Out-of-memory");
        return pmci_out_of_memory_e;
    }

    /* Ensure we start filling the structure from scratch */
    memset(&parms, 0, sizeof(parms));
    memset(&oper, 0, sizeof(oper));

    /* Update the scanner context */
    parms.flags = ( PME_PARAM_SET |
                    PME_PARAM_SUBSET |
                    PME_PARAM_SESSION_ID |
                    PME_PARAM_MODE );
    parms.pattern_set = cmd->set;
    parms.pattern_subset = ntohl(cmd->subsetMask);
    parms.session_id = ntohl(cmd->sessionId);
    parms.mode = PME_MODE_PASSTHRU_SCAN;
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "set=%d, mask=0x%x, sessionId=0x%x, "
               "mode=0x%x", parms.pattern_set, parms.pattern_subset,
               parms.session_id, parms.mode);
    if ( ioctl(pmci->scan, PME_IOCTL_SET_PARAMETERS, &parms) < 0 )
    {
        free(notif);
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }
    
    /* Send the data through the scanner */
    oper.cmd_flags = 0;
    oper.input_data = cmd->data;
    oper.input_size = ntohl(cmd->header.msgLength) - 
      sizeof(pmp_data_scan_request_msg_t);
    oper.results[PME_SCANNER_DEFLATE_IDX].data = NULL;
    oper.results[PME_SCANNER_DEFLATE_IDX].size = 0;    /* Deflate is not used */
    oper.results[PME_SCANNER_DEFLATE_IDX].used = 0;
    oper.results[PME_SCANNER_REPORT_IDX].data = notif->reports;
    oper.results[PME_SCANNER_REPORT_IDX].size = 
        PMCI_MAX_MSG_SIZE - sizeof(pmp_scan_report_indication_msg_t);
    oper.results[PME_SCANNER_REPORT_IDX].used = 0;
    if ( ioctl(pmci->scan, PME_SCANNER_IOCTL_EXECUTE_CMD, &oper) < 0 )
    {
        free(notif);
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Data was:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, oper.input_data, oper.input_size);
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Report is:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, oper.results[PME_SCANNER_REPORT_IDX].data,
        oper.results[PME_SCANNER_REPORT_IDX].used);
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Operation status is now:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, &oper, sizeof(oper));

    /* Ensure we got a report */
    if ( (oper.results[PME_SCANNER_REPORT_IDX].data == NULL) ||
         (oper.results[PME_SCANNER_REPORT_IDX].size < PMCI_MIN_REPORT_SIZE) )
    {
        free(notif);
        return pmci_failure_e;
    }

    /* Prepare the notification message (data is already copied) */
    memcpy(notif, cmd, sizeof(pmp_header_t));
    notif->header.msgType = pmp_scan_report_indication_msg_type_e;
    notif->header.msgLength  = sizeof(pmp_scan_report_indication_msg_t) + 
      oper.results[PME_SCANNER_REPORT_IDX].used;
    notif->origOffset = 0;
    
    /* Move the report data down the proxy stream */
    if ( write(pmci->proxy.producer, notif, notif->header.msgLength) < 0 )
    {
        free(notif);
        return pmci_failure_e;
    }

    /* Report is available in the pmci_read(...) path */
    free(notif);
    return pmci_success_e;
}

static int _pmci_get_hw_revision(pmp_hw_revision_t *rev)
{
    int hwHandle;
    struct pme_ctrl_rev hwRev;

    /* Need a separate handle to query the hardware revision */
    hwHandle = _pmci_openRetry(PME_CTRL_PATH, O_RDONLY);
    if ( hwHandle < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get a DMA CTRL handle");
        return pmci_failure_e;
    }

    /* Querying hardware revision is done through ioctl */
    if ( ioctl(hwHandle, PME_CTRL_IOCTL_REV, &hwRev) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't get revision, ioctl failed");
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }

    /* Convert the result into the protocol format */
    rev->socFamily                 = 0; /* Need to compute those */
    rev->socMember                 = 0; /* Need to compute those */
    rev->coreId                    = hwRev.ip_id;
    rev->coreMajor                 = hwRev.ip_mj;
    rev->coreMinor                 = hwRev.ip_mn;
    rev->coreIntegrationOptions    = hwRev.ip_int;
    rev->coreConfigurationOptions  = hwRev.ip_cfg;
    rev->unused                    = 0;

    /* No need to keep that handle around */
    if ( close(hwHandle) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't close DMA CTRL handle");
        return pmci_failure_e;
    }

    return pmci_success_e;
}

static int _pmci_get_protocol_revision(pmp_protocol_revision_t *rev)
{
    /* Convert the result into the protocol format */
    rev->protocolMajor             = PMP_CURRENT_VERSION;
    rev->protocolMinor             = 0;
    rev->unused                    = 0;

    return pmci_success_e;
}

static int _pmci_get_statistics(pmci_obj_t *pmci, pmp_statistics_attr_t *stats)
{
    PmsmKesStats_t kes;
    PmsmDxeStats_t dxe;
    PmsmSreStats_t sre;
    PmsmDeflateStats_t deflate;
    uint8_t command = PMSM_CMD_QUERY;
    uint8_t group = PMSM_GROUP_PM_ALL | PMSM_GROUP_DEFLATE;
    int results = pmci_success_e;
    int pmsm;
    struct sockaddr_un sun;

    /* Avoid compiler warning */
    if ( pmci == NULL ) return pmci_invalid_handle_e;

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Proxying to PMSM");
    
    /* Clear the buffer holding the hardware statistics */
    memset(&kes, 0xff, sizeof(kes));
    memset(&dxe, 0xff, sizeof(dxe));
    memset(&sre, 0xff, sizeof(sre));
    memset(&deflate, 0xff, sizeof(deflate));

    /* Query the statistics */
#ifdef PMCI_STRICT_STATS_HANDLING
    if ( pmci->stats <= 0 )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Not hooked to statistics "
                   "manager");
    }
    else
#endif /* PMCI_STRICT STATS_HANDLING */
    {
        /* Create a socket for the statistics manager */
        pmsm = socket(PMSM_SOCK_FAMILY, SOCK_STREAM, 0);
        if ( pmsm < 0 )
        {
            LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't create client socket");
            results = pmci_failure_e;
        }

        /* Connect to statistics manager */
        memset(&sun, 0, sizeof(sun));
        PMSM_SOCK_SET(sun, sizeof(sun));
        if ( connect(pmsm, (struct sockaddr *)&sun, sizeof(sun)) < 0 )
        {
            LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
                       "Can't connect to statistics manager but that's fine");
            results = pmci_failure_e;
        }

        /* Query the statistics */
        if ( send(pmsm, &command, sizeof(command), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't send command code");
            results = pmci_failure_e;
        }
        if ( send(pmsm, &group, sizeof(group), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't send group code");
            results = pmci_failure_e;
        }

        /* Wait for the results */
        if ( recv(pmsm, &kes, sizeof(kes), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't retrieve KES stats");
            results = pmci_failure_e;
        }
        if ( recv(pmsm, &dxe, sizeof(dxe), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't retrieve DXE stats");
            results = pmci_failure_e;
        }
        if ( recv(pmsm, &sre, sizeof(sre), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't retrieve SRE stats");
            results = pmci_failure_e;
        }
        if ( recv(pmsm, &deflate, sizeof(deflate), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't retrieve Deflate stats");
            results = pmci_failure_e;
        }

        close(pmsm);
    }

    /* Copy the statistics over */
    stats->pmInputBytes              = kes.inputByte;
    stats->pmOutputBytes             = sre.reportByte;
    stats->pmTriggerOneByteHits      = kes.triggerOneByteHit;
    stats->pmTriggerTwoByteHits      = kes.triggerTwoByteHit;
    stats->pmTriggerVariableHits     = kes.triggerVariableHit;
    stats->pmTriggerSpecialHits      = kes.triggerSpecialHit;
    stats->pmConfidenceHits          = kes.confidenceHit;
    stats->pmMatches                 = dxe.patternMatch;
    stats->pmDxeExecutions           = sre.dxeWithSrExecution;
    stats->pmEndOfSuiExecutions      = sre.suiWithSrExecution;
    stats->pmSuiMatchingPatterns     = dxe.suiMatch;
    stats->pmSuiGeneratingReports    = sre.suiWithSrReport;
    stats->pmInputSuis               = kes.inputSui;
    stats->pmSelectedMatches         = dxe.matchWithinDrcc;
    stats->dfInputBytes              = deflate.consumedByte;
    stats->dfOutputBytes             = deflate.producedByte;
    stats->dfDecompressions          = deflate.consumedWorkUnit;
    
    return pmci_success_e;
}

static int  _pmci_reset_statistics(pmci_obj_t *pmci)
{
    uint8_t command = PMSM_CMD_RESET;
    uint8_t group = PMSM_GROUP_PM_ALL | PMSM_GROUP_DEFLATE;
    int results = pmci_success_e;
    int pmsm;
    struct sockaddr_un sun;

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Proxying to PMSM");
    
    /* Reset the statistics */
    if ( pmci->stats <= 0 )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Not hooked to statistics "
                   "manager");
    }
    else
    {
        /* Create a socket for the statistics manager */
        pmsm = socket(PMSM_SOCK_FAMILY, SOCK_STREAM, 0);
        if ( pmsm < 0 )
        {
            LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Can't create client socket");
            results = pmci_failure_e;
        }

        /* Connect to statistics manager */
        memset(&sun, 0, sizeof(sun));
        PMSM_SOCK_SET(sun, sizeof(sun));
        if ( connect(pmsm, (struct sockaddr *)&sun, sizeof(sun)) < 0 )
        {
            LOG_STRING(LOG_INFO, _PMCI_PREFIX, 
                       "Can't connect to statistics manager but that's fine");
            results = pmci_failure_e;
        }

        /* Query the statistics */
        if ( send(pmsm, &command, sizeof(command), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't send command code");
            results = pmci_failure_e;
        }
        if ( send(pmsm, &group, sizeof(group), 0) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't send group code");
            results = pmci_failure_e;
        }
    }
    
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Completed with code %d", results);
    
    return results;
}

/* Add commands to batch buffer.  Ignores 0 length command buffer. */
static int _pmci_batch_buffer_add(pmci_obj_t *pmci, void* data, uint32_t length)
{
    int results = pmci_success_e;
    uint8_t* new_buffer_p;
    uint32_t n;
    
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch add 0x%p, length=%"PRIu32, data, length);
    if ( length > 0 )
    {
        if ( pmci->batch_data_len + length > pmci->batch_buffer_len )
        {
            /* Need bigger buffer */
            n = ((pmci->batch_data_len + length - pmci->batch_buffer_len) / 
                 PMCI_BATCH_BUFFER_GLOW_DELTA) + 1;
            pmci->batch_buffer_len += n * PMCI_BATCH_BUFFER_GLOW_DELTA;
            new_buffer_p = realloc(pmci->batch_buffer_p, pmci->batch_buffer_len);
            if ( new_buffer_p == NULL )
            {
                /* Can't adjust the size of the buffer */
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, 
                          "Cannot grow batch buffer to %"PRIu32" bytes",
                          pmci->batch_buffer_len);
                return pmci_out_of_memory_e;
            }
            pmci->batch_buffer_p = new_buffer_p;
        }
        /* Append the new commands. */
        memcpy(pmci->batch_buffer_p + pmci->batch_data_len, data, length);
        pmci->batch_data_len += length;

        LOG_STRING(LOG_TEST, _PMCI_PREFIX, 
                   "Batch buffer size = %"PRIu32"; data len = %"PRIu32,
                   pmci->batch_buffer_len, pmci->batch_data_len);
    }
    return results;
}

/* Check if the command is a set batch attribute command.  Always return the command length.
   Return true in *batch_cmd and attribute value in *batch_attr if the command is set
   batch attribute. */
static uint32_t _pmci_decode_batch_attr_cmd(void* cmd, bool* batch_cmd, uint32_t* batch_attr)
{
    uint32_t length;
    pmp_header_t *header = cmd;
    pmp_attribute_set_request_msg_t* set_req;
    *batch_cmd = false;
    
    length = ntohl(header->msgLength);

    if ( header->msgType == pmp_attribute_set_request_msg_type_e )
    {
        set_req = (pmp_attribute_set_request_msg_t *)header;
        if ( ntohl(set_req->attributeId) == pmp_batch_attr_id_e )
        {
             *batch_cmd = true;
             *batch_attr = set_req->attributeValue.batchAttr;
        }
    }
    return length;
}

static void _pmci_dump_object(pmci_obj_t *pmci, log_log_Level_t level)
{
    LOG_STRING(level, _PMCI_PREFIX, "magic       = 0x%x", pmci->magic);
    LOG_STRING(level, _PMCI_PREFIX, "pid         = %d",  pmci->pid);
    LOG_STRING(level, _PMCI_PREFIX, "handle      = %p", pmci->handle);
    LOG_STRING(level, _PMCI_PREFIX, "pmd         = %d", pmci->pmd);
    LOG_STRING(level, _PMCI_PREFIX, "channel     = %d", pmci->channel);
    LOG_STRING(level, _PMCI_PREFIX, "scan        = %d", pmci->scan);
    LOG_STRING(level, _PMCI_PREFIX, "stats       = %d", pmci->stats);
    LOG_STRING(level, _PMCI_PREFIX, "proxy:");
    LOG_STRING(level, _PMCI_PREFIX, "  producer  = %d", pmci->proxy.producer);
    LOG_STRING(level, _PMCI_PREFIX, "  consumer  = %d", pmci->proxy.consumer);
    LOG_STRING(level, _PMCI_PREFIX, "sched       = %p", pmci->sched);
    LOG_STRING(level, _PMCI_PREFIX, "schedSize   = %d", pmci->schedSize);
    LOG_STRING(level, _PMCI_PREFIX, "schedNum    = %d", pmci->schedNum);
    if ( pmci->timeout == PMCI_INFINITE )
    {
        LOG_STRING(level, _PMCI_PREFIX, "timeout     = PMCI_INFINITE");
    }
    else
    {
        LOG_STRING(level, _PMCI_PREFIX, "timeout     = %d", pmci->timeout);
    }
    LOG_STRING(level, _PMCI_PREFIX, "exclusive   = %"PRIu32, pmci->exclusive);
    LOG_STRING(level, _PMCI_PREFIX, "batch       = %"PRIu32, pmci->batch);
    LOG_STRING(level, _PMCI_PREFIX, "batch_buffer_p   = 0x%p", pmci->batch_buffer_p);
    LOG_STRING(level, _PMCI_PREFIX, "batch_buffer_len = %"PRIu32, pmci->batch_buffer_len);
    LOG_STRING(level, _PMCI_PREFIX, "batch_data_len   = %"PRIu32, pmci->batch_data_len);
    LOG_STRING(level, _PMCI_PREFIX, "batch_buffer_threshold = %"PRIu32, 
               pmci->batch_buffer_threshold);

    LOG_STRING(level, _PMCI_PREFIX, "Memory Dump:");
    LOG_MEMORY_DUMP(level, _PMCI_PREFIX, pmci, sizeof(pmci_obj_t));
}

static void _pmciDumpVersion(log_log_Level_t level, uint8_t version)
{
    if ( version == PMP_CURRENT_VERSION )
    {
        LOG_STRING(level, _PMCI_PREFIX, "   Version = pmp_current_version(%d)",
                   version);
    }
    else
    {
        LOG_STRING(level, _PMCI_PREFIX, "   Version = pmp_unknown_version(%d)",
                   version);
    }
}

static void _pmciDumpType(log_log_Level_t level, uint8_t type)
{
    switch (type)
    {
    case pmp_table_read_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_table_read_request_msg_type_e(%d)", type);
        break;
    case pmp_table_read_reply_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_table_read_reply_msg_type_e(%d)", type);
        break;
    case pmp_table_write_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_table_write_request_msg_type_e(%d)", type);
        break;
    case pmp_table_reset_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_table_reset_request_msg_type_e(%d)", type);
        break;
    case pmp_attribute_get_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_attribute_get_request_msg_type_e(%d)", type);
        break;
    case pmp_attribute_get_reply_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_attribute_get_reply_msg_type_e(%d)", type);
        break;
    case pmp_attribute_set_request_msg_type_e:
        LOG_STRING(level, 
                   _PMCI_PREFIX,
                   "   Type    = pmp_attribute_set_request_msg_type_e(%d)",
                   type);
        break;
    case pmp_ctx_by_session_id_clear_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_ctx_by_session_id_clear_request_msg_type_e(%d)",
                   type);
        break;
    case pmp_ctx_by_rule_id_clear_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_ctx_by_rule_id_clear_request_msg_type_e(%d)",
                   type);
        break;
    case pmp_ctx_all_clear_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_ctx_all_clear_request_msg_type_e(%d)", type);
        break;
    case pmp_error_indication_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_error_indication_msg_type_e(%d)", type);
        break;
    case pmp_data_scan_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_data_scan_msg_type_e(%d)", type);
        break;
    case pmp_scan_report_indication_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   Type    = pmp_scan_report_indication_msg_type_e(%d)", type);
        break;
    default:
        LOG_STRING(level, _PMCI_PREFIX, "   Type    = pmp_null_msg_type_e(%d)",
                   type);
        break;
    }
}

static void _pmciDumpLength(log_log_Level_t level, uint32_t length)
{
    LOG_STRING(level, _PMCI_PREFIX, "   Length  = %d (0x%x)",
               (int)length, (int)length);
}

static void _pmciDumpMsgId(log_log_Level_t level, uint64_t msgId)
{
    LOG_STRING(level, _PMCI_PREFIX, "   MsgId   = 0x%"PRIx64, msgId);
}

static void _pmciDumpTableId(log_log_Level_t level, uint32_t tableId)
{
    switch(tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_one_byte_trigger"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_two_byte_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_two_byte_trigger"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_variable_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_variable_trigger"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_confidence_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_confidence_table_id_e"
                   "(%d)", tableId);
        break;
    case pmp_confirmation_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_confirmation"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_user_defined_group_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_user_defined_group"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_equivalence_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_equivalence_table_id_e"
                   "(%d)", tableId);
        break;
    case pmp_session_context_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_session_context"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_special_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_special_trigger"
                   "TableId_e(%d)", tableId);
        break;
    default:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_null_table_id_e"
                   "(%d)", tableId);
        break;
    }
}

static void _pmci_dump_data(log_log_Level_t level, void *data, int length)
{
    LOG_STRING(level, _PMCI_PREFIX, "   Data    = (%d bytes follow)", length);
    if ( length > 512 )
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, data, 512);
        LOG_STRING(level, _PMCI_PREFIX, "   Data truncated at 512B");
    }
    else
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, data, length);
    }
}

static void _pmciDumpAttrId(log_log_Level_t level, uint32_t attrId)
{
    switch(attrId)
    {
    case pmp_statistics_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_statistics_attr_id_e(%d)", attrId);
        break;
    case pmp_hardware_revision_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_hardware_revision_attr_id_e(%d)", attrId);
        break;
    case pmp_protocol_revision_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_protocol_revision_attr_id_e(%d)", attrId);
        break;
    case pmp_atomic_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_atomic_attr_id_e(%d)", attrId);
        break;
    case pmp_batch_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_batch_attr_id_e(%d)", attrId);
        break;
    case pmp_sre_end_of_sui_index_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_sre_end_of_sui_index_attr_id_e(%d)", 
                   attrId);
        break;
    case pmp_variable_trigger_size_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_variable_trigger_size_attr_id_e(%d)", attrId);
        break;
    case pmp_confidence_chain_max_length_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_confidence_chain_max_length_attr_id_e(%d)", 
                   attrId);
        break;
    case pmp_sw_database_signature_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_sw_database_signature_attr_id_e(%d)", attrId);
        break;
    case pmp_drcc_selection_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = pmp_drcc_selection_attr_id_e(%d)", attrId);
        break;
    case pmp_extension_block_num_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_extension_block_num_attr_id_e(%d)", 
                   attrId);
        break;
    case pmp_context_max_num_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_context_max_num_attr_id_e(%d)", 
                   attrId);
        break;
    case pmp_context_area_size_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_context_area_size_attr_id_e(%d)", 
                   attrId);
        break;
    case pmp_max_stateful_rule_num_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_max_stateful_rule_num_attr_id_e(%d)", 
                   attrId);
        break;
    default:
        LOG_STRING(level, _PMCI_PREFIX, 
                   "   AttrId  = UNKNOWN(%d)", attrId);
        break;
    }
}

static void _pmci_decode_msg(log_log_Level_t level, pmp_header_t *header)
{
    pmp_table_read_reply_msg_t *readReq;
    pmp_table_write_request_msg_t *writeReq;
    pmp_table_reset_request_msg_t *resetReq;
    pmp_attribute_set_request_msg_t *setReq;
    pmp_attribute_get_request_msg_t *getReq;
    pmp_ctx_by_session_id_clear_request_msg_t *clearBySession;
    pmp_ctx_by_rule_id_clear_request_msg_t *clearByRule;

    /* Waste less time */
    if ( !log_is_log_level_enabled(level) ) return;

    LOG_STRING(level, _PMCI_PREFIX, "Command Decode");

    /* Dump the common header and next eight bytes as raw data */
    if ( header->msgLength > 128 )
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, header, 128);
    }
    else
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, header, header->msgLength);
    }

    /* Dump the common header */
    _pmciDumpVersion(level, header->protocolVersion);
    _pmciDumpType(level, header->msgType);
    _pmciDumpLength(level, header->msgLength);
    _pmciDumpMsgId(level, header->msgId);

    /* The rest of the message is specific for each command type */
    switch(header->msgType)
    {
    case pmp_table_read_request_msg_type_e:
    case pmp_table_read_reply_msg_type_e:
        readReq = (pmp_table_read_reply_msg_t *)header;
        _pmciDumpTableId(level, readReq->tableId);
        LOG_STRING(level, _PMCI_PREFIX, "   Index   = 0x%x", 
                   readReq->indexedEntry.index);
        if ( readReq->header.msgLength > sizeof(pmp_table_read_request_msg_t) )
        {
          LOG_STRING(level, _PMCI_PREFIX, "   Data    =");
          LOG_MEMORY_DUMP(level, _PMCI_PREFIX, &readReq->indexedEntry.entry,
                          header->msgLength - 
                          sizeof(pmp_table_read_request_msg_t));
        }
        break;
    case pmp_table_write_request_msg_type_e:
        writeReq = (pmp_table_write_request_msg_t *)header;
        _pmciDumpTableId(level, writeReq->tableId);
        LOG_STRING(level, _PMCI_PREFIX, "   Index   = 0x%x", 
                   writeReq->indexedEntry.index);
        _pmci_dump_data(level, &writeReq->indexedEntry.entry, 
                      writeReq->header.msgLength +
                      sizeof(pmp_table_entry_t) -
                      sizeof(pmp_table_write_request_msg_t));
        
        break;
    case pmp_table_reset_request_msg_type_e:
        resetReq = (pmp_table_reset_request_msg_t *)header;
        _pmciDumpTableId(level, resetReq->tableId);
        break;
    case pmp_attribute_get_request_msg_type_e:
    case pmp_attribute_get_reply_msg_type_e:
        getReq = (pmp_attribute_get_request_msg_t *)header;
        _pmciDumpAttrId(level, getReq->attributeId);
        break;
    case pmp_attribute_set_request_msg_type_e:
        setReq = (pmp_attribute_set_request_msg_t *)header;
        _pmciDumpAttrId(level, setReq->attributeId);
        LOG_STRING(level, _PMCI_PREFIX, "   AttrVal = 0x%x", 
                   *(int *)&setReq->attributeValue);
        break;
    case pmp_ctx_by_session_id_clear_request_msg_type_e:
        clearBySession = (pmp_ctx_by_session_id_clear_request_msg_t *)header;
        LOG_STRING(level, _PMCI_PREFIX, "   Session = 0x%x (%d)", 
                   clearBySession->sessionId,
                   clearBySession->sessionId);
        LOG_STRING(level, _PMCI_PREFIX, "   RuleCap = %d",
                   clearBySession->ruleCap);
        break;
    case pmp_ctx_by_rule_id_clear_request_msg_type_e:
        clearByRule = (pmp_ctx_by_rule_id_clear_request_msg_t *)header;
        LOG_STRING(level, _PMCI_PREFIX, "   FirstSes= 0x%x",
                   clearByRule->firstSessionId);
        LOG_STRING(level, _PMCI_PREFIX, "   Depth   = %d",
                   clearByRule->sessionDepth);
        LOG_STRING(level, _PMCI_PREFIX, "   NumSes  = %d",
                   clearByRule->numberOfSession);
        LOG_STRING(level, _PMCI_PREFIX, "   Rules   =");
        _pmci_dump_data(level, clearByRule->ruleIds, 
                      clearByRule->header.msgLength - 
                      sizeof(pmp_ctx_by_rule_id_clear_request_msg_t) -
                      sizeof(uint32_t));
        break;
    /* We may omit the following case statements as these all revert to
     * the default case.
     *
    case pmp_ctx_all_clear_msg_type_e:
    case pmp_error_indication_msg_type_e:
    case pmp_data_scan_msg_type_e:
    case pmp_scan_report_indication_msg_type_e:
     */
    default:
        if ( header->msgLength > sizeof(pmp_header_t) )
        {
            LOG_STRING(level, _PMCI_PREFIX, "   Data    =");
            LOG_MEMORY_DUMP(level, _PMCI_PREFIX, header->data,
                            header->msgLength - sizeof(pmp_header_t));
        }
        break;
    }
}

#ifdef PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES
static void _pmci_decode_all_msg(log_log_Level_t level, pmp_header_t *header, 
                              int length)
{
    pmp_header_t *msg;
    void *start = header;
    void *end = start + length;

    /**********************************************************************
     * WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING 
     * For performance, we might want to skip this as it is time consuming
     * not necessary for the proper functioning of the control interface.
     **********************************************************************/

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "***** START OF DECODE *****");
    while (start < end)
    {
        msg = (pmp_header_t *)start;
        _pmci_decode_msg(level, msg);
        start += ntohl(msg->msgLength);
    }
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "****** END OF DECODE ******");

}
#endif /* PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES */

/**********************************************************************
 * Description:
 *    This function provides the highest valid index for a given table
 *
 * Parameters:
 *    pmci    - pmci object
 *    tableId - Table identifier for which to compute the maximum index value
 *
 * Return:
 *    Maximum index value that is valid for the specified table identifier
 **********************************************************************/
int _pmci_max_index_get(pmci_obj_t *pmci, pmp_table_id_t tableId)
{
    uint32_t value;
    switch (tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        return PMP_ONE_BYTE_TRIGGER_ENTRY_MAX_INDEX;
        break;
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_MAX_INDEX;
        break;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_MAX_INDEX;
        break;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_MAX_INDEX;
        break;
    case pmp_confirmation_table_id_e:
        if ( _pmci_get_config_attr(pmci, pmp_extension_block_num_attr_id_e, 
                                   &value) != pmci_success_e )
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to get "
                       "extensionBlockNum");
            return 0;
        }
        /* ConfirmationEntryMaxIndex = ConfirmationEntryNum - 1 */
        return ((int)value - 1);         
        break;
    case pmp_user_defined_group_table_id_e:
        return PMP_USER_DEFINED_GROUP_ENTRY_MAX_INDEX;
        break;
    case pmp_equivalence_table_id_e:
        return PMP_EQUIVALENCE_ENTRY_MAX_INDEX;
        break;
    case pmp_session_context_table_id_e:
        if ( _pmci_get_config_attr(pmci, pmp_context_max_num_attr_id_e, &value) !=
             pmci_success_e )
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to get sessionNum");
            return 0;
        }
        /* SessionContextEntryMaxIndex = SessionEntryNum - 1 */
        return ((int)value - 1);
        break;
    case pmp_special_trigger_table_id_e:
        return PMP_SPECIAL_TRIGGER_ENTRY_MAX_INDEX;
        break;
    default:
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid tableId %d", tableId);
        return 0;
        break;
    } /* switch */

    return 0;
} /* pmciMaxIndexGet */

/**********************************************************************
 * Description:
 *    This function provides the record size to use in the message
 *    protocol for a given table identifier.  The returned value
 *    represent the size of the data portion of the message that is
 *    sent to the PM hardware.
 *
 * Parameters:
 *    tableId - Table identifier for which to compute the record size value
 *
 * Return:
 *    Record size associated to the specified table identifier.
 **********************************************************************/
int _pmci_record_size_get(pmp_table_id_t tableId)
{
    switch (tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        return PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_SIZE;
        break;
    case pmp_confirmation_table_id_e:
        return PMP_CONFIRMATION_ENTRY_SIZE;
        break;
    case pmp_user_defined_group_table_id_e:
        return PMP_USER_DEFINED_GROUP_ENTRY_SIZE;
        break;
    case pmp_equivalence_table_id_e:
        return PMP_EQUIVALENCE_ENTRY_SIZE;
        break;
    case pmp_session_context_table_id_e:
        /* The session contexts are read by cache line offset */
        return PMP_SESSION_CONTEXT_ENTRY_SIZE;
        break;
    case pmp_special_trigger_table_id_e:
        return PMP_SPECIAL_TRIGGER_ENTRY_SIZE;
        break;
    default:
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid tableId %d", tableId);
        return 0;
        break;
    } /* switch */

    return 0;
} /* pmciRecordSizeGet */

int pmci_context_clear_by_session_id(uint32_t sessionId)
{
    handle_t pmci_handle;
    pmp_ctx_by_session_id_clear_request_msg_t clearReq;
    pmci_error_t status;
    int channel = PMCI_DEFAULT_CHANNEL;
    uint32_t sessionNum;

    /* Verify access to PMCI and PMD modules */
    status = pmci_open(channel, &pmci_handle);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't access PMCI module "
                   "(%d:%s)", status, pmci_error_string(status));
        return pmci_unavailable_driver_e;
    }
    
    if ( _pmci_get_config_attr(pmci_handle, pmp_context_max_num_attr_id_e, &sessionNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionNum");
        pmci_close(pmci_handle);
        return pmci_failure_e;
    }

    /* Verify that the specified sessionId is valid */
    if ( (sessionId == 0) || (sessionId >= sessionNum) )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Session 0x%x is invalid",
                   (int)sessionId);
        pmci_close(pmci_handle);
        return pmci_invalid_parameters_e;
    }

    /* Prepare the message to clear the context */
    memset(&clearReq, 0, sizeof(clearReq));
    clearReq.header.protocolVersion = PMP_CURRENT_VERSION;
    clearReq.header.msgType         = pmp_ctx_by_session_id_clear_request_msg_type_e;
    clearReq.header.reserved        = 0;
    clearReq.header.msgLength       = htonl(sizeof(clearReq));
    clearReq.header.msgId           = (uintptr_t)pmci_handle;
    clearReq.sessionId              = htonl(sessionId);
    clearReq.ruleCap                = 0;

    /* Send the request */
    status = pmci_write(pmci_handle, &clearReq, sizeof(clearReq));
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't send clear request "
                   "(%d:%s)", status, pmci_error_string(status));
        pmci_close(pmci_handle);
        return status;
    }

    /* Wait until the request has been completed */
    status = pmci_flush(pmci_handle);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't complete clear request "
                   "(%d:%s)", status, pmci_error_string(status));
        pmci_close(pmci_handle);
        return status;
    }
         
    status = pmci_close(pmci_handle);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't close pmci handle "
                   "(%d:%s)", status, pmci_error_string(status));
        return status;
    }
    return pmci_success_e;
}
