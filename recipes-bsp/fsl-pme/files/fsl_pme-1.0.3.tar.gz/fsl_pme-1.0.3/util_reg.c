/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"
#include <driver.h>

int reg(UNUSED(int, argc), UNUSED(char **, argv));
int cds(UNUSED(int, argc), UNUSED(char **, argv));

#if 0
static int usage(int verbose, int retval)
{
	fprintf(stderr, "%sreg <device> <offset> [value]\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose)
		fprintf(stderr, "%s    set if [value], otherwise get\n",
				USAGE_CLEAR);
	return retval;
}
static int cds_usage(int verbose, int retval)
{
	fprintf(stderr, "%scds <offset> [value]\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose)
		fprintf(stderr, "%s    set if [value], otherwise get\n",
				USAGE_CLEAR);
	return retval;
}
#endif


int reg(UNUSED(int, argc), UNUSED(char **, argv))
{
#if 0
	struct pm_register r;
	int fd;

	if(argc < 0) return usage(1, 0);
	if((argc < 3) || (argc > 4))
		return usage(0, -1);
	if(parse_uint(argv[2], &r.offset, "offset"))
		return usage(0, -1);
	if((argc == 4) && parse_uint(argv[3], &r.value, "value"))
		return usage(0, -1);
	if((fd = open(argv[1], O_RDONLY)) < 0) {
		perror("Couldn't open device");
		return usage(0, -1);
	}
	if(argc == 3) {
		if(ioctl(fd, PME_IOCTL_GETREG, &r)) {
			perror("PME_IOCTL_GETREG failed");
			return usage(0, -1);
		}
		printf("GETREG(%s,0x%04x) -> 0x%08x\n", argv[1],
				r.offset, r.value);
		return 0;
	}
	if(ioctl(fd, PME_IOCTL_SETREG, &r)) {
		perror("PME_IOCTL_SETREG failed");
		return usage(0, -1);
	}
	printf("SETREG(%s,0x%04x) <- 0x%08x\n", argv[1], r.offset, r.value);
	return 0;
#else
	return -ENOSYS;
#endif
}
int cds(UNUSED(int, argc), UNUSED(char **, argv))
{
#if 0
	struct pm_register r;
	int fd;

	if(argc < 0) return cds_usage(1, 0);
	if((argc < 2) || (argc > 3))
		return cds_usage(0, -1);
	if(parse_uint(argv[1], &r.offset, "offset"))
		return cds_usage(0, -1);
	if((argc == 3) && parse_uint(argv[2], &r.value, "value"))
		return cds_usage(0, -1);
	if((fd = open(PME_CTRL_PATH, O_RDONLY)) < 0) {
		perror("Couldn't open device");
		return cds_usage(0, -1);
	}
	if(argc == 2) {
		if(ioctl(fd, PME_IOCTL_GETREG_CDS, &r)) {
			perror("PME_IOCTL_GETREG_CDS failed");
			return cds_usage(0, -1);
		}
		printf("GETREG_CDS(0x%04x) -> 0x%08x\n", r.offset, r.value);
		return 0;
	}
	if(ioctl(fd, PME_IOCTL_SETREG_CDS, &r)) {
		perror("PME_IOCTL_SETREG_CDS failed");
		return cds_usage(0, -1);
	}
	printf("SETREG_CDS(0x%04x) <- 0x%08x\n", r.offset, r.value);
	return 0;
#else
	return -ENOSYS;
#endif
}
