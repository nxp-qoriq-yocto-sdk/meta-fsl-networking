/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaCommon.c
 *
 * Description:
 *   This file implements the common portion of the Pattern Matching Loader 
 *   Agent API implementations.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmla.h>
#include <log.h>
#include <string.h>
#include <generic_types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

/**********************************************************************
 * Private types
 **********************************************************************/

typedef struct
{
    PmlaError_t code;
    char *string;
} PmlaErrorString_t;

/* Module prefix */
#define _PMLA_PREFIX "pmla"

/* Minimum string length to best describes a target structure */
#define PMLA_MIN_TARGET_FIXED  25

/* Special error indexes */
#define PMLA_UNKNOWN_ERROR_INDEX    (pmlaErrorFirst_c-2)
#define PMLA_UNKNOWN_SUCCESS_INDEX  (pmlaErrorFirst_c-3)
#define PMLA_END_OF_LIST_CODE       0
#define PMLA_UNKNOWN_CODE           -1

/**********************************************************************
 * Global variables
 **********************************************************************/

/* Table of error message used to convert error code to a string */
static PmlaErrorString_t _pmlaErrorStrings[] = {
    { pmlaSuccess_c            , "The operation completed with success" },
    { pmlaOutOfMemory_c        , "Can't allocate memory" },
    { pmlaInvalidTarget_c      , "Target structure badly populated" },
    { pmlaInvalidHandle_c      , "Invalid Loader Agent handle specified" },
    { pmlaNotConnected_c       , "Currently not connected to target" },
    { pmlaAlreadyConnected_c   , "Already connected to target" },
    { pmlaInvalidOptionCode_c  , "Invalid option code specified" },
    { pmlaInvalidOptionValue_c , "Invalid option value specified" },
    { pmlaInvalidOptionSize_c  , "Invalid option size specified" },
    { pmlaUnavailableOption_c  , "Wrong option for current state" },
    { pmlaConnectFailure_c     , "Loader Agent cannot connect to target" },
    { pmlaBulkInProgress_c     , "Bulk hint already provided" },
    { pmlaNotInBulkState_c     , "Bulk hint was not provided" },
    { pmlaNoBufferProvided_c   , "Data buffer is NULL" },
    { pmlaBufferSizeError_c    , "Data buffer size is too big" },
    { pmlaInvalidTimeout_c     , "Timout value is out of range" },
    { pmlaLostConnectivity_c   , "Lost connectivity with the target" },
    { pmlaTransportError_c     , "Some kind of transport error" },
    { pmlaCantDestroy_c        , "Error while destroying the object" },
    { pmlaTargetHwFailure_c    , "Remote target got a hardware failure" },
    { pmlaTargetSwFailure_c    , "Remote target got a software failure" },
    { pmlaUnrecoverableError_c , "Unrecoverable software error" },
    { pmlaTimedOut_c           , "Operation timed out" },
    { pmlaTargetHwUnavailable_c, "Remote target hardware is unavailable" },
    { pmlaInvalidCommand_c     , "Specified PMP command is invalid" },
    { pmlaInvalidNotification_c, "Received PMP notification is invalid" },
    { pmlaBufferPending_c      , "Receive buffer currently pending" },
    { PMLA_END_OF_LIST_CODE    , NULL },
    { PMLA_UNKNOWN_CODE        , "Unknown error code" },
    { PMLA_UNKNOWN_CODE        , "Unknown success code" }
};

/**********************************************************************
 * API Implementation
 **********************************************************************/

PmlaError_t pmlaTargetString ( PmlaTarget_t *target, char *stringBuffer )
{
    size_t offset;
    struct sockaddr_in *inetAddr;
    struct sockaddr_un *unixAddr;

    /* Sanitize the parameters */
    if ( target == NULL )
    {
        return pmlaInvalidHandle_c;
    }
    if ( stringBuffer == NULL )
    {
        return pmlaNoBufferProvided_c;
    }

    /* Convert the target into a tring */
    switch (target->addr.sa_family)
    {
    case AF_INET:
        inetAddr = (struct sockaddr_in *)&target->addr;
        sprintf(stringBuffer, "CHANNEL(%d) INET(%s:%d)",
                target->channel,
                inet_ntoa(inetAddr->sin_addr),
                ntohs(inetAddr->sin_port));
        break;
    case AF_UNIX:
        unixAddr = (struct sockaddr_un *)&target->addr;
        offset = PMLA_TARGET_STRING_MIN_SIZE - PMLA_MIN_TARGET_FIXED;
        if ( strlen(unixAddr->sun_path) > offset )
        {
            /* Need to truncate the file name */
            sprintf(stringBuffer, "CHANNEL(%d) UNIX(...%s)",
                    target->channel,
                    &unixAddr->sun_path[PMLA_TARGET_STRING_MIN_SIZE-offset]);
        }
        else
        {
            /* We're free to put the whole file name */
            sprintf(stringBuffer, "CHANNEL(%d) UNIX(%s)",
                    target->channel,
                    unixAddr->sun_path);
        }
        break;
    case AF_UNSPEC:
        sprintf(stringBuffer, "CHANNEL(%d) UNSPECIFIED()",
                target->channel);
        break;
    default:
        sprintf(stringBuffer, "INVALID");
        break;
    }

    return pmlaSuccess_c;
}

const char *pmlaErrorString ( PmlaError_t code )
{
    int codeIndex;

    /* Validate the error code */
    if ( code < pmlaErrorFirst_c )
    {
        return _pmlaErrorStrings[abs(PMLA_UNKNOWN_ERROR_INDEX)].string;
    }
    if ( code > pmlaErrorLast_c )
    {
        return _pmlaErrorStrings[abs(PMLA_UNKNOWN_SUCCESS_INDEX)].string;
    }

    /* Here we could either walk into the table or use the absolute value of
     * the error code as an index.  For now, we just take the absolute value.
     */
    codeIndex = abs(code);

    /* Ensure the chosen index matches with the error code */
    if ( code != _pmlaErrorStrings[codeIndex].code )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Error code mismatch (%d/%d)",
                   code, _pmlaErrorStrings[codeIndex].code);
        return _pmlaErrorStrings[abs(pmlaUnrecoverableError_c)].string;
    }

    /* Return the corresponding error code */
    return _pmlaErrorStrings[codeIndex].string;
}
