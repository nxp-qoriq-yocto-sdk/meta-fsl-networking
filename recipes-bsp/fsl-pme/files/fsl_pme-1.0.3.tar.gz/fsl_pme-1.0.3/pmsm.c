/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmsm.c
 *
 * Description:
 *   This file holds the Pattern Matching Statistics Manager implementation
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmsm.h>
#include <pmapp.h>
#include <log.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <driver.h>

/**********************************************************************
 * Macros
 **********************************************************************/

/* Logging prefix */
#define PMSM_PREFIX              "pmsm"

/* Daemon arguments */
#define PMSM_ARG_HELP            "--help"
#define PMSM_ARG_DEBUG           "--debug"
#define PMSM_ARG_POLLING         "--polling"
#define PMSM_ARG_POLLING_VALUE   "<interval>"
#define PMSM_ARG_LOGGING         "--log-file"
#define PMSM_ARG_LOGGING_VALUE   "[<fileName>]"
#define PMSM_ARG_LOGGING_PID     "<pid>"
#define PMSM_ARG_STDOUT          "--log-stdout"
#define PMSM_ARG_LEVEL           "--log-level"
#define PMSM_ARG_LEVEL_VALUE     "<logMask>"

/* Polling period (in milliseconds) */
#define PMSM_POLLING_PERIOD      6000

/* Default logging file */
#define PMSM_DEFAULT_LOG_FILE    "/tmp/pmsmd.%s.log"

/* Maximum logging file length */
#define PMSM_MAX_LOG_FNAME_SIZE  80

/**********************************************************************
 * Types
 **********************************************************************/

typedef struct
{
    bool               logOnFile;
    bool               destroyed;
    int                polling;
    pthread_t          pollingTid;
    pthread_mutex_t    mutex;
    int                driver;
    int                connection;
    PmsmKesStats_t     curKes;
    PmsmDxeStats_t     curDxe;
    PmsmSreStats_t     curSre;
    PmsmDeflateStats_t curDeflate;
} PmsmObj_t;

/**********************************************************************
 * Globals
 **********************************************************************/

static PmsmObj_t _obj;

/**********************************************************************
 * Private declaration
 **********************************************************************/

static int   _help(char *cmd, char *text, bool full);
static int   _processArguments(PmsmObj_t *obj, int argn, char *args[]);
static int   _checkAndOpenDriver(PmsmObj_t *obj);
static void  _signalKillHandler(int sigNum);
static int   _createResources(PmsmObj_t *obj);
static void *_pollingThread(void *arg);
static void *_connectingThread(void *arg);

static void  _updateKesStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws);
static void  _updateDxeStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws);
static void  _updateSreStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws);
static void  _updateDeflateStats(PmsmObj_t *obj,struct pme_ctrl_stats *hws);

/**********************************************************************
 * Implementation
 **********************************************************************/

int main (int argn, char *args[])
{
    /* Sanitize the arguments */
    if ( _processArguments(&_obj, argn, args) < 0 )
    {
        return _help(args[0], "Invalid arguments", false);
    }

    /* Check availability of the driver and grabbing an handle to it */
    if ( _checkAndOpenDriver(&_obj) < 0 )
    {
        return _help(args[0], "Can't access the driver", false);
    }

    /* Daemonize the process */
    if ( daemon(!_obj.logOnFile, !_obj.logOnFile) < 0 )
    {
        return _help(args[0], "Can't detach from terminal", false);
    }

    LOG_STRING(LOG_INFO, PMSM_PREFIX, "Starting PMSM daemon");

    /* Hook to the various signals that can kill the daemon */
    signal(SIGINT,  _signalKillHandler);
    signal(SIGSTOP, _signalKillHandler);
    signal(SIGTERM, _signalKillHandler);
    signal(SIGKILL, _signalKillHandler);

    /* Create the resources needed by both threads */
    if ( _createResources(&_obj) < 0 )
    {
        return _help(args[0], "Can't create daemon resources", false);
    }

    /* Kill off the polling thread */
    if ( pthread_create(&_obj.pollingTid, NULL, _pollingThread, &_obj) )
    {
        LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Can't create polling thread!");
        exit(0);
    }
    
    /* Kill off the connecting thread */
    _connectingThread(&_obj);

    return 0;
}

/**********************************************************************
 * Private implementation
 **********************************************************************/

static int _help(char *cmd, char *text, bool full)
{
    if ( text != NULL )
    {
        printf("Error:   %s\n", text);
    }
    printf("Syntax:  %s [%s] [%s] [%s %s]\n"
           "         [%s %s] [%s %s] [%s]\n",
           cmd,
           PMSM_ARG_HELP,
           PMSM_ARG_DEBUG,
           PMSM_ARG_POLLING, PMSM_ARG_POLLING_VALUE,
           PMSM_ARG_LOGGING, PMSM_ARG_LOGGING_VALUE,
           PMSM_ARG_LEVEL, PMSM_ARG_LEVEL_VALUE,
           PMSM_ARG_STDOUT);
    printf("Options: \n");
    if ( full )
    {
        printf("    %s\n", PMSM_ARG_HELP);
        printf("         Display this screen but not spawn off the daemon.\n");
        printf("    %s\n", PMSM_ARG_DEBUG);
        printf("         Optional argument that enable all log levels.  It\n"
               "         is equivalent of using --log-level -1 argument.\n");
        printf("    %s %s\n", PMSM_ARG_POLLING, PMSM_ARG_POLLING_VALUE);
        printf("         By default, the statistics manager polls the PM\n"
               "         hardware once every %d ms in order to prevent from\n"
               "         statistics rollover.  This option argument allows\n"
               "         to override that using the %s argument\n"
               "         expressed in ms.\n", 
               PMSM_POLLING_PERIOD, PMSM_ARG_POLLING_VALUE);
        printf("    %s %s\n", PMSM_ARG_LOGGING, PMSM_ARG_LOGGING_VALUE);
        printf("         By default, all logs are stored in the file\n"
               "         " PMSM_DEFAULT_LOG_FILE ".  This optional argument\n"
               "         allows to redirect the logs to a different file.\n"
               "         If the file name value is omitted, the default file\n"
               "         name is used.\n", PMSM_ARG_LOGGING_PID);
        printf("    %s %s\n", PMSM_ARG_LEVEL, PMSM_ARG_LEVEL_VALUE);
        printf("         This optional argument specifies the log level.\n");
        printf("    %s\n", PMSM_ARG_STDOUT);
        printf("         By defaults, all log output is writtent to a file.\n"
               "         This option argument instructs the daemon to dump\n"
               "         all log output onto standard output (aka stdout).\n"
               "         Note however that by dumping the logs on stdout,\n"
               "         the daemon cannot fully detach itself from the\n"
               "         calling shell.  When using this option, exiting\n"
               "         from the calling shell will hang until the daemon\n"
               "         terminates.\n");
    }
    else
    {
        printf("    Use --help for more information.\n");
    }

    return 0;
}

static int _processArguments(PmsmObj_t *obj, int argn, char *args[])
{
    int arg = 1;
    bool useStdout = false;
    char logFile[PMSM_MAX_LOG_FNAME_SIZE];
    char myPid[10];
    int level = PMAPP_DefaultLogLevel_d;

    /* Make sure we start with a fresh object */
    memset(obj, 0, sizeof(PmsmObj_t));
    obj->polling = PMSM_POLLING_PERIOD;
    sprintf(myPid, "%d", getpid());
    sprintf(logFile, PMSM_DEFAULT_LOG_FILE, myPid);

    /* Processes all arguments */
    while ( arg < argn )
    {
        if ( strcmp(args[arg], PMSM_ARG_HELP) == 0 )
        {
            _help(args[0], NULL, true);
            exit(0);
        }
        else if ( strcmp(args[arg], PMSM_ARG_DEBUG) == 0 )
        {
            log_mask_set(LOG_ALL);
        }
        else if ( strcmp(args[arg], PMSM_ARG_POLLING) == 0 )
        {
            arg++;

            if ( (arg < argn) && (args[arg][0] != '-') )
            {
                obj->polling = atoi(args[arg]);
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "Using polling interval "
                           "of %d ms", obj->polling);
            }
            else
            {
                printf ("Invalid polling period %s\n", args[arg]);
                return -1;
            }
        }
        else if ( strcmp(args[arg], PMSM_ARG_LOGGING) == 0 )
        {
            /* Log file name is optional */
            useStdout = false;

            /* Check to see if there is a file name specified */
            if ( ((arg+1) < argn) &&
                 (args[arg+1] != NULL) &&
                 (args[arg+1][0] != '-') &&
                 (args[arg+1][1] != '-') &&
                 (strlen(args[arg+1]) < (PMSM_MAX_LOG_FNAME_SIZE-1)) )
            {
                arg++;
                sprintf(logFile, "%s", args[arg]);
            }
        }
        else if ( strcmp(args[arg], PMSM_ARG_LEVEL) == 0 )
        {
            /* Ensure next argument is present */
            if ( (arg+1) >= argn )
            {
                printf("No value for %s\n", args[arg]);
                return -1;
            }

            /* Move index to actual argument */
            arg++;

            /* Check for a valid log level */
            if ( (args[arg][0] == '0') &&
                 (args[arg][1] == 'x') )
            {
                if ( (!isxdigit(args[arg][2])) ||
                     (strlen(args[arg]) <= 2) )
                {
                    printf("Invalid hex log level %s\n", args[arg]);
                    return -1;
                }

                /* Hex log level */
                sscanf(&args[arg][2], "%x", &level);
            }
            else if ( (isdigit(args[arg][0])) ||
                      ((args[arg][0] == '-') && (isdigit(args[arg][1]))) )
            {
                /* Dec log level */
                sscanf(args[arg], "%d", &level);
            }
            else
            {
                /* Invalid log level */
                printf ("Invalid log level %s\n", args[arg]);
                return -1;
            }
        }
        else if ( strcmp(args[arg], PMSM_ARG_STDOUT) == 0 )
        {
            /* Forces all output to stdout */
            useStdout = true;
        }
        else
        {
            printf ("Unknown argument %s\n", args[arg]);
            return -1;
        }

        arg++;
    }


    /* Apply the desired log level */
    log_mask_set(level);

    /* Set the log output location */
    if ( useStdout )
    {
        obj->logOnFile = false;
    }
    else
    {
        if ( log_log_to_file(logFile) == HANDLE_NULL )
        {
            printf ("Warning, cannot write to %s.  Redirecting to stdout.\n",
                    logFile);
            log_handle_set(stdout);
            obj->logOnFile = false;
        }
        else
        {
            obj->logOnFile = true;
        }
    }

    return 0;
}

static int _checkAndOpenDriver(PmsmObj_t *obj)
{
    int fd;

    /* Attempt to acquire a handle of the driver */
    fd = open(PME_CTRL_PATH, O_RDWR);
    if ( fd < 0 )
    {
        return -1;
    }

    /* Keep a copy of the handle */
    obj->driver = fd;

    return 0;
}

static void _signalKillHandler(int sigNum)
{
    LOG_STRING(LOG_TEST, PMSM_PREFIX, "Interrupted by signal %d", sigNum);

    /* Ensure we're not destroying more than once */
    if ( _obj.destroyed )
    {
        return;
    }
    _obj.destroyed = true;

    /* Close the listen socket */
    if ( close(_obj.connection) < 0 )
    {
        LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't destroy connection socket");
    }

    /* Close the driver handle */
    if ( close(_obj.driver) < 0 )
    {
        LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't destroy driver handle");
    }

    /* Destroy the mutex */
    if ( pthread_mutex_destroy(&_obj.mutex) != 0 )
    {
        LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't destroy mutex");
    }

    /* Remove socket file */
    if ( remove(PMSM_SOCK_PATH) < 0 )
    {
        LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't remove socket file");
    }

    LOG_STRING(LOG_INFO, PMSM_PREFIX, "Stopping PMSM daemon");
}

static int _createResources(PmsmObj_t *obj)
{
    struct sockaddr_un sun;

    /* Create semaphore */
    if ( pthread_mutex_init(&obj->mutex, NULL) < 0 )
    {
        LOG_STRING(LOG_INFO, PMSM_PREFIX, "Can't create mutex");
        return -1;
    }

    /* Ensure that previous socket file does not exists */
    if ( remove(PMSM_SOCK_PATH) >= 0 )
    {
        LOG_STRING(LOG_INFO, PMSM_PREFIX, "PMSM wasn't shutdown properly");
    }
    else
    {
        if ( errno != ENOENT )
        {
            LOG_STRING(LOG_INFO, PMSM_PREFIX, "remove():  %d=%s",
                       errno, strerror(errno));
        }
    }

    /* Create listen socket */
    obj->connection = socket(PMSM_SOCK_FAMILY, SOCK_STREAM, 0);
    if ( obj->connection < 0 )
    {
        LOG_STRING(LOG_INFO, PMSM_PREFIX, "Can't create listen socket");
        pthread_mutex_destroy(&obj->mutex);
        return -1;
    }
    
    /* Prepare the socket for listening to new calls */
    memset(&sun, 0, sizeof(sun));
    PMSM_SOCK_SET(sun, sizeof(sun));
    if ( bind(obj->connection, (struct sockaddr *)&sun, sizeof(sun)) < 0 )
    {
        LOG_STRING(LOG_INFO, PMSM_PREFIX, "Can't bind on listen socket");
        pthread_mutex_destroy(&obj->mutex);
        close(obj->connection);
        return -1;
    }
    if ( listen(obj->connection, 128) < 0 )
    {
        LOG_STRING(LOG_INFO, PMSM_PREFIX, "Can't listen on listen socket");
        pthread_mutex_destroy(&obj->mutex);
        close(obj->connection);
        return -1;
    }

    return 0;
}

static void *_pollingThread(void *arg)
{
    PmsmObj_t *obj = (PmsmObj_t *)arg;
    struct pme_ctrl_stats stats;
    uint32_t pollingPeriod = obj->polling;

    /* Clear the statistics */
    if ( ioctl(obj->driver, PME_CTRL_IOCTL_STATS, &stats) < 0 )
    {
        LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot reset statistics");
    }
    
    /* Keep polling to avoid rollovers */
    while(1)
    {
        /* Wait for next iteration to poll */
        if ( ioctl(obj->driver, PME_CTRL_IOCTL_SLEEP, &pollingPeriod) < 0 )
        {
            if ( !obj->destroyed )
            {
                LOG_STRING(LOG_WARNING, PMSM_PREFIX, 
                           "Cannot sleep for statistics");
            }
            exit(-1);
        }

        /* Ensure we're the only thread messing around */
        if ( pthread_mutex_lock(&obj->mutex) != 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot wait for mutex");
            exit(-1);
        }

        LOG_STRING(LOG_TEST, PMSM_PREFIX, "Polling hardware statistics");

        /* Pull in all known statistics */
        memset(&stats, 0, sizeof(stats));
        stats.flags = ( PME_CTRL_KES | PME_CTRL_DXE | PME_CTRL_SRE |
                        PME_CTRL_DEFLATE );
        if ( ioctl(obj->driver, PME_CTRL_IOCTL_STATS, &stats) < 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot acquire statistics");
            exit(-1);
        }

        /* Update the statistics */
        _updateKesStats(obj, &stats);
        _updateDxeStats(obj, &stats);
        _updateSreStats(obj, &stats);
        _updateDeflateStats(obj, &stats);

        /* Release the mutex */
        if ( pthread_mutex_unlock(&obj->mutex) != 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot wait for mutex");
            exit(-1);
        }
    }

    return NULL;
}

static void *_connectingThread(void *arg)
{
    PmsmObj_t *obj = (PmsmObj_t *)arg;
    struct pme_ctrl_stats stats;
    struct sockaddr_un sun;
    socklen_t sunSize = sizeof(sun);
    int client;
    uint8_t command;
    uint8_t group;

    /* Process incoming connection requests */
    while (1)
    {
        /* Wait for a new connection */
        client = accept(obj->connection, (struct sockaddr *)&sun, &sunSize);
        if ( client < 0 )
        {
            if (!obj->destroyed)
            {
                LOG_STRING(LOG_WARNING, PMSM_PREFIX, 
                           "Failed to accept connections");
            }
            exit(-1);
        }

        /* Read the command and stats code to figure out what to do */
        if ( recv(client, &command, sizeof(command), 0) < 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Failed to read command "
                       "code");
            exit(-1);
        }
        if ( recv(client, &group, sizeof(group), 0) < 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Failed to read group code");
            exit(-1);
        }

        /* Prepare the statistics query */
        memset(&stats, 0, sizeof(stats));
        if ( group & PMSM_GROUP_PM_KES )  stats.flags |= PME_CTRL_KES;
        if ( group & PMSM_GROUP_PM_DXE )  stats.flags |= PME_CTRL_DXE;
        if ( group & PMSM_GROUP_PM_SRE )  stats.flags |= PME_CTRL_SRE;
        if ( group & PMSM_GROUP_DEFLATE ) stats.flags |= PME_CTRL_DEFLATE;

        /* Acquire the mutex before querying the hardware */
        if ( pthread_mutex_lock(&obj->mutex) != 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot wait for mutex");
            exit(-1);
        }

        /* Poll the hardware for the stats we're interested in */
        if ( ioctl(obj->driver, PME_CTRL_IOCTL_STATS, &stats) < 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot acquire statistics");
            exit(-1);
        }
            
        /* Process the query */
        if ( command & PMSM_CMD_QUERY )
        {
            LOG_STRING(LOG_TEST, PMSM_PREFIX, "Polling hardware statistics");
            
            /* Update the statistics and write resutls */
            if ( group & PMSM_GROUP_PM_KES )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   KES");
                _updateKesStats(obj, &stats);
                if ( send(client, &obj->curKes, sizeof(obj->curKes), 0) < 0 )
                {
                    LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't write KES stats");
                }
            }
            if ( group & PMSM_GROUP_PM_DXE )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   DXE");
                _updateDxeStats(obj, &stats);
                if ( send(client, &obj->curDxe, sizeof(obj->curDxe), 0) < 0 )
                {
                    LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't write DXE stats");
                }
            }
            if ( group & PMSM_GROUP_PM_SRE )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   SRE");
                _updateSreStats(obj, &stats);
                if ( send(client, &obj->curSre, sizeof(obj->curSre), 0) < 0 )
                {
                    LOG_STRING(LOG_TEST, PMSM_PREFIX, "Can't write SRE stats");
                }
            }
            if ( group & PMSM_GROUP_DEFLATE )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   Deflate");
                _updateDeflateStats(obj, &stats);
                if ( send(client, &obj->curDeflate, 
                          sizeof(obj->curDeflate), 0) < 0 )
                {
                    LOG_STRING(LOG_TEST, PMSM_PREFIX, 
                               "Can't write Deflate stats");
                }
            }
        }
        
        if ( command & PMSM_CMD_RESET )
        {
            LOG_STRING(LOG_TEST, PMSM_PREFIX, "Reset software statistics");
            
            if ( group & PMSM_GROUP_PM_KES )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   KES");
                memset(&obj->curKes, 0, sizeof(obj->curKes));
            }
            if ( group & PMSM_GROUP_PM_DXE )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   DXE");
                memset(&obj->curDxe, 0, sizeof(obj->curDxe));
            }
            if ( group & PMSM_GROUP_PM_SRE )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   SRE");
                memset(&obj->curSre, 0, sizeof(obj->curSre));
            }
            if ( group & PMSM_GROUP_DEFLATE )
            {
                LOG_STRING(LOG_TEST, PMSM_PREFIX, "   Deflate");
                memset(&obj->curDeflate, 0, sizeof(obj->curDeflate));
            }
        }

        /* Release the mutex */
        if ( pthread_mutex_unlock(&obj->mutex) != 0 )
        {
            LOG_STRING(LOG_WARNING, PMSM_PREFIX, "Cannot wait for mutex");
            exit(-1);
        }

        /* Close the client connection */
        close(client);
    }

    return NULL;
}

static void _updateKesStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws)
{
    obj->curKes.inputByte             += hws->stnib;
    obj->curKes.inputSui              += hws->stnis;
    obj->curKes.triggerOneByteHit     += hws->stnth1;
    obj->curKes.triggerTwoByteHit     += hws->stnth2;
    obj->curKes.triggerVariableHit    += hws->stnthl;
    obj->curKes.triggerSpecialHit     += hws->stnths;
    obj->curKes.confidenceHit         += hws->stnch;
}

static void _updateDxeStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws)
{
    obj->curDxe.patternMatch          += hws->stnpm;
    obj->curDxe.suiMatch              += hws->stns1m;
    obj->curDxe.matchWithinDrcc       += hws->stnpmr;
}

static void _updateSreStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws)
{
    obj->curSre.dxeWithSrExecution    += hws->stndsr;
    obj->curSre.suiWithSrExecution    += hws->stnesr;
    obj->curSre.suiWithSrReport       += hws->stns1r;
    obj->curSre.reportByte            += hws->stnob;
}

static void _updateDeflateStats(PmsmObj_t *obj, struct pme_ctrl_stats *hws)
{
    obj->curDeflate.consumedByte      += hws->stdbc;
    obj->curDeflate.producedByte      += hws->stdbp;
    obj->curDeflate.consumedWorkUnit  += hws->stdwc;
}
