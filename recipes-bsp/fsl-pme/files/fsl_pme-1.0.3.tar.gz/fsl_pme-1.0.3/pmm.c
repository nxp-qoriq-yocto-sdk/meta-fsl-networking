/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : pmm_pmm.c
 *
 *   This file contains the implementation of the Pattern Matching
 *   Manager (PMM) module.
 *
 ****************************************************************************/




/*--------------------- Include Files -----------------------------*/

#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#include <cli.h>
#include <db.h>
#include <hndl.h>
#include <generic_types.h>
#include <idx.h>
#include <log.h>
#include <mem.h>
#include <pm_defs.h>
#include <pmapp.h>
#include <pmla.h>
#include <pmll.h>
#include <pmrec.h>
#include <pmsrc.h>





/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the prefix for the PMM module. */
#define _PMM_MODULE_NAME                   "PMM"


/* If overall debug mode is set to on, then turn on the PMM debug
 * functionality. */
#ifdef DEV_DBG
#  define PMM_DEBUG
#endif


/* This macro defines the default ping count. */
#define _PMM_DEFAULT_PING_COUNT            3


/* This macro defines the default name of the log file. */
#define _PMM_DEFAULT_LOG_FILE_NAME         ""


/* These two macros are used to control the intesity of the display. */
#define _PMM_HIGH_INTESITY_ON              "\033[1m"
#define _PMM_ALL_OFF                       "\033[0m"


/* The next definitions define the min() and max() macros.  Watch out
 * how you use them.  For example min = _PMM_MIN(i++, j++) will
 * increment the smaller counter twice. */
#define _PMM_MIN(x, y)                     ((x) < (y) ? (x) : (y))
#define _PMM_MAX(x, y)                     ((x) > (y) ? (x) : (y))


/* The next few macros display common command option strings. */
#define _PMM_QM_STRING_DISPLAY()                                              \
  fprintf(stdout, "\n\t%s"                                                    \
          "\n\t   Like the %s option; displays the synopsis of the command.", \
          _pmm_qm_keyword_sg, _pmm_h_keyword_sg);
#define _PMM_HSTRING_DISPLAY()                                                \
  fprintf(stdout, "\n\t%s"                                                    \
          "\n\t   Like the %s option; displays the synopsis of the command.", \
          _pmm_h_keyword_sg, _pmm_qm_keyword_sg);
#define _PMM_HELP_STRING_DISPLAY()                                            \
  fprintf(stdout, "\n\t%s"                                                    \
          "\n\t   Displays the help information for the command.",            \
          _pmm_help_keyword_sg);
#define _PMM_VERSION_STRING_DISPLAY()                                         \
  fprintf(stdout, "\n\t%s"                                                    \
          "\n\t   Indicates that a version of a sub-system is to be read.  "  \
          "\n\t   The following keyword indicates the sub-system to read "    \
          "\n\t   the version from.", _pmm_version_keyword_sg);
#define _PMM_HW_STRING_DISPLAY()                                              \
  fprintf(stdout, "\n\t%s"                                                    \
          "\n\t   Indicates that the operation should be carried out on the " \
          "\n\t   PM H/W.", _pmm_hw_keyword_sg);


/* The next macro defines the default size of data messages that are
 * sent to the PM H/W when scanning data for patterns. */
#define _PMM_DEFAULT_DATA_MSG_SIZE         8192


/* The next two macros define the size of the pmm name tables, e.g.,
 * the expression and rule name tables.  The factor macro is used to
 * determines the size of the name table.  The actual size of the name
 * table is  2 ^ _PMM_NAME_TABLE_SIZE_FACTOR, e.g., 2 ^ 10 = 1024.
 * The size is defined through such a factor so that the name hashing
 * factions can be adjusted automatically when the table size changes.
 * In the current implementation of the hash function used for the
 * names the maximum value for this macro is 16. */
#define _PMM_NAME_TABLE_SIZE_FACTOR        10
#define _PMM_NAME_TABLE_SIZE               (1 << _PMM_NAME_TABLE_SIZE_FACTOR)


/* This macro defines the maximum number of parameters in a CLI
 * command. */
#define _PMM_PARAM_MAX_NUM                 32


/* The next two macros define the maximum size of the expression and
 * option strings as supported by the PMM module. */
#define _PMM_EXP_STRING_MAX_SIZE           256
#define _PMM_EXP_OPTIONS_STRING_MAX_SIZE   256


/* The following macros define the arguments that the PMM application
 * supports. */
#define _PMM_CMD_ARG_PM_hw_simulation      "--hwsim"
#define _PMM_CMD_ARG_LONG_TARGET_CHANNEL   "--channel"
#define _PMM_CMD_ARG_SHORT_TARGET_CHANNEL  "-c"
#define _PMM_CMD_ARG_LONG_EXIT_ON_ERROR    "--exit-on-error"
#define _PMM_CMD_ARG_SHORT_EXIT_ON_ERROR   "-e"
#define _PMM_CMD_ARG_TARGET_ADDRESS        "--target"
#define _PMM_CMD_ARG_8572_REV_1_0          "--8572rev1.0"


/* This macro defines the timeout (in seconds) interval used to
 * receive all the PMLA messages. */
#define _PMM_PMLA_TIMOUT                   30


/* This macro defines the keep alive interval (in seconds) that the
 * PMLA module is configured with. */
#define _PMM_PMLA_KEEP_ALIVE_INTERVAL      60


/* The next few macros define the IPv4 address, IPv4 port and the ID
 * of the PM H/W channel to be used with the PMLA module to open a
 * connection to the PM H/W. */
#define _PMM_PMLA_TARGET_IP_ADDRESS        0x7f000001
#define _PMM_PMLA_TARGET_IP_PORT           12345


/* This macro defines the default PM H/W (DMA) channel ID. */
#define _PMM_PMLA_TARGET_CHANNEL_ID        0


/* This macro defines the initial number of the PMLL DB handles. */
#define _PMM_INITIAL_PMLL_HANDLE_TABLE_SIZE 128


/* This macro defines the NULL PMLL DB handle. */
#define _PMM_NULL_PMLL_DB_HANDLE           -1U


#define _PMM_NA_STATS ((uint64_t)0xffffffffffffffffLL)
#define _PMM_DISP_STATS(attrName, attrField)                               \
  if ( statistics.attrField == _PMM_NA_STATS ) {                           \
    fprintf(stdout, "   %s :            N/A            N/A   "             \
            "         N/A\n", attrName);                                   \
  } else {                                                                 \
    fprintf(stdout, "   %s :   %12"PRIu64"   %12"PRIu64"   %12"PRIu64"\n", \
            attrName,                                                      \
            PMP_PMHWTOHLL(statistics.attrField),                           \
            PMP_PMHWTOHLL(pmmDb_p->snapshot.attrField),                    \
            PMP_PMHWTOHLL(statistics.attrField) -                          \
            PMP_PMHWTOHLL(pmmDb_p->snapshot.attrField));                   \
  }










/*--------------------- Type Definitions---------------------------*/

/* This type holds all pmm application arguments. */
typedef struct {
  bool      hwSimFlagOptSetFlag;  /* hwSimFlag option set flag */
  bool      logLevelOptSetFlag;   /* logLevel option set flag */
  bool      logFileNameOptSetFlag;/* logFileName option set flag */
  bool      targetOptSetFlag;     /* target option set flag */

  bool      hwSimFlag;            /* simulate (in a limited way) the PM H/W */
  bool      exitOnErrorFlag;      /* make PMM exit upon an error. */
  uint32_t  logLevel;             /* log level */
  char     *logFileName_p;        /* name of the log file */
  uint32_t  targetIpv4Address;    /* IPv4 address of the target PM H/W */
  uint16_t  targetIpv4Port;       /* IPv4 port of the target PM H/W */
  uint32_t  targetChannelId;      /* channel of the target PM H/W */
  uint32_t  pmlaChannelTimeout;   /* PMLA channel timeout - used with reads */
  bool      option8572rev1_0Flag; /* Special compiler option set flag */
} _pmm_app_params_t;


/* This type is used to collect statistics while executing the match
 * command. */
typedef struct {
  uint64_t  counters[PM_PATTERN_MAX_NUM + 2];
} _pmm_pm_stats_t;


/* This type defines a name structure as used by the PMM functions.
 * The maximum length of a name is PM_NAME_MAX_LENGTH characters
 * including the terminating NULL character. */
typedef char  _pmm_name_t[PM_NAME_MAX_LENGTH];


/* This type defines the pmm expression record. */
typedef struct {
  char      exp_s[_PMM_EXP_STRING_MAX_SIZE];
  char      options_s[_PMM_EXP_OPTIONS_STRING_MAX_SIZE];
  uint32_t  pmmIndex;
  uint32_t  llIndex;
} _pmm_exp_record_t;


/* This type defines the pmm rule record. */
typedef struct {
  uint32_t     reactionNum;
  _pmm_name_t *reactionNames_p;
  uint32_t     pmmIndex;
  uint32_t     llIndex;
} _pmm_rule_record_t;


/* This type contains data associated with a PM database. */
typedef struct {
  unsigned int           llDbHandle;
  handle_t               pmlaForPmllHandle;
  handle_t               pmlaForPmmHandle;
  handle_t               expDbHandle;
  handle_t               ruleDbHandle;
  pmp_statistics_attr_t  snapshot;
  bool                   option8572rev1_0;
} _pmm_db_t;



  



/*--------------------- Global Data Definitions -------------------*/

/* The next few variables define the names of the commands available
 * in the Pattern Matching CLI. */
static const char *_pmm_add_cmd_sg                   = "add";
static const char *_pmm_commit_cmd_sg                = "commit";
static const char *_pmm_delete_cmd_sg                = "delete";
static const char *_pmm_ping_cmd_sg                  = "ping";
static const char *_pmm_reset_cmd_sg                 = "reset";
static const char *_pmm_read_cmd_sg                  = "read";
static const char *_pmm_set_cmd_sg                   = "set";
static const char *_pmm_show_cmd_sg                  = "show";


/* The next few variables define the keywords used in the CLI
 * commands. */
static const char *_pmm_all_keyword_sg               = "all";
static const char *_pmm_attribute_keyword_sg         = "attribute";
static const char *_pmm_attributes_keyword_sg        = "attributes";
static const char *_pmm_binary_keyword_sg            = "binary";
static const char *_pmm_count_keyword_sg             = "count";
static const char *_pmm_counter_keyword_sg           = "counter";
static const char *_pmm_equivalence_keyword_sg       = "equivalence";
static const char *_pmm_exp_keyword_sg               = "exp";
static const char *_pmm_file_keyword_sg              = "file";
static const char *_pmm_filename_keyword_sg          = "filename";
static const char *_pmm_h_keyword_sg                 = "h";
static const char *_pmm_help_keyword_sg              = "help";
static const char *_pmm_hw_keyword_sg                = "hw";
static const char *_pmm_ll_keyword_sg                = "ll";
static const char *_pmm_name_keyword_sg              = "name";
static const char *_pmm_options_keyword_sg           = "options";
static const char *_pmm_qm_keyword_sg                = "?";
static const char *_pmm_regex_keyword_sg             = "regex";
static const char *_pmm_report_keyword_sg            = "noreport";
static const char *_pmm_rule_keyword_sg              = "rule";
static const char *_pmm_set_keyword_sg               = "set";
static const char *_pmm_source_keyword_sg            = "source";
static const char *_pmm_stats_keyword_sg             = "stats";
static const char *_pmm_tag_keyword_sg               = "tag";
static const char *_pmm_table_keyword_sg             = "table";
static const char *_pmm_variablesize_keyword_sg      = "variablesize";
static const char *_pmm_version_keyword_sg           = "version";


/* The next few variables define messages used by the different CLI
 * commands. */
static const char *_pmm_invalid_param_sg     =
  "\"%s\" is an invalid parameter for the \"%s\" command/option.\n";
static const char *_pmm_too_many_params_sg   = 
  "There are too many parameters for the \"%s\" command/option.\n";
static const char *_pmm_too_few_params_sg    =
  "Insufficient number of parameters for the \"%s\" command/option.\n";


/* The next variable defines the delimiters accepted between the
 * keywords of a CLI commands when the command is parsed with the
 * cli_command_parse() function. */
static char  *_pmm_delimiters_sg = " \t";


/* This variable will store the default PMM DB handle. */
static handle_t  _pmm_db_handle_sg = HANDLE_NULL;










/*--------------------- Static Function Definitions ---------------*/

/* Receive the next message from the specified PMLA connection.
 *
 * param pmlaHandle   ID of the PMLA connection to use.
 * param msg_p        Buffer where the received message is stored. 
 * param msgSize_p    Size of the received message.
 * retval             true upon success; false otherwise.  When true
 *                    is returned, the received message is stored in
 *                    msg_p and the size of the received message is
 *                    stored in msgSize_p.  Note that it is the
 *                    responsibility of the caller to free the msg_p
 *                    buffer with a call to the mem_free function.
 */
static bool
_pmm_msg_receive(
  handle_t    pmlaHandle,
  pmp_msg_t **msg_p,
  uint32_t   *msgSize_p
  )
{
  PmlaError_t  pmlaStatus = pmlaSuccess_c;
  uint32_t     msgSize    = 0;
  pmp_msg_t    msg;
  

  /* Reset the message buffer. */
  *msg_p = NULL;
  

  /* Attempt to read the message. */
  pmlaStatus = pmlaRecv(pmlaHandle, &msg);
  if (pmlaSuccess_c != pmlaStatus) {
    fprintf(stdout, "Failed to read the message from %s.  \"%s\"\n", 
            PMLA_MODULE_NAME, pmlaErrorString(pmlaStatus));
    return false;
  }

  
  /* Allocate a buffer for the message. */
  msgSize    = PMP_PMHWTOHL(msg.header.msgLength);
  *msgSize_p = msgSize;
  
  *msg_p = mem_calloc(1, msgSize);
  if (NULL == *msg_p) {
    fprintf(stdout, "Failed to allocate a %u byte long buffer needed to "
            "read a %s message of that size.\n", msgSize, PMLA_MODULE_NAME);
    return false;
  }
  

  /* Copy the read message header into the message buffer. */
  memcpy(*msg_p, &msg, msgSize);

  
  return true;
} /* _pmm_msg_receive */


/* Send a message over the specified PMLA connection.
 *
 * param pmlaHandle   ID of the PMLA connection to use.
 * param msg_p        Pointer to the message to be sent.
 * retval             true upon success; false otherwise.  Note that
 *                    this function does not free the passed in
 *                    message buffer. 
 */
static bool
_pmm_msg_send(
  handle_t   pmlaHandle,
  pmp_msg_t *msg_p
  )
{
  bool         status     = true;
  PmlaError_t  pmlaStatus = pmlaSuccess_c;
    
  
  /* Send the message. */
  pmlaStatus = pmlaSend(pmlaHandle, msg_p);
  if (pmlaSuccess_c != pmlaStatus) {
    fprintf(stdout, "Failed to send a %s message.  \"%s\"\n", 
            PMLA_MODULE_NAME, pmlaErrorString(pmlaStatus));
    status = false;
  }
    
  return status;
} /* _pmm_msg_send */


/* Retrieves the next message ID to use.
 *
 * This is a very simple function.  The function does not ensure tha
 * the message ID it returns is not already in use.
 *
 * retval  The next message ID to use.
 */
static uint64_t
_pmm_msg_id_get(void)
{
  static uint64_t  msgId = 0;
  
  return msgId++;
} /* _pmm_msg_id_get */


/* Read an attribute from the PM H/W.
 *
 * param pmlaHandle   ID of the communication channel to use.
 * param attributeId  ID of the attribute to be written.
 * param buffer_p     Pointer to the buffer where to store the attribute.
 * param size_p       Pointer to store the length of the read attribute.
 * retval             true upon success; false otherwise. 
 */
static bool
_pmm_attribute_read(
  handle_t                  pmlaHandle,
  pmp_attribute_id_field_t  attributeId,
  void                     *buffer_p,
  uint32_t                 *size_p)
{
  bool                          status          = true;
  uint32_t                      msgSize         = 0;
  pmp_message_type_t            msgType         = 
    pmp_attribute_get_request_msg_type_e;
  uint32_t                      msgBufferSize   = sizeof(pmp_msg_t);
  pmp_msg_t                    *msgBuffer_p     = mem_calloc(1, msgBufferSize);
  uint32_t                      msgId           = _pmm_msg_id_get();
  pmp_msg_t                    *replyMsg_p      = NULL;
  uint32_t                      replyMsgSize    = 0;
  pmp_message_type_t            replyMsgType    = 
    pmp_attribute_get_reply_msg_type_e;
  uint32_t                      attributeSize   = 0;
  pmp_attribute_get_request_msg_t *requestMsg_p = NULL;

 
  /* Check the initializations above. */
  if (NULL == msgBuffer_p) {
    fprintf(stdout, "Failed to allocate a %u byte long message buffer.\n", 
            msgBufferSize);
    return false;
  }


  /* Build and send the read request message. */
  requestMsg_p = (&msgBuffer_p->requestMsg.attributeGetRequestMsg);

  msgSize = PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE;
  memset(requestMsg_p, 0, msgSize);
  requestMsg_p->header.protocolVersion = PMP_CURRENT_VERSION;
  requestMsg_p->header.msgType         = msgType;
  requestMsg_p->header.reserved        = 0;
  requestMsg_p->header.msgLength       = PMP_PMHWTOHL(msgSize);
  requestMsg_p->header.msgId           = PMP_HTOPMHWLL(msgId);
  requestMsg_p->attributeId            = PMP_HTOPMHWL(attributeId);
  status = _pmm_msg_send(pmlaHandle, msgBuffer_p);

  if (true == status) {
    /* Read the reply message. */
    status = _pmm_msg_receive(pmlaHandle, &replyMsg_p, &replyMsgSize);
    if (true == status) {
      if (replyMsgType == replyMsg_p->header.msgType) {
        /* Copy the attribute into the provided buffer. */
        attributeSize = 
          (replyMsgSize - PMP_ATTRIBUTE_GET_REPLY_EMPTY_MSG_SIZE);
        memcpy(buffer_p, 
               &replyMsg_p->replyMsg.attributeGetReplyMsg.attributeValue,
               attributeSize);
      }
      else {
        fprintf(stdout, "Received message type %u but was expecting %u.\n",
                replyMsg_p->header.msgType, replyMsgType);
        status = false;
      }
    }

    /* Free the reply message buffer. */
    if (NULL != replyMsg_p) { mem_free(replyMsg_p); }
  } /* if - no errors so far - read the reply message. */
  
  /* Free the request message buffer. */
  if (NULL != msgBuffer_p) { mem_free(msgBuffer_p); }
  
  *size_p = attributeSize;
  return status;
} /* _pmm_attribute_read */


/* Write an attribute to the PM H/W.
 *
 * param pmlaHandle   ID of the communication channel to use.
 * param attributeId  ID of the attribute to be written.
 * param buffer_p     Pointer to the buffer with the attribute value.
 * param size         Size of the attribute value.
 * retval             true upon success; false otherwise. 
 */
static bool
_pmm_attribute_write(
  handle_t                  pmlaHandle,
  pmp_attribute_id_field_t  attributeId,
  void                     *buffer_p,
  uint32_t                  size
  )
{
  bool       boolStatus  = true;
  uint32_t   msgLength   = 0;
  pmp_msg_t *msgBuffer_p = NULL;
 
  
  /* Allocate memory needed to build the message. */
  msgLength = PMP_ATTRIBUTE_SET_REQUEST_MSG_SIZE(size);

  msgBuffer_p = mem_calloc(1, msgLength);
  if (NULL == msgBuffer_p) {
    fprintf(stdout, "Failed to allocate %u bytes of memory needed to send "
            "an attribute write request.\n", msgLength);
    return false;
  }
  pmp_attribute_set_request_msg_t *msg_p =
    &msgBuffer_p->requestMsg.attributeSetRequestMsg;


  /* Build the message. */
  msg_p->header.protocolVersion = PMP_CURRENT_VERSION;
  msg_p->header.msgType         = pmp_attribute_set_request_msg_type_e;
  msg_p->header.msgId           = PMP_HTOPMHWLL(_pmm_msg_id_get());
  msg_p->header.msgLength       = PMP_HTOPMHWL(msgLength);
  msg_p->attributeId            = PMP_HTOPMHWL(attributeId);
  memcpy(&msg_p->attributeValue, buffer_p, size);


  /* Send the message. */
  boolStatus = _pmm_msg_send(pmlaHandle, msgBuffer_p);

   
  /* Free the message buffer. */
  if (NULL != msgBuffer_p) { mem_free(msgBuffer_p); }
  
  return boolStatus;
} /* _pmm_attribute_write */


/* 
 * Retrieve platform specific parameters from the PM H/W.
 *
 * This function attempts to read all the platform specific parameters
 * from the PM H/W identified by the pmlaHandle channel that are
 * needed to create a PMLL DB.
 *
 * At present the function reads the following parameters:
 * dxeSreTableSize       Location of where to store the read number of
 *                       the DXE and SRE confirmation entries. 
 * sreSessionCtxSize     Location of where to store the read size of
 *                       the SRE session context. 
 * sreSessionCtxNum      Location of where to store the read number of
 *                       the sessions. 
 * sreRuleNum            Location of where to store the read maximum
 *                       number of the stateful rules. 
 *
 * param pmlaHandle      Handle of the PMLA connection to use.
 * param pmllDbParams_p  Where to store the read PMLL DB parameters.
 * retval                true on success; false otherwise.  When true
 *                       is returned the values of the read parameters
 *                       are passed back through the pointer parameters.
 */
static PmlaError_t
_pmm_target_params_get(
  handle_t          pmlaHandle,
  pmll_db_params_t *pmllDbParams_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: "
             "%s(pmlaHandle=%"PRI_HANDLE", pmllDbParams_p=%p).", __func__, 
             pmlaHandle, pmllDbParams_p);
  
  bool                              boolStatus        = false;
  uint32_t                          attributeSize     = 0;
  pmp_extension_block_num_attr_t    dxeSreTableSize   = 0;
  pmp_context_area_size_attr_t      sreSessionCtxSize = 0;
  pmp_context_max_num_attr_t        sreSessionCtxNum  = 0;
  pmp_max_stateful_rule_num_attr_t  sreRuleNum        = 0;
  
  
  /* Read the number of the confirmation entries. */
  boolStatus = _pmm_attribute_read(pmlaHandle, 
                                   pmp_extension_block_num_attr_id_e,
                                   &dxeSreTableSize, &attributeSize);
  if (true != boolStatus) {
    fprintf(stdout, "An attempt to read the number of the available "
            "confirmation entries attribute failed.\n");
    return false;
  }
  else if (sizeof(pmp_extension_block_num_attr_t) != attributeSize) {
    fprintf(stdout, "The read extension block number attribute has an "
            "unexpected size.  Expected size is %Zd; read size is %u.\n",
            sizeof(pmp_extension_block_num_attr_t), attributeSize);
    return false;
  }
  

  /* Read the session context size. */
  boolStatus = _pmm_attribute_read(pmlaHandle, 
                                   pmp_context_area_size_attr_id_e,
                                   &sreSessionCtxSize, &attributeSize);
  if (true != boolStatus) {
    fprintf(stdout, "An attempt to read the session context size attribute "
            "failed.\n");
    return false;
  }
  else if (sizeof(pmp_context_area_size_attr_t) != attributeSize) {
    fprintf(stdout, "The read context area size attribute has an unexpected "
            "size.  Expected size is %Zd; read size is %u.\n", 
            sizeof(pmp_context_area_size_attr_t), attributeSize);
    return false;
  } 


  /* Read the session number. */
  boolStatus = _pmm_attribute_read(pmlaHandle, pmp_context_max_num_attr_id_e,
                                   &sreSessionCtxNum, &attributeSize);
  if (true != boolStatus) {
    fprintf(stdout, "An attempt to read the session context size attribute "
            "failed.\n");
    return false;
  }
  else if (sizeof(pmp_context_max_num_attr_t) != attributeSize) {
    fprintf(stdout, "The read session context size attribute has an "
            "unexpected size.  Expected size is %Zd; read size is %u.\n", 
            sizeof(pmp_context_max_num_attr_t), attributeSize);
    return false;
  } 


  /* Read the maximum number of the stateful rules. */
  boolStatus = _pmm_attribute_read(pmlaHandle, 
                                   pmp_max_stateful_rule_num_attr_id_e,
                                   &sreRuleNum, &attributeSize);
  if (true != boolStatus) {
    fprintf(stdout, "An attempt to read the maximum number of stateful "
            "rules attribute failed.\n");
    return false;
  }
  else if (sizeof(pmp_max_stateful_rule_num_attr_t) != attributeSize) {
    fprintf(stdout, "The read maximum number of the stateful rules attribute "
            "has an unexpected size.  Expected size is %Zd; read size is "
            "%u.\n", sizeof(pmp_max_stateful_rule_num_attr_t), attributeSize);
    return false;
  } 

  
  pmllDbParams_p->dxeSreTableSize   = PMP_PMHWTOHL(dxeSreTableSize);
  pmllDbParams_p->sreSessionCtxSize = PMP_PMHWTOHL(sreSessionCtxSize);
  pmllDbParams_p->sreSessionCtxNum  = PMP_PMHWTOHL(sreSessionCtxNum);  
  pmllDbParams_p->sreRuleNum        = PMP_PMHWTOHL(sreRuleNum);

  return true;
} /* _pmm_target_params_get */


/* Pings the PM H/W.
 *
 * param pmlaHandle  ID of the communication channel to use.
 * retval            true if the ping worked with no errors, false
 *                   otherwise. 
 */
static bool
_pmm_ping(
  handle_t  pmlaHandle
  )
{
  PmlaError_t  pmlaStatus = pmlaSuccess_c;
  bool         returnCode = true;
    

  /* Ping operation is implemented using the PMLA flush command. */
  pmlaStatus = pmlaFlush(pmlaHandle);
  if (pmlaSuccess_c != pmlaStatus) {
    fprintf(stdout, "Pinging the PM H/W failed.  \"%s\"\n", 
            pmlaErrorString(pmlaStatus));
    returnCode = false;
  }

  return returnCode;
} /* _pmm_ping */


/*
 * Converts the passed string to an IPv4 address.
 *
 * param addrString_p  Pointer to the string with the address value.
 * param address_p     Pointer to where to store the converted address.
 * param port_p        Pointer to where to store the converted port.
 * retval              True upon success; false otherwise.
 */
static bool
_pmm_ipv4if_address_from_string_get(
  const char      *addrString_p,
  uint32_t *const  address_p,
  uint16_t *const  port_p
  )
{
  uint32_t        address          = 0;
  char           *end_p            = NULL;
  char           *addrStringCopy_p = NULL;
  char           *portString_p     = NULL;
  bool            returnValue      = false;
  struct in_addr  inAddr;
  

  addrStringCopy_p = strdup(addrString_p);
  if (NULL == addrStringCopy_p) {
    /* We failed to duplicate the address string. */
    return false;
  }
  
  /* First check if the port is specified. */
  portString_p = strchr(addrStringCopy_p, ':');
  if (NULL != portString_p) {
    /* The port is specified.  Adjust the address and port strings. */
    *portString_p = 0;
    portString_p++;
  }
  
    
  /* Try to extract the IPv4 address first.  Assume that the value of
   * the address is in a numeric form. */
  address = strtoul(addrStringCopy_p, &end_p, 0);
  if ((NULL != addrStringCopy_p) && (NULL == end_p)) {
    *address_p  = ntohl(address);
    returnValue = true;
  }
  else {
    /* Assume that the address is in the standard numbers-and-dots
     * notation. */
    if (0 != inet_aton(addrStringCopy_p, &inAddr)) {
      *address_p  = ntohl(inAddr.s_addr);
      returnValue = true;
    }
    else {
      /* Assume that the string is a name of a host. */
      struct hostent *hostent_p = gethostbyname2(addrStringCopy_p, AF_INET);
      if (NULL != hostent_p) {    
        *address_p  = ntohl(((struct in_addr *)hostent_p->h_addr_list[0])->
                            s_addr);
        returnValue = true;
      }
    }
  }
  
  
  /* Now try to extract the IPv4 port number. */
  if (NULL != portString_p) {
    uint32_t  tmpValue = 0;
    
    if ((false == cli_uint32get(portString_p, &tmpValue)) ||
        (tmpValue > 0xffff)) {
      returnValue = false;
    }
    else {
      *port_p = tmpValue;
    }
  }
  
  /* Free the duplicated string. */
  if (NULL != addrStringCopy_p) { free(addrStringCopy_p); }
      
  return returnValue;
} /* _pmm_ipv4if_address_from_string_get */


/* 
 * Get the presentation form of an IPv4 address.
 *
 * param ipv4Address    Numeric form of the IPv4 address.
 * param ipv4Address_p  Pointer to the buffer where the presentation
 *                      form of the IPv4 address is going to be
 *                      stored.  The buffer must be at least the
 *                      INET_ADDRSTRLEN bytes long. 
 * retval               Pointer to passed in ipv4Address_p buffer
 *                      with the presentation form of the address.
 *                      The buffer contains an empty string, i.e, "",
 *                      upon an error.
 */
static char * 
_pmm_ipv4if_string_from_address_get(
  uint32_t  ipv4Address,
  char     *ipv4Address_p
  )
{
  uint32_t  ipv4AddressNet = htonl(ipv4Address);


  if (NULL == ipv4Address_p) {
    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "%s: NULL ipv4Address_p "
               "passed.", __func__);
    return ipv4Address_p;
  }

  if (NULL == inet_ntop(AF_INET, &ipv4AddressNet, ipv4Address_p,
                        INET_ADDRSTRLEN)) {
    ipv4Address_p[0] = 0; 
  }
  
  return ipv4Address_p;
} /* _pmm_ipv4if_string_from_address_get */


/* 
 * Create a PMLA connection to the PM H/W.
 *
 * This function attempts to create a control connection to communicate
 * with the PM H/W identified by the ipv4Address, ipv4Port and
 * channelId parameters.  The function assumes that an IPv4 address
 * and port combined with the channel ID are used to identify the PM
 * target. 
 *
 * param ipv4Address  IPv4 address of the PM target host.
 * param ipv4Port     IPv4 port of the PM target host.
 * param channelId    Part of the local address; ID of the PM H/W channel.
 * param timeout      The timeout to be associated with the connection.
 *                    This timeout is used while trying to receive PMLA
 *                    messages. 
 * param handle_p     Pointer to the area where the handle of the
 *                    created control connection is to be stored.
 * retval             pmlaSuccess_c upon success; a PMLA error code
 *                    otherwise.  When PMLA_Ok_e is returned the
 *                    handle of the created connection is returned
 *                    through the handle_p parameter.
 */
static PmlaError_t
_pmm_pmla_connection_create(
  uint32_t  ipv4Address,
  uint16_t  ipv4Port,
  uint32_t  channelId,
  uint32_t  timeout,
  handle_t *handle_p
  )
{
  char                ipv4Address_s[INET_ADDRSTRLEN] = "";
  PmlaError_t         pmlaStatus                     = pmlaSuccess_c;
  PmlaTarget_t        pmlaTargetAddress;
  struct sockaddr_in *inetAddr_p                     =
    (struct sockaddr_in *)&pmlaTargetAddress.addr;


  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: "
             "%s(ipv4Address=%s, ipv4Port=%u, "
             "channelId=%u, timeout=%u, handle_p=%p).", 
             __func__, _pmm_ipv4if_string_from_address_get(ipv4Address, 
                                                           ipv4Address_s),
             ipv4Port, channelId, timeout, handle_p);


  /* Build the PMLA targer address structure. */
  memset(&pmlaTargetAddress, 0, sizeof(pmlaTargetAddress));
  pmlaTargetAddress.channel   = channelId;
  inetAddr_p->sin_family      = AF_INET;
  inetAddr_p->sin_port        = htons(ipv4Port);
  inetAddr_p->sin_addr.s_addr = htonl(ipv4Address);
   
  
  /* Create the PMLA target object. */
  pmlaStatus = pmlaOpen(&pmlaTargetAddress, handle_p);
  if (pmlaSuccess_c != pmlaStatus) {
    /* There was an error. */
    LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Failed to open a %s connection.  "
               "\"%s\"", PMLA_MODULE_NAME, pmlaErrorString(pmlaStatus));
    return pmlaStatus;
  }
  
  /* Set the timeout value for the PMLA connection. */
  pmlaStatus = pmlaSetOption(*handle_p, pmlaOptionTimeout_c, 
                             &timeout, sizeof(timeout));
  if (pmlaSuccess_c != pmlaStatus) {
    LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to set the timeout "
               "value to %u on a %s connection to PM H/W target with "
               "ipv4Address=%s, ipv4Port=%u and channelId=%u.  \"%s\"", 
               timeout, PMLA_MODULE_NAME, 
               _pmm_ipv4if_string_from_address_get(ipv4Address, ipv4Address_s),
               ipv4Port, channelId, pmlaErrorString(pmlaStatus));
  }
  else {
    /* Connect to the PM H/W target. */
    pmlaStatus = pmlaConnect(*handle_p);
    if (pmlaSuccess_c != pmlaStatus) {
      LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Failed to connect to PM "
                 "H/W target with ipv4Address=%s, ipv4Port=%u and "
                 "channelId=%u.  \"%s\"", 
                 _pmm_ipv4if_string_from_address_get(ipv4Address, 
                                                     ipv4Address_s),
                 ipv4Port, channelId, pmlaErrorString(pmlaStatus));
    }
    else {
      /* We successfully connected to the PM H/W target.  Now we
       * set the keep alive interval for this connection. */
      int  keepAliveInterval = _PMM_PMLA_KEEP_ALIVE_INTERVAL;
      pmlaStatus = pmlaSetOption(*handle_p, pmlaOptionKeepAlive_c, 
                                 &keepAliveInterval, 
                                 sizeof(keepAliveInterval));
      if (pmlaSuccess_c != pmlaStatus) {
        LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to set the keep "
                   "alive interval to %d on a %s connection to PM H/W  "
                   "target with ipv4Address=%s, ipv4Port=%u and "
                   "channelId=%u.  \"%s\"", keepAliveInterval, 
                   PMLA_MODULE_NAME, 
                   _pmm_ipv4if_string_from_address_get(ipv4Address, 
                                                       ipv4Address_s),
                   ipv4Port, channelId, pmlaErrorString(pmlaStatus));
      }
    }
  }
  

  if (pmlaSuccess_c != pmlaStatus) {
    /* The function failed.  Close the connection. */
    PmlaError_t  pmlaCloseStatus = pmlaClose(*handle_p);
    *handle_p = HANDLE_NULL;
    if (pmlaSuccess_c != pmlaCloseStatus) {
      LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Failed to close a %s "
                 "connection opened to PM H/W target with ipv4Address=%s, "
                 "ipv4Port=%u and channelId=%u.  \"%s\"", PMLA_MODULE_NAME, 
                 _pmm_ipv4if_string_from_address_get(ipv4Address, 
                                                     ipv4Address_s),
                 ipv4Port, channelId, pmlaErrorString(pmlaCloseStatus));
    }
  }
  else {
    LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Successfully created a %s "
               "connection to PM H/W (handle=%"PRI_HANDLE").",
               PMLA_MODULE_NAME, *handle_p);
  }
  
  return pmlaStatus;
} /* _pmm_pmla_connection_create */


/*
 * Allocate a PMM rule record.
 *
 * param  reactionNum  Number of reactions in the rule to be allocated.
 * retval              The pointer to the allocated record on success; NULL
 *                     pointer otherwise.
 */
static _pmm_rule_record_t *
_pmm_pmm_rule_allocate(
  uint32_t  reactionNum
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: "
             "%s(reactionNum=%u).", __func__, reactionNum);


  /* Allocate and clear a new rule record. */
  _pmm_rule_record_t *rule_p = mem_calloc(1, sizeof(_pmm_rule_record_t));
  if (NULL == rule_p) {
    LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Failed to allocate memory "
               "for a new rule record.");
    return NULL;
  }
  else {
    LOG_STRING(LOG_MEMORY, _PMM_MODULE_NAME, "Allocated %Zd bytes at "
               "location %p for a new PMM rule record.", 
               sizeof(_pmm_rule_record_t), rule_p);

    /* Allocate and clear memory for the names of the expressions in
     * the rule. */
    rule_p->reactionNames_p = mem_calloc(reactionNum, sizeof(_pmm_name_t));
    if (NULL == rule_p->reactionNames_p) {
      LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Failed to allocate memory "
                 "for the expression name fields in a new rule record.");
      mem_free(rule_p);
      return NULL;
    }
    else {
      LOG_STRING(LOG_MEMORY, _PMM_MODULE_NAME, "Allocated %Zd bytes at "
                 "location %p for a reaction name table in a new PMM rule "
                 "record.", reactionNum * sizeof(_pmm_name_t),
                 rule_p->reactionNames_p);
    }
  }

  return rule_p;
} /* _pmm_pmm_rule_allocate */


/*
 * Free the memory used by the specified PMM rule.
 *
 * param rule_p  Pointer to the rule to free.
 */
static void
_pmm_pmm_rule_free(
  _pmm_rule_record_t *rule_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(rule_p=%p).",
             __func__, rule_p);

  if (NULL == rule_p) {
    LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "NULL rule_p pointer passed in.");
    return;
  }
  
  if (NULL != rule_p->reactionNames_p) {
    LOG_STRING(LOG_MEMORY, _PMM_MODULE_NAME, "Freeing reactionNames_p=%p "
               "table for rule with pmmIndex=%u.", rule_p->reactionNames_p,
               rule_p->pmmIndex);
    mem_free(rule_p->reactionNames_p);
  }
      
  LOG_STRING(LOG_MEMORY, _PMM_MODULE_NAME, "Freeing rule_p=%p record for rule "
             "with pmmIndex=%u.", rule_p, rule_p->pmmIndex);
  mem_free(rule_p);
} /* _pmm_pmm_rule_free */


/*
 * Recursively free all the PM reaction entries in the passed chain.
 *
 * param reaction_p  Pointer to the first PM reaction entry in the chain.
 */
static void
_pmm_pm_rule_reaction_entry_free(
  pm_reaction_entry_t *pmReaction_p
  )
{
  if (NULL != pmReaction_p) {
    if (NULL != pmReaction_p->nextReactionEntry_p) {
      _pmm_pm_rule_reaction_entry_free(pmReaction_p->nextReactionEntry_p);
    }

    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Freeing a PM reaction entry at "
               "location %p.", pmReaction_p);
    mem_free(pmReaction_p);
  }  
} /* _pmm_pm_rule_reaction_entry_free */


/*
 * Free the memory used by the specified PM rule.
 *
 * param rule_p  Pointer to the PM rule record to be deallocated.
 */
static void
_pmm_pm_rule_free(
  pm_rule_record_v_1_0_0_t *pmRule_p
  )
{
  if (NULL != pmRule_p) {
    if (NULL != pmRule_p->reactionEntry_p) {
      _pmm_pm_rule_reaction_entry_free(pmRule_p->reactionEntry_p);
    }
           
    /* Deallocate the rule record. */
    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Freeing a PM rule record at "
               "location %p.", pmRule_p);
    mem_free(pmRule_p);
  }  
} /* _pmm_pm_rule_free */


/*
 * Show a PMM expression record.
 *
 * param exp_p  Pointer to the expression record to be shown.
 */
static void 
_pmm_exp_show(
  void     *exp_p,
  char     *recordName_p,
  uint32_t  recordIndex
  )
{
  const _pmm_exp_record_t *const  pmmExp_p = exp_p;

  recordIndex = 0;      /* to avaid the"unsued parameter" warning */


  fprintf(stdout, "name=%-10s   expression=\"%s\"   options=\"%s\"\n",
          recordName_p, pmmExp_p->exp_s, pmmExp_p->options_s);
} /* _pmm_exp_record_show */


/*
 * Show a PMM rule record.
 *
 * param rule_p  Pointer to the rule record to be shown.
 */
static void 
_pmm_rule_show(
  void     *rule_p,
  char     *recordName_p,
  uint32_t  recordIndex
  )
{
  const _pmm_rule_record_t *const pmmRule_p = rule_p;
  uint32_t                        i         = 0;

  recordIndex = 0;      /* to avaid the"unsued parameter" warning */
  

  fprintf(stdout, "name=%-10s   reactionNum=%u, "
          "expNames: ", recordName_p, pmmRule_p->reactionNum);
  _pmm_name_t *reactionNames_p = pmmRule_p->reactionNames_p;
  for (i = 0;i < pmmRule_p->reactionNum;i++) {
    fprintf(stdout, "%s ", reactionNames_p[i]);
  }
  fprintf(stdout, "\n");    
} /* _pmm_rule_record_show */


/* 
 *  Allocates a new exp. record and adds it to the PMM exp. DB.
 *
 * param expDbHandle   DB handle to add the expression record to.
 * param pmExp_p       Data to initialize the new record with.
 * param exp_p         Expression string.
 * param options_p     Expression options string.
 * param llIndex       Linker-loader index to be stored in the new
 *                     expression record.
 * retval              Pointer to the newly created and added
 *                     expression record on successs; NULL pointer
 *                     otherwise.
 */
static _pmm_exp_record_t *
_pmm_exp_add(
  const handle_t           expDbHandle,
  pm_exp_record_v_1_0_1_t *pmExp_p,
  const char              *exp_p,           
  const char              *options_p,
  const uint32_t           llIndex
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(expDbHandle="
             "%"PRI_HANDLE", pmExp_p=%p (name=%s), exp_p=%p, options_p=%p, "
             "llIndex=%u).", __func__, expDbHandle, pmExp_p, pmExp_p->name_s,
             exp_p, options_p, llIndex);  

  /* Allocate and clear a new expression record. */
  _pmm_exp_record_t *pmmExp_p = mem_calloc(1, sizeof(_pmm_exp_record_t));
  if (NULL == pmmExp_p) {
    LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, 
               "Failed to allocate a new expression record.");
    return NULL;
  }
  LOG_STRING(LOG_MEMORY, _PMM_MODULE_NAME, "Allocated %Zd bytes at location "
             "%p for a new PMM expression record.", sizeof(_pmm_exp_record_t), 
             pmmExp_p);
  
  
  /* Initialize the newly allocated PMM expression record. */
  strncpy(pmmExp_p->exp_s, exp_p, _PMM_EXP_STRING_MAX_SIZE);
  strncpy(pmmExp_p->options_s, options_p, _PMM_EXP_OPTIONS_STRING_MAX_SIZE);
  pmmExp_p->exp_s[_PMM_EXP_STRING_MAX_SIZE - 1] = 0;
  pmmExp_p->llIndex                             = llIndex;
  

  /* Add the new expression record to the PMM expression DB. */
  uint32_t    pmmIndex = IDX_NULL_INDEX;
  db_status_t dbStatus = db_record_add(expDbHandle, pmExp_p->name_s, 
                                       pmmExp_p, &pmmIndex);
  if (db_ok_e != dbStatus) {
    fprintf(stdout, "Failed to add a new expression record to "
            "the PMM expression DB.  \"%s\"\n", db_error_string_get(dbStatus));
    LOG_STRING(LOG_MEMORY, _PMM_MODULE_NAME, "Freeing exp_p=%p record for"
               "expression with llIndex=%u.", pmmExp_p, llIndex);
    mem_free(pmmExp_p);
    return NULL;
  }

  /* Store the PMM index in the expression record. */
  pmmExp_p->pmmIndex = pmmIndex;

  return pmmExp_p;
} /* _pmm_exp_add */


/* 
 *  Allocates a new rule record and adds it to the PMM rule DB.
 *
 * param  ruleDbHandle  DB handle to add the rule record to.
 * param  pmRule_p      Data to initialize the new record with.
 * param  llIndex       Linker-loader index to be stored in the new
 *                      rule record.
 * retval               Pointer to the newly created and added rule
 *                      record on successs; NULL pointer otherwise.
 */
static _pmm_rule_record_t *
_pmm_rule_add(
  const handle_t            ruleDbHandle,
  pm_rule_record_v_1_0_0_t *pmRule_p,
  const uint32_t            llIndex
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME,
             "Entering function: %s(ruleDbHandle=%"PRI_HANDLE", pmRule_p=%p "
             "(name=%s), llIndex=%u).", __func__, ruleDbHandle, pmRule_p,
             pmRule_p->name_s, llIndex);
  
  /* Allocate a new rule record. */
  _pmm_rule_record_t *pmmRule_p = 
    _pmm_pmm_rule_allocate(pmRule_p->reactionNum);
  if (NULL == pmmRule_p) {
    LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Failed to allocate a new rule "
               "record.");
    return NULL;
  }
  
  /* Initialize the newly allocated PMM rule record. */
  /* Save the number of expressions in the rule. */
  pmmRule_p->reactionNum = pmRule_p->reactionNum;

  /* Save the names of all the expressions in the rule. */
  pm_reaction_entry_t *reaction_p     = pmRule_p->reactionEntry_p;
  _pmm_name_t         *reactionName_p = pmmRule_p->reactionNames_p;
  uint32_t             i              = 0;
  for (i = 0;i < pmRule_p->reactionNum;i++) {
    strncpy(reactionName_p[i], reaction_p->expName_s, PM_NAME_MAX_LENGTH - 1);
    /* Move to the next expression in the rule. */
    reaction_p = reaction_p->nextReactionEntry_p;
  }

  /* Save the LL index. */
  pmmRule_p->llIndex = llIndex;
  

  /* Add the new rule record to the PMM rule DB. */
  uint32_t    pmmIndex = IDX_NULL_INDEX;
  db_status_t dbStatus = db_record_add(ruleDbHandle, pmRule_p->name_s, 
                                       pmmRule_p, &pmmIndex);
  if (db_ok_e != dbStatus) {
    fprintf(stdout, "Failed to add a new rule record to the PMM "
            "rule DB.  \"%s\"\n", db_error_string_get(dbStatus));
    _pmm_pmm_rule_free(pmmRule_p);
    return NULL;
  }

  /* Store the PMM index in the rule record. */
  pmmRule_p->pmmIndex = pmmIndex;

  return pmmRule_p;
} /* _pmm_rule_add */


/* 
 * Adds rules from the specified binary file.
 *
 * param pmmDbHandle    Handle of the PMM DB to use.
 * param binFileName_p  Name of the binary file to use.
 * retval               0 upon success;  -1 otherwise.
 */
static int
_pmm_rules_from_bin_file_add(
  handle_t  pmmDbHandle,
  char     *binFileName_p
  )
{
  FILE                     *binFile_p             = fopen(binFileName_p, "r");
  uint32_t                  recordType            = 0;
  uint32_t                  recordVersion         = 0;
  uint32_t                  ruleNameLength        = 0;
  size_t                    readNum               = 0;
  uint32_t                  i                     = 0;
  uint32_t                  addedRuleCount        = 0;
  uint32_t                  failedRuleCount       = 0;
  char                     *eofError_s            = 
    "EOF encountered while reading a rule record.\n";
  char                     *failError_s           =
    "Failed to read a rule record.  \"%s\"\n";
  bool                      reactionsReadOk       = false;
  bool                      tryToAddRule          = false;
  pmll_status_t             pmllStatus            = pmll_ok_e;
  uint32_t                  idx                   = 0;
  char                     *ruleNameString_p      = NULL;
  pm_rule_record_v_1_0_0_t *rule_p                = NULL;
  _pmm_db_t                *pmmDb_p               = pmmDbHandle;
  unsigned int              llDbHandle            = pmmDb_p->llDbHandle;
  int                       status                = 0;
    

  if (NULL == binFile_p) {
    fprintf(stdout, "Could not open file \"%s\".  \"%s\".\n", 
            binFileName_p, strerror(errno));
    return errno;
  }
  

  /* Read the rule records from the file. */
  while (true) {
    /* Allocate a rule record.  This record will be filled with the
     * data read from the binary rule record, then added to the PMLL
     * DB and then freed.  It is not optimal but it is simple. */
    rule_p = (pm_rule_record_v_1_0_0_t *)mem_calloc(
      1, sizeof(pm_rule_record_v_1_0_0_t));
    if (NULL == rule_p) {
      fprintf(stdout, failError_s, strerror(errno));
      status = errno;
      break;
    }
    
 
    /* Read the record type. */
    readNum = fread(&recordType, sizeof(recordType), 1, binFile_p);
    if (1 != readNum) {
      if (0 == feof(binFile_p)) {
        fprintf(stdout, failError_s, strerror(errno));
        status = EINVAL;
      }
      break;
    }
    else {
      /* Make sure this is a rule record. */
      if (PM_COMPILED_RULE_RECORD_TYPE != PMP_PMHWTOHL(recordType)) {
        fprintf(stdout, "Failed to read a record from a binary file.  The "
                "record has an unexpected record type of %#x.\n", 
                PMP_PMHWTOHL(recordType));
        status = EINVAL;
        break;
      }
    }
    
    /* Read the rule record version. */
    readNum = fread(&recordVersion, sizeof(recordVersion), 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    recordVersion = PMP_PMHWTOHL(recordVersion);
    /* Check if the read rule record version is as we expect it to be,
     * i.e., PM_RULE_BIN_RECORD_V_1_0_0. */
    if (PM_RULE_BIN_RECORD_V_1_0_0 != recordVersion) {
      fprintf(stdout, "Found unsupported binary rule record version of "
              "%#x.\n", recordVersion);
      status = EINVAL;
      break;
    }

    /* Read the rule name length. */
    readNum = fread(&ruleNameLength, sizeof(ruleNameLength), 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    ruleNameLength = PMP_PMHWTOHL(ruleNameLength);

    /* Read the rule name.  We read the entire name of the rule to be
     * able to display it in case it is too long. */
    if (NULL != ruleNameString_p) { mem_free(ruleNameString_p); }
    ruleNameString_p = mem_calloc(1, ruleNameLength);
    if (NULL == ruleNameString_p) {
      fprintf(stdout, failError_s, strerror(errno));
      status = errno;
      break;
    }
    readNum = fread(ruleNameString_p, ruleNameLength, 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    /* Check if the length of the rule name is not too long. */
    if (0 != ruleNameString_p[ruleNameLength - 1]) {
      fprintf(stdout, "Found a rule with name that is not NULL "
              "terminated.\n");
      status = EINVAL;
      tryToAddRule = false;
    }
    if (ruleNameLength > sizeof(rule_p->name_s)) {
      fprintf(stdout, "Failed to add a rule record with rule name \"%s\".  "
              "Rule name length of %u bytes is larger than the LL maximum "
              "supported size of %Zd.\n", ruleNameString_p, ruleNameLength,
              sizeof(rule_p->name_s));
      status = EINVAL;
      tryToAddRule = false;
    }
    else {
      /* Copy the read rule name into the PMLL rule record. */
      strncpy(rule_p->name_s, ruleNameString_p, ruleNameLength);
      if (0 != rule_p->name_s[PM_NAME_MAX_LENGTH - 1]) {
        fprintf(stdout, "Found a rule with name that is not NULL "
                "terminated after being copied.\n");
        status = EINVAL;
        tryToAddRule = false;
      }
    }
    
    /* Read the number of the reactions present in this rule. */
    readNum = fread(&rule_p->reactionNum, sizeof(rule_p->reactionNum), 1, 
                    binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    rule_p->reactionNum = PMP_PMHWTOHL(rule_p->reactionNum);


    /* Now read all the reactions in this rule.  Also link these
     * reactions together as required by the PMLL rule record. */
    pm_reaction_entry_t **pointToThisReaction_p = &rule_p->reactionEntry_p;
    uint32_t              eventType             = 0;
    uint32_t              expNameLength         = 0;
    char                 *expNameString_p       = NULL;
    uint8_t              *reactionData_p        = NULL;
    reactionsReadOk                             = true;
    tryToAddRule                                = true;
   
    for (i = 0;i < rule_p->reactionNum;i++) {
      /* Allocate memory for this reaction. */
      pm_reaction_entry_t *reaction_p = 
        mem_calloc(1, sizeof(pm_reaction_entry_t));
      if (NULL == reaction_p) {
        fprintf(stdout, failError_s, strerror(errno));
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }
      else {
        *pointToThisReaction_p = reaction_p;
      }
    
      /* Read the event type */
      readNum = fread(&eventType, sizeof(eventType), 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }
      reaction_p->reactionEventType = PMP_PMHWTOHL(eventType);

      /* Read the length of the expression name. */
      readNum = fread(&expNameLength, sizeof(expNameLength), 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }
      expNameLength = PMP_PMHWTOHL(expNameLength);

      /* Read the name of the expression. */
      if (NULL != expNameString_p) { mem_free(expNameString_p); }
      expNameString_p = mem_calloc(1, expNameLength);
      if (NULL == expNameString_p) {
        fprintf(stdout, failError_s, strerror(errno));
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }
      readNum = fread(expNameString_p, expNameLength, 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }

      /* Check if the expression name is NULL terminated. */
      if (0 != expNameString_p[expNameLength - 1]) {
        fprintf(stdout, "Reaction %u in rule \"%s\" has expression name "
                "that is not NULL terminated.\n", i + 1, rule_p->name_s);
        status = EINVAL;
        tryToAddRule = false;
      }
      /* Check if the length of the expression name is not too long. */
      if (expNameLength > sizeof(reaction_p->expName_s)) {
        fprintf(stdout, "Failed to add a rule record with rule name \"%s\".  "
                "A reaction refers to expression \"%s\" with name length "
                "of %u which is too big.  The maximum expression name "
                "length supported by LL is %Zd.\n", rule_p->name_s, 
                expNameString_p, expNameLength, 
                sizeof(reaction_p->expName_s));
        status = EINVAL;
        tryToAddRule = false;
      }
      else {
        /* Copy the read expression name into the PMLL reaction record. */
        strncpy(reaction_p->expName_s, expNameString_p, expNameLength);
        if (0 != reaction_p->expName_s[PM_NAME_MAX_LENGTH - 1]) {
          fprintf(stdout, "Reaction %u in rule \"%s\" has expression name "
                  "that is not NULL terminated after being copied.\n", 
                  i + 1, rule_p->name_s);
          status       = EINVAL;
          tryToAddRule = false;
        }
        else {
          /* Check if an exp. with the name just read exists in the LL
           * DB.  Do it only for reactions with the pattern reaction
           * event type. */
          if (pm_pattern_reaction_event_type_e == 
              reaction_p->reactionEventType) {
            bool  nameIsInUse = false;
            pmllStatus = pmll_exp_name_in_use(pmmDb_p->llDbHandle, 
                                              reaction_p->expName_s, 
                                              &nameIsInUse, NULL);
            if (pmll_ok_e != pmllStatus) {
              fprintf(stdout, "Failed to determine if expression \"%s\" "
                      "used by rule \"%s\" exists.  \"%s\"\n", 
                      reaction_p->expName_s, rule_p->name_s,  
                      pmll_error_string_get(pmllStatus));
              status       = EINVAL;
              tryToAddRule = false;
            }
            else if (false == nameIsInUse) {
              fprintf(stdout, "Cannot add rule with name \"%s\".  The rule "
                      "uses expression \"%s\" which is not defined.\n", 
                      rule_p->name_s, reaction_p->expName_s);
              status       = EINVAL;
              tryToAddRule = false;
            }
          }
        }
      }
      
      /* Read the size of the reaction. */
      readNum = fread(&reaction_p->reactionSize, 
                      sizeof(reaction_p->reactionSize), 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }
      reaction_p->reactionSize = PMP_PMHWTOHL(reaction_p->reactionSize);
          
      /* Read the reaction. */
      if (NULL != reactionData_p) { mem_free(reactionData_p); }
      reactionData_p = mem_calloc(1, reaction_p->reactionSize);
      if (NULL == reactionData_p) {
        fprintf(stdout, failError_s, strerror(errno));
        reactionsReadOk = false;
        status = EINVAL;
        break;
      }
      readNum = fread(reactionData_p, reaction_p->reactionSize, 1, 
                      binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        tryToAddRule = false;
        status = EINVAL;
        break;
      }
      if (reaction_p->reactionSize > sizeof(reaction_p->reactionData)) {
        fprintf(stdout, "Failed to read a rule record.  Size of "
                "reaction for rule \"%s\" and expression \"%s\" of %u "
                "bytes is too big.  The maximum reaction size supported "
                "by LL is %Zd.\n", rule_p->name_s, reaction_p->expName_s, 
                reaction_p->reactionSize, sizeof(reaction_p->reactionData));
        status       = EINVAL;
        tryToAddRule = false;
      }
      else {
        /* Copy the read reaction data into the PMLL reaction record. */
        memcpy(reaction_p->reactionData, reactionData_p, 
               reaction_p->reactionSize);
      }
      

      /* Adjust the pointToThisReaction_p pointer. */
      pointToThisReaction_p = &reaction_p->nextReactionEntry_p;
    } /* for - read the expressions in the rule */


    /* The rule has been read.  If the rule has been read successfully
     * then the rule record has been created and is ready to be added
     * to LL. */
    if (false == reactionsReadOk) {
      /* We failed to read the rule.  We must bail out from reading
       * the file. */
      failedRuleCount++;
      break;
    }
    
    /* We read the rule successfully.  Check if we can add it to LL. */
    if (true == tryToAddRule) {
      /* Add the rule to the linker-loader DB. */
      LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Adding rule with name \"%s\" "
                 "to the PMLL DB.", rule_p->name_s);
      pmllStatus = pmll_rule_add(pmmDb_p->llDbHandle, PMLL_RULE_RECORD_V_1_0_0,
                                 (pm_rule_record_t *)rule_p, &idx);
      if (pmll_ok_e == pmllStatus) {
        addedRuleCount++;
        /* Add the rule to the PMM rule DB. */
        if (NULL == _pmm_rule_add(pmmDb_p->ruleDbHandle, rule_p, idx)) {
          LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "Failed to add the \"%s\" "
                     "rule to the PMM DB.", rule_p->name_s);
          status = EIO;
        }
      }
      else {
        fprintf(stdout, "Failed to add a rule with name \"%s\".  "
                "\"%s\"\n", rule_p->name_s, pmll_error_string_get(pmllStatus));
        status = EIO;
        failedRuleCount++;
      }
    }
    else {
      /* We read the rule successfuly but the data read contained errors. */
      failedRuleCount++;
    }

    /* We are done with this rule.  Free all the allocated memory
     * blocks used to add this rule.  If needed again they will be
     * reallocated. */
    if (NULL != rule_p) { 
      _pmm_pm_rule_free(rule_p);
      rule_p = NULL; 
    }
    if (NULL != ruleNameString_p) { 
      mem_free(ruleNameString_p); 
      ruleNameString_p = NULL; 
    }
    if (NULL != expNameString_p) { 
      mem_free(expNameString_p); 
      expNameString_p = NULL; 
    }
    if (NULL != reactionData_p) {
      mem_free(reactionData_p); 
      reactionData_p = NULL; 
    }

    /* Check if we are not spinning in the while(true) loop. */
    if (addedRuleCount > PMLL_RULE_MAX_NUM) {
      LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME,
                 "Bad logic in function or there are too many rules in "
                 "the binary file.;  spinning in a while loop "
                 "(addedRuleCount=%u, failedRuleCount=%u).", 
                 addedRuleCount, failedRuleCount);
      status = EIO;
      break;
    }
  } /* while - read all the rules from the binary file. */



  /* We are done with the file.  Free all the allocated memory blocks. */
  if (NULL != rule_p) { 
    mem_free(rule_p); 
    rule_p = NULL; 
  }
  if (NULL != ruleNameString_p) { 
    mem_free(ruleNameString_p); 
    rule_p = NULL; 
  }
  

  if (0 != addedRuleCount) {
    if (1 == addedRuleCount) {
      fprintf(stdout, "Successfully added one rule to the PM DB "
              "with handle %u.\n", llDbHandle);
    }
    else{
      fprintf(stdout, "Successfully added %u rules to the PM DB "
              "with handle %u.\n", addedRuleCount, llDbHandle);
    }
  }
  if (0 != failedRuleCount) {
    if (1 == failedRuleCount) {
      fprintf(stdout, "Failed to add one rule to the PM DB with "
              "handle %u.\n", llDbHandle);
    }
    else {
      fprintf(stdout, "Failed to add %u rules to PM DB with "
              "handle %u.\n", failedRuleCount, llDbHandle);
    }
  }
  
  fclose(binFile_p);
  return status;
} /* _pmm_rules_from_bin_file_add */


/*
 * Adds expressions from the specified binary file.
 *
 * param pmmDbHandle    Handle of the PMM DB to use.
 * param binFileName_p  Name of the binary file to use.
 * retval               0 upon success;  -1 otherwise.
 */
static int
_pmm_regexs_from_bin_file_add(
  handle_t  pmmDbHandle,
  char     *binFileName_p
  )
{
  pm_exp_record_v_1_0_1_t  exp;
  pm_pattern_record_t     *currentPattern_p      = NULL;
  pm_pattern_record_t     *previousPattern_p     = NULL;
  FILE                    *binFile_p             = fopen(binFileName_p, "r");
  uint32_t                 recordType            = 0;
  uint32_t                 recordVersion         = 0;
  uint32_t                 pmeVersion            = 0;
  uint32_t                 siliconVersion        = 0;
  uint32_t                 expNameLength         = 0;
  uint32_t                 expStringLength       = 0;
  uint32_t                 optionStringLength    = 0;
  uint32_t                 patternsNum           = 0;
  uint32_t                 count                 = 0;
  uint32_t                 keyElementEntrySize   = 0;
  uint32_t                 confirmationEntrySize = 0;
  char                    *eofError_s            = 
    "EOF encountered while reading a regex record.\n";
  char                    *failError_s           = 
    "Failed to read a regex record.  \"%s\"\n";
  size_t                   readNum               = 0;
  uint32_t                 llIndex               = 0;
  pmll_status_t            pmllStatus            = pmll_ok_e;
  uint32_t                 failedExpCount        = 0;
  uint32_t                 addedExpCount         = 0;
  char                    *expString_p           = NULL;
  char                    *optionString_p        = NULL;
  char                    *expNameString_p       = NULL;
  uint32_t                 cleanup               = 0;
  _pmm_db_t               *pmmDb_p               = pmmDbHandle;
  unsigned int             llDbHandle            = pmmDb_p->llDbHandle;
  int                      status                = 0;
  

  /* Try to open the binary file to read the records from. */
  if (binFile_p == NULL) {
    fprintf(stdout, "Could not open file \"%s\".  \"%s\"\n", 
            binFileName_p,  strerror(errno));
    return errno;
  }

  /* Read the expression records from the file and add them to the LL
   * and PMM DBs. */
  while (true) {
    /* Read the record type. */
    readNum = fread(&recordType, sizeof(recordType), 1, binFile_p);
    if (1 != readNum) {
      if (0 == feof(binFile_p)) {
        fprintf(stdout, failError_s, strerror(errno));
        status = EINVAL;
      }
      break;
    }
    else {
      /* Make sure this is an expression record. */
      if (PM_COMPILED_REGEX_RECORD_TYPE != PMP_PMHWTOHL(recordType)) {
        fprintf(stdout, "Failed to read a record from a binary file.  The "
                "record has an unexpected record type of %#x.\n", 
                PMP_PMHWTOHL(recordType));
        status = EINVAL;
        break;
      }
    }
    
    /* Read the expression record version. */
    readNum = fread(&recordVersion, sizeof(recordVersion), 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    recordVersion = PMP_PMHWTOHL(recordVersion);
    /* Check if the read regex record version is as we expect it to
     * be. Currently these version are supported: 
     * PM_REGEX_BIN_RECORD_V_1_0_1 
     * PM_REGEX_BIN_RECORD_V_2_0_0 + PM_PME_VERSION_1_1 + PM_SI_VERSION_1_0 
     * PM_REGEX_BIN_RECORD_V_2_0_0 + PM_PME_VERSION_1_1 + PM_SI_VERSION_1_1 */
    if (PM_REGEX_BIN_RECORD_V_1_0_1 != recordVersion &&
        PM_REGEX_BIN_RECORD_V_2_0_0 != recordVersion) {
      fprintf(stdout, "Found unsupported binary regex record version of "
              "%d.%d.%d\n", recordVersion >> 16, 
              (recordVersion >> 8) & 0xff, recordVersion & 0xff);
      status = EINVAL;
      break;
    }
    if (PM_REGEX_BIN_RECORD_V_2_0_0 == recordVersion) {
      /* With PM_REGEX_BIN_RECORD_V_2_0_0, two more fields pmeVersion and 
       * siliconVersion are being checked here. */
      readNum = fread(&pmeVersion, sizeof(pmeVersion), 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        status = EINVAL;
        break;
      }
      pmeVersion = PMP_PMHWTOHL(pmeVersion);
      /* Only PME 1.1 is supported by this version of PMM. */
      if (PM_PME_VERSION_1_1 != pmeVersion) {
        fprintf(stdout, "Found unsupported PME version of "
                "%d.%d\n", pmeVersion >> 8, pmeVersion & 0xff);
        status = EINVAL;
        break;
      }
      readNum = fread(&siliconVersion, sizeof(siliconVersion), 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        status = EINVAL;
        break;
      }
      siliconVersion = PMP_PMHWTOHL(siliconVersion);
      /* Only silicon version 1.0 and 1.1 are supported by this 
       * version of PMM */
      if (PM_SI_VERSION_1_0 != siliconVersion &&
          PM_SI_VERSION_1_1 != siliconVersion) {
        fprintf(stdout, "Found unsupported silicon version of "
              "%d.%d\n", siliconVersion >> 8, siliconVersion & 0xff);
        status = EINVAL;
        break;
      }
      if (pmmDb_p->option8572rev1_0 && PM_SI_VERSION_1_0 != siliconVersion) {
        fprintf(stdout, "Found incompatible silicon version of "
              "%d.%d when %s option is enabled.\n", siliconVersion >> 8,
              siliconVersion & 0xff, _PMM_CMD_ARG_8572_REV_1_0);
        status = EINVAL;
        break;
      }
    }
    
    /* Read the expression name length. */
    readNum = fread(&expNameLength, sizeof(expNameLength), 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    expNameLength = PMP_PMHWTOHL(expNameLength);
    
    /* Read the expression name. */
    if (NULL != expNameString_p) { mem_free(expNameString_p); }
    expNameString_p = mem_calloc(1, expNameLength);
    if (NULL == expNameString_p) {
      fprintf(stdout, failError_s, strerror(errno));
      status = EINVAL;
      break;
    }
    readNum = fread(expNameString_p, expNameLength, 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }

    /* Read the expression string length. */
    readNum = fread(&expStringLength, sizeof(expStringLength), 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    expStringLength = PMP_PMHWTOHL(expStringLength);
    
    /* Read the expression string. */
    if (NULL != expString_p) { mem_free(expString_p); }
    expString_p = mem_calloc(1, expStringLength);
    if (NULL == expString_p) {
      fprintf(stdout, "Failed to allocate %u bytes of memory needed to "
              "read the expression string for the \"%s\" expression.\n", 
              expStringLength, expNameString_p);
      status = EINVAL;
      break;
    }
    readNum = fread(expString_p, expStringLength, 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    
    /* Read the option string length. */
    readNum = fread(&optionStringLength, sizeof(optionStringLength), 1, 
                    binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    optionStringLength = PMP_PMHWTOHL(optionStringLength);
    
    /* Read the option string. */
    if (NULL != optionString_p) { mem_free(optionString_p); }
    optionString_p = mem_calloc(1, optionStringLength);
    if (NULL == optionString_p) {
      fprintf(stdout, "Failed to allocate %u bytes of memory needed to "
              "read the option string for the \"%s\" expression.\n", 
              optionStringLength, expNameString_p);
      status = EINVAL;
      break;
    }
    readNum = fread(optionString_p, optionStringLength, 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }

    /* Read the number of patterns. */
    readNum = fread(&patternsNum, sizeof(patternsNum), 1, binFile_p);
    if (1 != readNum) {
      if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
      else { fprintf(stdout, failError_s, strerror(errno)); }
      status = EINVAL;
      break;
    }
    patternsNum = PMP_PMHWTOHL(patternsNum);

    currentPattern_p  = &(exp.patterns);
    previousPattern_p = NULL;

    currentPattern_p->nextPatternRecord_p = NULL;

    /* Read in each pattern */
    cleanup = 0;

    for (count = 0; count < patternsNum; count++) {
      /* The expression record already contains 1 pattern record. If
       * there is more than one pattern we need to allocate a new
       * pattern record. */
      if (count > 0) {
        currentPattern_p = (pm_pattern_record_t *)
          malloc(sizeof(pm_pattern_record_t));
        if (currentPattern_p == NULL) {
          cleanup = 1;
          status = ENOMEM;
          break;
        }
        memset(currentPattern_p, 0, sizeof(pm_pattern_record_t));
        previousPattern_p->nextPatternRecord_p = currentPattern_p;
      }
      
      /* Read the size of the key element entry. */
      readNum = fread(&keyElementEntrySize, sizeof(keyElementEntrySize), 1, 
                      binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        cleanup = 1;
        status = EINVAL;
        break;
      }
      keyElementEntrySize = PMP_PMHWTOHL(keyElementEntrySize);
      if (keyElementEntrySize > sizeof(currentPattern_p->keyElementEntry)) {
        fprintf(stdout, "Failed to read the key element entry for expression "
                "with name %s.  The size of the key element entry is %u which "
                "is longer than the expected maximum size of %Zd.\n", 
                expNameString_p, keyElementEntrySize, 
                sizeof(currentPattern_p->keyElementEntry));
        cleanup = 1;
        status = EINVAL;
        break;
      }
       
      /* Read the key element entry. */
      readNum = fread(&(currentPattern_p->keyElementEntry), 
                      keyElementEntrySize, 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        cleanup = 1;
        status = EINVAL;
        break;
      }
   
      /* Read the size of the confirmation entry. */
      readNum = fread(&confirmationEntrySize, sizeof(confirmationEntrySize), 
                      1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        cleanup = 1;
        status = EINVAL;
        break;
      }
      confirmationEntrySize = PMP_PMHWTOHL(confirmationEntrySize);
      if (confirmationEntrySize > 
          sizeof(currentPattern_p->confirmationEntry)) {
        fprintf(stdout, "Failed to read the confirmation entry for "
                "expression with name %s.  The size of the confirmation "
                "entry is %u which is longer than the expected maximum "
                "size of %Zd.\n", expNameString_p, confirmationEntrySize, 
                sizeof(currentPattern_p->confirmationEntry));
        cleanup = 1;
        status = EINVAL;
        break;
      }
   
      /* Read the confirmation entry. */
      readNum = fread(&(currentPattern_p->confirmationEntry), 
                      confirmationEntrySize, 1, binFile_p);
      if (1 != readNum) {
        if (0 != feof(binFile_p)) { fprintf(stdout, eofError_s); }
        else { fprintf(stdout, failError_s, strerror(errno)); }
        cleanup = 1;
        status = EINVAL;
        break;
      }
   
   
      /* Check if some of the parameters are not too long for the PMM
       * and LL limits. */
      if (expNameLength > sizeof(exp.name_s)) {
        fprintf(stdout, "Failed to add an expression record.  Expression name "
                "length of %u bytes is larger than the LL maximum supported "
                "size of %Zd.\n", expNameLength, sizeof(exp.name_s));
        cleanup = 1;
        status = EINVAL;
        break;
      }
      else {
        memcpy(&exp.name_s, expNameString_p, expNameLength);
        if (0 != exp.name_s[expNameLength - 1]) {
          fprintf(stdout, "Failed to add an expression record.  Found an "
                  "expression with name that is not NULL terminated.\n");
          cleanup = 1;
          status = EINVAL;
          break;
        }
      }
      if (expStringLength > _PMM_EXP_STRING_MAX_SIZE) {
        fprintf(stdout, "Failed to add an expression record with name "
                "\"%s\".  Expression string length of %u bytes is larger "
                "than the PMM maximum supported size of %u.\n", exp.name_s, 
                expStringLength, _PMM_EXP_STRING_MAX_SIZE);
        cleanup = 1;
        status = EINVAL;
        break;
      }
      if (0 != expString_p[expStringLength - 1]) {
        fprintf(stdout, "Failed to add an expression record with name "
                "\"%s\".  Expression string in this record is not NULL "
                "terminated.\n", exp.name_s);
        cleanup = 1;
        status = EINVAL;
        break;
      }
      if (optionStringLength > _PMM_EXP_OPTIONS_STRING_MAX_SIZE) {
        fprintf(stdout, "Failed to add an expression record with name "
                "\"%s\".  Expression option length of %u bytes is larger "
                "than the PMM maximum supported size of %u.\n", exp.name_s,
                expStringLength, _PMM_EXP_OPTIONS_STRING_MAX_SIZE);
        cleanup = 1;
        status = EINVAL;
        break;
      }
      if (0 != optionString_p[optionStringLength - 1]) {
        fprintf(stdout, "Failed to add an expression record with name "
                "\"%s\".  Options string in this record is not NULL "
                "terminated.\n", exp.name_s);
        cleanup = 1;
        status = EINVAL;
        break;
      }

      previousPattern_p = currentPattern_p;
    }

    /* Check if we exited abnormally from reading the patterns */
    if (cleanup) {
      /* Free any pattern objects that were created. */

      while (exp.patterns.nextPatternRecord_p != NULL)
      {
        currentPattern_p = exp.patterns.nextPatternRecord_p;

        exp.patterns.nextPatternRecord_p = 
          (exp.patterns.nextPatternRecord_p)->nextPatternRecord_p;

        free(currentPattern_p);
      }
      break;
    }


    /* Attempt to add the read regex record to the PMLL DB. */
    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Adding expression with name "
               "\"%s\" to the PMLL DB.", exp.name_s);
    pmllStatus = pmll_exp_add(llDbHandle, PMLL_EXP_RECORD_V_1_0_1, 
                              (pm_exp_record_t *)&exp, &llIndex);
    if (pmllStatus == pmll_ok_e) {
      addedExpCount++;
      /* Add the regex to the PMM DB. */
      if (NULL == _pmm_exp_add(pmmDb_p->expDbHandle, &exp, expString_p, 
                               optionString_p, llIndex)) {
        LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "Failed to add the \"%s\" "
                   "expression to the PMM DB.", exp.name_s);
        status = EIO;
      }
    }
    else {
      fprintf(stdout, "Failed to add regular expression with name "
              "\"%s\".  \"%s\"\n", exp.name_s, 
              pmll_error_string_get(pmllStatus));
      failedExpCount++;
      status = EIO;
    }

    /* Free any pattern objects that were created. */
    while (exp.patterns.nextPatternRecord_p != NULL)
    {
      currentPattern_p = exp.patterns.nextPatternRecord_p;

      exp.patterns.nextPatternRecord_p = 
        (exp.patterns.nextPatternRecord_p)->nextPatternRecord_p;

      free(currentPattern_p);
    }
  } /* while (true) */

  
  /* Free the expression and option string buffers. */
  if (NULL != expString_p)     { mem_free(expString_p); }
  if (NULL != optionString_p)  { mem_free(optionString_p); }
  if (NULL != expNameString_p) { mem_free(expNameString_p); }
  
  
  if (0 != addedExpCount) {
    if (1 == addedExpCount) {
      fprintf(stdout, "Successfully added one regex to the PM DB "
              "with handle %u.\n", llDbHandle);
    }
    else {
      fprintf(stdout,
              "Successfully added %u regexes to the PM DB with handle %u.\n",
              addedExpCount, llDbHandle);
    }
  }  
  if (0 != failedExpCount) {
    if (1 == failedExpCount) {
      fprintf(stdout, "Failed to add one regex to the PM DB with "
              "handle %u.\n", llDbHandle);
    }
    else {
      fprintf(stdout, "Failed to add %u expressions to PM DB with "
              "handle %u.\n", failedExpCount, llDbHandle);
    }
  }
  fclose(binFile_p);

  return status;
} /* _pmm_regexs_from_bin_file_add */


/* 
 * Generic add command.
 *
 * The "add" command is the overall command primitive for adding
 * regular expressions, rules, etc.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_add(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, 
             (NULL == cmd_p)? "NULL":cmd_p, cmd_p, context_p);
  
  int                     compile_result       = 0;
  int                     tmpSrcFileFd         = 0;
  int                     tmpBinFileFd         = 0;
  int32_t                 argc                 = 0;
  int                     rmStatus             = 0;
  int                     status               = EINVAL;
  char                   *argv_p[_PMM_PARAM_MAX_NUM];           
  struct stat             fileStats;
  bool                    errorFlag            = false;
  bool                    binFileSpecified     = false;
  pmsrc_error_codes_t     srcStatus            = pmsrc_ok_e;
  char                    tmpBinFileName[32]   = "/tmp/tmp.bin.XXXXXX";
  char                    tmpSrcFileName[32]   = "/tmp/tmp.src.XXXXXX";
  char                   *srcFileName_p        = NULL;
  char                   *binFileName_p        = tmpBinFileName;
  char                   *compiledFileName     = NULL;
  char                   *regex_string         = NULL;
  char                   *cmdCopy_p            = NULL;
  cli_status_t            cliStatus            = cli_error_e;
  handle_t                pmmDbHandle          = *((handle_t *)context_p);
  pmrec_module_options_t  recCompileOptions;
  pmsrc_module_options_t  srcCompileOptions;
  char                   *recCompileMessage_p  = NULL;
  char                   *srcCompileMessage_p  = NULL;
  _pmm_db_t              *pmmDb_p              = NULL;

  pmmDb_p = pmmDbHandle;
  /* Since cli_command_parse will replace all space and tab with \0,
   * we need to save the expression+option string first since it may
   * have spaces. */
  cmdCopy_p = malloc(strlen(cmd_p) + 2);
  if(cmdCopy_p == NULL)
  {
    fprintf(stdout, "Failed to allocate memory for the "
            "duplicate string.\n");
    return ENOMEM;
  }
  strcpy(cmdCopy_p, cmd_p);
  strcat(cmdCopy_p, "\n");


  /* Process the command line parametes.  If the regular expression
   * have a lot of space it can legally break the parameter number
   * limit. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e && cliStatus != cli_too_many_parameters_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }

  
  /* Process the help options. */
  if ((argc >= 2) &&
      ((strcmp(argv_p[1], _pmm_qm_keyword_sg)    == 0) ||
       (strcmp(argv_p[1], _pmm_h_keyword_sg)     == 0) ||
       (strcmp(argv_p[1], _pmm_help_keyword_sg)  == 0))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s %s %s %s <%s>"
            "\n\t%s %s %s %s <%s> [%s <%s>]"
            "\n\t%s %s %s <name> %s /<regex>/[options]"
            "\n\t%s %s %s %s <%s>"
            "\n\t%s %s %s %s <%s> [%s <%s>]\n",
            _pmm_add_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_add_cmd_sg, _pmm_help_keyword_sg,
            _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_file_keyword_sg, 
            _pmm_binary_keyword_sg, _pmm_filename_keyword_sg,
            _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_file_keyword_sg, 
            _pmm_source_keyword_sg, _pmm_filename_keyword_sg, 
            _pmm_binary_keyword_sg, _pmm_filename_keyword_sg,
            _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_name_keyword_sg, 
            _pmm_exp_keyword_sg,
            _pmm_add_cmd_sg, _pmm_rule_keyword_sg, _pmm_file_keyword_sg,
            _pmm_binary_keyword_sg, _pmm_filename_keyword_sg,
            _pmm_add_cmd_sg, _pmm_rule_keyword_sg, _pmm_file_keyword_sg, 
            _pmm_source_keyword_sg, _pmm_filename_keyword_sg, 
            _pmm_binary_keyword_sg, _pmm_filename_keyword_sg
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command is used to add expressions or rules to the "
        "\n\tlinker-loader DB.  The expression(s) or rule(s) to be added "
        "\n\tcan be in the \"%s\", or yet to be compiled, format or "
        "\n\tthey can be in the \"%s\", or already compiled, format.  "
        "\n\tIf the entity to be added is presented to this command in the "
        "\n\tsource format the entity is compiled first.  Only if the "
        "\n\tcompilation finishes successfully, the compiled entity is "
        "\n\tadded to the linker-loader DB.  If the entity to be added is "
        "\n\tpresented in the \"%s\" format the entity is added to the "
        "\n\tlinker-loader DB without any pre-processing.  Clearly, adding "
        "\n\texpressions or rules that are in the \"%s\" format is faster."
        "\n\tWhen adding \"%s\" formated entities from a file it is possible"
        "\n\tto have the compiled results stored in a \"%s\" formated file.  "
        "\n\tSpecify the optional \"%s\" keyword followed by a file name to"
        "\n\tdo that."
        "\n"
        "\n\tThe following options are supported by the \"%s %s %s\" "
        "\n\tcommand (after the expression i.e. /abc/[options]):"
        "\n\t  %s=<value>"
        "\n\t  %s"
        "\n\t  %s=<value>"
        "\n\t  i" 
        "\n\t  s" 
        "\n\t  m\n",
        _pmm_add_cmd_sg, _pmm_source_keyword_sg, _pmm_binary_keyword_sg, 
        _pmm_binary_keyword_sg,
        _pmm_binary_keyword_sg, _pmm_source_keyword_sg, _pmm_binary_keyword_sg, 
        _pmm_binary_keyword_sg, 
        _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_name_keyword_sg,
        _pmm_tag_keyword_sg,
        _pmm_report_keyword_sg,
        _pmm_counter_keyword_sg);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   The entity(ies) is presented or to be stored in the "
              "\n\t   binary, i.e., already compiled, format.", 
              _pmm_binary_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Specifies the counter to use while counting matches "
              "\n\t   of this expression.", _pmm_counter_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the following option contains the "
              "\n\t   regular expression to be added.  Note that the "
              "\n\t   regular expression option is delimited by the '/' "
              "\n\t   characters.", _pmm_exp_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   The entities to be added are to be read from a file.  "
              "\n\t   The name of the file follows this keyword.", 
              _pmm_file_keyword_sg);
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   The entity to be added is defined by parameters "
              "\n\t   specified in this command (and not, e.g., in a file).",
              _pmm_name_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   The supported options are listed in the description "
              "\n\t   section of this help.  More details on each option "
              "\n\t   can be found in the parameters section of this help.", 
              _pmm_options_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   The operation is to be performed on a regular "
              "\n\t   expression.", _pmm_regex_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Disables the generation of a match "
              "\n\t   report for this expression.", _pmm_report_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   The operation is to be performed on a rule.", 
              _pmm_rule_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Associates the expression with a set of expressions.",
              _pmm_set_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   The entity(ies) is presented in the source, i.e., "
              "\n\t   not yet compiled, format.", _pmm_source_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   This value is included in the match report for this "
              "\n\t   expression.  The value can be used to identify an "
              "\n\t   expression or a group of expressions.  Note that this "
              "\n\t   value could be chosen to be unique for each "
              "\n\t   expressions in the DB.", _pmm_tag_keyword_sg);
      fprintf(stdout, "\n");
      fprintf(stdout, "Examples:");
      fprintf(stdout, "\n\t%s %s %s %s myexpressions.src",
              _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_file_keyword_sg,
              _pmm_source_keyword_sg);
      fprintf(stdout, "\n\t%s %s %s e1 exp /matchme/tag=0x01",
              _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_name_keyword_sg);
      fprintf(stdout, "\n\t%s %s %s %s regexes.bin",
              _pmm_add_cmd_sg, _pmm_regex_keyword_sg, _pmm_file_keyword_sg, 
              _pmm_binary_keyword_sg);
      fprintf(stdout, "\n\t%s %s %s %s /tmp/rules.src %s /tmp/rules.bin",
              _pmm_add_cmd_sg, _pmm_rule_keyword_sg, _pmm_file_keyword_sg, 
              _pmm_source_keyword_sg, _pmm_binary_keyword_sg);
      fprintf(stdout, "\n");
    }
  }
  else if ((argc >= 2) && (0 == strcmp(argv_p[1], _pmm_regex_keyword_sg))) {
    /* Process the regex keyword. */
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_regex_keyword_sg);
    }
    else if (0 == strcmp(argv_p[2], _pmm_name_keyword_sg)) {
      /* Process the regex name keyword. */
      if (argc < 4) {
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_name_keyword_sg);
      }
      else {
        /*---------------------------------------------------------------*/
        /* add regex name <name> exp /<regular expression>/[options] */
        /*---------------------------------------------------------------*/
        if (argc < 5) {
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_name_keyword_sg);
        }
        else {
          /* Everything after 'exp' is considered the regex. */
          /* Check for expression key. */
          if (strcmp(argv_p[4], _pmm_exp_keyword_sg) == 0) {
            
            /* Everything following is the actual regular expression. */
            if (argc < 6) {
              fprintf(stdout, "Found no expression after the \"%s\" "
                      "keyword.\n", _pmm_exp_keyword_sg);
              free(cmdCopy_p);
              return EINVAL;
            }

            /* Calculate the pointer to the beginning of the expression. */
            regex_string = cmdCopy_p + 
              ((char*)argv_p[4] - cmd_p) + strlen(_pmm_exp_keyword_sg);
            
            /* Store the regex string in a file since the compiler
             * only accepts files. */
            tmpSrcFileFd = mkstemp(tmpSrcFileName);
            if (-1 == tmpSrcFileFd) {
              /* We failed to create and open a unique source file. */
              fprintf(stdout, "Could not open a temporary source file.  "
                      "\"%s\"\n", strerror(errno));
              free(cmdCopy_p);
              return EIO;
            }

            /* Regex name is in argv_p[3] */
            if (write(tmpSrcFileFd, argv_p[3], strlen(argv_p[3])) != 
                (ssize_t)(strlen(argv_p[3])) ||
                write(tmpSrcFileFd, regex_string, strlen(regex_string)) != 
                (ssize_t)(strlen(regex_string))) {
              fprintf(stdout, "Could not write to a temporary file "
                      "\"%s\".\n", tmpSrcFileName);
              close(tmpSrcFileFd);
              free(cmdCopy_p);
              return EIO;
            }

            /* Create a unique temporary binary file. */
            tmpBinFileFd = mkstemp(tmpBinFileName);
            if (-1 == tmpBinFileFd) {
              /* We failed to create and open a unique binary file. */
              fprintf(stdout, "Could not open a temporary binary file.  "
                      "\"%s\"\n", strerror(errno));
              close(tmpSrcFileFd);
              free(cmdCopy_p);
              return EIO;
            }
            close(tmpBinFileFd);
            close(tmpSrcFileFd);
            free(cmdCopy_p);
            cmdCopy_p = NULL;

            memset (&recCompileOptions, 0, sizeof(pmrec_module_options_t));

            recCompileOptions.debug_level            = pmrec_debug_none_e;
            recCompileOptions.group_definition       = pmrec_groups_default0_e;
            recCompileOptions.group_def_filename_p   = NULL;
            recCompileOptions.equivalence_definition = 
              pmrec_equivalence_default0_e;
            recCompileOptions.equiv_def_filename_p   = NULL;
            recCompileOptions.warnings_are_errors    = false;
            recCompileOptions.suppress_warnings      = false;
            recCompileOptions.hide_strings           = false;
            recCompileOptions.silicon_8572_rev_1_0   = pmmDb_p->option8572rev1_0;
            
            compile_result = pmrec_compile(
              tmpSrcFileName,       /* input */
              tmpBinFileName,       /* output */
              &recCompileOptions,   /* options */
              &recCompileMessage_p);/* compiler message */

            if (recCompileMessage_p != NULL)
            {
               fprintf(stdout, "%s\n", recCompileMessage_p);

               /* Free the memory that was allocated by the compiler lib. */
               free (recCompileMessage_p);
            }

            if (compile_result == pmrec_ok_e ||
                compile_result == pmrec_warnings_e) {
              if (compile_result == pmrec_ok_e) {
                fprintf(stdout, "Successfully compiled the expression.\n");
              }
              else {
                fprintf(stdout, "Compiled the expression with warnings.\n");
              }
                            
              status = _pmm_regexs_from_bin_file_add(_pmm_db_handle_sg,
                                                     tmpBinFileName);

              /* Remove the temporary binary file. */
              rmStatus = remove(tmpBinFileName);
              if (0 != rmStatus) {
                fprintf(stdout, "Failed to remove the temporary file "
                        "\"%s\".  \"%s\"\n", tmpBinFileName, 
                        strerror(errno));
              }
            } /* if - compilation was successful. */
            else {
              status = EIO;
              fprintf(stdout, "Compile failed with error: %s\n",
                      pmrec_get_error_string(compile_result));
            }
            
            /* Remove the temporary source file. */
            rmStatus = remove(tmpSrcFileName);
            if (0 != rmStatus) {
              fprintf(stdout, "Failed to remove the temporary file "
                      "\"%s\".  \"%s\"\n", tmpSrcFileName, 
                      strerror(errno));
            }
          }
          else {
            fprintf(stdout, "Unrecognized keyword: \"%s\" Was expecting "
                    "\"%s\".\n", argv_p[4], _pmm_exp_keyword_sg);
          }
        } /* else - there are more parameters after name. */
      } /* else - name was specified. */
    } /* if - regex name keyword processing. */
    else if (0 == strcmp(argv_p[2], _pmm_file_keyword_sg)) {
      /* Process the regex file keyword. */
      if (argc < 4) {
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_file_keyword_sg);
      }
      else if (0 == strcmp(argv_p[3], _pmm_binary_keyword_sg)) {
        if (argc < 5) {
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_binary_keyword_sg);
        }
        else if (argc > 5) {
          fprintf(stdout, _pmm_too_many_params_sg, _pmm_binary_keyword_sg);
        }
        else {
          /*-----------------------------------------------------------------*/
          /* add regex file binary <filename> */
          /*-----------------------------------------------------------------*/
            /* Process the regex file binary keyword. */
          status = _pmm_regexs_from_bin_file_add(_pmm_db_handle_sg, argv_p[4]);
        }
      } /* if - regex file binary keyword processing. */
      else if (0 == strcmp(argv_p[3], _pmm_source_keyword_sg)) {
        /*----------------------------------------------------------------*/
        /* add regex file source <filename> */
        /*----------------------------------------------------------------*/
        if (argc < 5) {
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_source_keyword_sg);
        }
        else {
          /* The source file name is specified, check if it exists. */
          if (-1 == stat(argv_p[4], &fileStats)) {
            fprintf(stdout, "Could not find the \"%s\" regex source file.  "
                    "\"%s\"\n", argv_p[4], strerror(errno));
            errorFlag = true;
          }
          else {
            if (false == S_ISREG(fileStats.st_mode)) {
              fprintf(stdout, "\"%s\" is not a name of a regular file.\n",
                      argv_p[4]);
              errorFlag = true;
            }
            else {
              /* Check if the binary file name is specified. */
              binFileName_p    = NULL;
              binFileSpecified = false;
              if (argc > 5) {
                if (0 == strcmp(argv_p[5], _pmm_binary_keyword_sg)) {
                  if (argc < 7) {
                    fprintf(stdout, _pmm_too_few_params_sg, 
                            _pmm_binary_keyword_sg);
                    errorFlag = true;
                  }
                  else {
                    binFileName_p    = argv_p[6];
                    binFileSpecified = true;
                  }
                }
                else {
                  fprintf(stdout, _pmm_invalid_param_sg, argv_p[5], 
                          _pmm_file_keyword_sg);
                  errorFlag = true;
                }
              }
            }
          }

          if (false == errorFlag) {
            /* Check if there are not too many parameters. */
            if (argc > 7) {
              fprintf(stdout, _pmm_too_many_params_sg, _pmm_file_keyword_sg);
            }
            else {
              /* Compile the "source" file and generate the binary file. */
              if (true == binFileSpecified) {
                compiledFileName = argv_p[6];
              }
              else {
                /* Create a unique temporary binary file. */
                tmpBinFileFd = mkstemp(tmpBinFileName);
                if (-1 == tmpBinFileFd) {
                  /* We failed to create and open a unique binary file. */
                  fprintf(stdout, "Could not create a temporary binary file.  "
                          "\"%s\"\n", strerror(errno));
                  errorFlag = true;
                }
                else close(tmpBinFileFd);
                compiledFileName = tmpBinFileName;
              }
              if (false == errorFlag) {
                memset (&recCompileOptions, 0, sizeof(pmrec_module_options_t));

                recCompileOptions.debug_level            = pmrec_debug_none_e;
                recCompileOptions.group_definition       = 
                  pmrec_groups_default0_e;
                recCompileOptions.group_def_filename_p   = NULL;
                recCompileOptions.equivalence_definition = 
                  pmrec_equivalence_default0_e;
                recCompileOptions.equiv_def_filename_p   = NULL;
                recCompileOptions.warnings_are_errors    = false;
                recCompileOptions.hide_strings           = false;
                recCompileOptions.silicon_8572_rev_1_0   = pmmDb_p->option8572rev1_0;

                compile_result = pmrec_compile(
                  (char *)argv_p[4],     /* input */
                  compiledFileName,      /* output */
                  &recCompileOptions,    /* options */
                  &recCompileMessage_p); /* compiler message */
              
                if (recCompileMessage_p != NULL)
                {
                   fprintf(stdout, "%s\n", recCompileMessage_p);

                   /* Free the memory that was allocated by the
                    * compiler lib. */
                   free (recCompileMessage_p);
                }

                if ((compile_result == pmrec_ok_e) || 
                    (compile_result == pmrec_warnings_e)) {
                  if (compile_result == pmrec_ok_e) {
                    fprintf(stdout, "Successfully compiled the \"%s\" "
                            "expression source file.", argv_p[4]);
                  }
                  else {
                    fprintf(stdout, "The \"%s\" file was compiled with "
                            "warnings.", argv_p[4]);
                  }
                  
                  if (true == binFileSpecified) {
                    fprintf(stdout, "\nCompiled file: %s.", binFileName_p);
                  }
                  fprintf(stdout, "\n");
                  
                  status = _pmm_regexs_from_bin_file_add(_pmm_db_handle_sg, 
                                                         compiledFileName);
                  
                  /* Remove the temporary file if the binary file name
                   * was not specified. */
                  if (false == binFileSpecified) {
                    rmStatus = remove(compiledFileName);
                    if (0 != rmStatus) {
                      fprintf(stdout, "Failed to remove the temporary \"%s\" "
                              "binary file.  \"%s\"\n", compiledFileName, 
                              strerror(errno));
                    }
                  }
                } /* if - compilation was successful. */
                else {
                  fprintf(stdout, "Compilation of the file \"%s\" failed "
                          "with error: %s\n", argv_p[4], 
                          pmrec_get_error_string(compile_result));
                }
              }
            } /* else - the number of parameters is ok. */
          } /* if - no errors so far. */
        } /* else - there are at least 5 parameters. */
      } /* if - regex file source keyword processing. */
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[3], 
                _pmm_file_keyword_sg);
      }
    } /* if - regex file keyword processing. */
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_regex_keyword_sg);
    }
  } /* else if - regex keyword processing. */
  else if ((argc >= 2) && (0 == strcmp(argv_p[1], _pmm_rule_keyword_sg))) {
    /* Process the rule keyword. */
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_rule_keyword_sg);
    }
    else if (0 == strcmp(argv_p[2], _pmm_file_keyword_sg)) {
      /* Process the rule file keyword. */
      if (argc < 4) {
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_file_keyword_sg);
      }
      else if (0 == strcmp(argv_p[3], _pmm_binary_keyword_sg)) {
        /*-----------------------------------------------------------------*/
        /* add rule file binary <filename> */
        /*-----------------------------------------------------------------*/
        /* Process the rule file binary keyword. */
        if (argc < 5) {
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_binary_keyword_sg);
        }
        else if (argc > 5) {
          fprintf(stdout, _pmm_too_many_params_sg, _pmm_binary_keyword_sg);
        }
        else {
          binFileName_p = argv_p[4];
          /* Add rules from the compiled file. */
          status = _pmm_rules_from_bin_file_add(pmmDbHandle, binFileName_p);
        }
      } /* if - rule file binary keyword processing. */
      else if (0 == strcmp(argv_p[3], _pmm_source_keyword_sg)) {
        /*----------------------------------------------------------------*/
        /* add rule file source <filename> */
        /*----------------------------------------------------------------*/
        /* Process the rule file source keyword. */
        if (argc < 5) {
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_source_keyword_sg);
        }
        else {
          /* The source file name is specified, check if it exists. */
          if (-1 == stat(argv_p[4], &fileStats)) {
            fprintf(stdout, "Could not find the \"%s\" rule source file.  "
                    "\"%s\"\n", argv_p[4], strerror(errno));
            errorFlag = true;
          }
          else {
            if (false == S_ISREG(fileStats.st_mode)) {
              fprintf(stdout, "\"%s\" is not a name of a regular file.\n",
                      argv_p[4]);
              errorFlag = true;
            }
            else {
              srcFileName_p = argv_p[4];
              
              /* Check if the binary file name is specified. */
              if (argc > 5) {
                if (0 == strcmp(argv_p[5], _pmm_binary_keyword_sg)) {
                  if (argc < 7) {
                    fprintf(stdout, _pmm_too_few_params_sg, 
                            _pmm_binary_keyword_sg);
                    errorFlag = true;
                  }
                  else {
                    binFileName_p    = argv_p[6];
                    binFileSpecified = true;
                  }
                }
                else {
                  fprintf(stdout, _pmm_invalid_param_sg, argv_p[5], 
                          _pmm_file_keyword_sg);
                  errorFlag = true;
                }
              }
            }
          } /* else - check the source file name. */
        
          /* Get a unique binary file name if the name was not specified. */
          if ((false == errorFlag) && (false == binFileSpecified)) {
            /* Create a unique temporary binary file. */
            tmpBinFileFd = mkstemp(binFileName_p);
            if (-1 == tmpBinFileFd) {
              /* We failed to create and open a unique binary file. */
              fprintf(stdout, "Could not create a temporary binary file.  "
                      "\"%s\"\n", strerror(errno));
              errorFlag = true;
            }
            else close(tmpBinFileFd);
          }
        
          if (false == errorFlag) {
            /* Check if there are not too many parameters. */
            if (argc > 7) {
              fprintf(stdout, _pmm_too_many_params_sg, _pmm_file_keyword_sg);
            }
            else {
              /* Compile the "source" file and generate the binary file. */

              srcCompileOptions.debug_level         = pmsrc_debug_off_e;
              srcCompileOptions.report_pad          = pmsrc_report_pad4_e;
              srcCompileOptions.string_pad          = PMSRC_DEFAULT_STRING_PAD;
              srcCompileOptions.report_cnst_sz      = pmsrc_report_cnst_sz4_e;
              srcCompileOptions.allow_inconclusive  = 
                pmsrc_conclusive_only_matches_e;
              srcCompileOptions.warnings_are_errors = false;
              srcCompileOptions.suppress_warnings   = false;

              srcStatus = pmsrc_compile(srcFileName_p, 
                                        binFileName_p,
                                        &srcCompileOptions,
                                        &srcCompileMessage_p); 

              if (srcCompileMessage_p != NULL)
              {
                 fprintf(stdout, "%s\n", srcCompileMessage_p);
                 free (srcCompileMessage_p);
              }

              if ((pmsrc_ok_e == srcStatus) || 
                  (pmsrc_warnings_e == srcStatus)) {
                if (pmsrc_warnings_e == srcStatus) {
                  fprintf(stdout, "Successfully compiled the \"%s\" rule "
                          "source file with warnings.\n", srcFileName_p);
                }
                else {
                  fprintf(stdout, "Successfully compiled the \"%s\" rule "
                          "source file.\n", srcFileName_p);
                }
                
                /* Add rules from the compiled file. */
                status = _pmm_rules_from_bin_file_add(pmmDbHandle, 
                                                      binFileName_p);
                
                /* Remove the temporary file if the binary file name
                 * was not specified. */
                if (false == binFileSpecified) {
                  rmStatus = remove(binFileName_p);
                  if (0 != rmStatus) {
                    fprintf(stdout, "Failed to remove the temporary \"%s\" "
                            "binary file.  \"%s\"\n", binFileName_p, 
                            strerror(errno));
                  }
                }
              } /* if - so far there were no errors. */
              else {
                /* The compilation failed. */
                fprintf(stdout, "Failed to compile the \"%s\" rule source "
                        "file.  %s\n", srcFileName_p, 
                        pmsrc_get_error_string(srcStatus));
              }
            } /* else - the number of parameters is ok. */
          } /* if - no errors so far. */
        } /* else - the source file name is specified. */
      } /* if - rule file source keyword processing. */
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[3], 
                _pmm_file_keyword_sg);
      }
    } /* if - rule file keyword processing. */
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_rule_keyword_sg);
    }
  } /* else if - rule keyword processing. */
  else if (argc >= 2) {
    fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_add_cmd_sg);
  }
  else {
    fprintf(stdout, _pmm_too_few_params_sg, _pmm_add_cmd_sg);
  }
  
  /* Free regex_string here if there were syntax or file I/O error. */
  if(cmdCopy_p != NULL) free(cmdCopy_p);
  
  return status;
} /* _pmm_pm_menu_add */


/*
 * Delete a single rule from both the LL and PMM DBs.
 *
 * param llDbHandle   Handle of the PMLL DB to use.
 * param pmmDbHandle  Handle of the PMM DB to use.
 * param llIndex      LL index of the rule record to delete.
 * param pmmIndex     PMM index of the rule record to delete.
 * retval             "true" upon success, "false" otherwise.
 */
static bool
_pmm_rule_delete(
  unsigned int  llDbHandle,
  handle_t      pmmDbHandle,
  uint32_t      llIndex,
  uint32_t      pmmIndex
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: "
             "%s(llDbHandle=%u, pmmDbHandle=%"PRI_HANDLE", llIndex=%u, "
             "pmmIndex=%u).", __func__, llDbHandle, pmmDbHandle,
             llIndex, pmmIndex);

  pmll_status_t       pmllStatus = pmll_ok_e;
  bool                status     = true;
  _pmm_rule_record_t *rule_p     = NULL;


  /* Get the pointer to the rule record. */
  rule_p = db_record_by_index_get(pmmDbHandle, pmmIndex);
  if (NULL == rule_p) {
    fprintf(stdout, "Rule with index %u does not exist.", pmmIndex);
    return (false);
  }
  
  if (llIndex != pmmIndex) {
    /* We can do this comparison since the same DB module is used by
     * both PMM and LL modules and the records are added and removed
     * to/from both DBs at the same time. */
    LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "LL and PMM indexes are "
               "different (llIndex=%u, pmmIndex=%u.", llIndex, pmmIndex);
    status = false;
  }
  else {
    /* Delete the rule from the LL database. */
    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Deleting rule with index %u "
               "from PMLL DB with handle=%u.", llIndex, llDbHandle);
    pmllStatus = pmll_rule_delete(llDbHandle, llIndex);
    if (pmll_ok_e != pmllStatus) {
      fprintf(stdout, "Deleting rule with LL index=%u from the LL "
              "DB failed with the following error: \"%s\"\n", 
              llIndex, pmll_error_string_get(pmllStatus));
      status = false;
    }
    else {
      /* Delete the rule from the PMM rule DB. */
      LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Deleting rule with index %u "
                 "from PMM DB with handle=%"PRI_HANDLE".", pmmIndex, 
                 pmmDbHandle);
      db_status_t dbStatus = db_record_by_index_delete(pmmDbHandle, pmmIndex);
      if (db_ok_e != dbStatus) {
        LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "Failed to delete rule with "
                   "index %u from the PMM rule DB.  %s", pmmIndex,
                   db_error_string_get(dbStatus));
        status = false;
      }
    }
  }

  /* Free the rule record. */
  _pmm_pmm_rule_free(rule_p);
  
  return status;
} /* _pmm_rule_delete */


/*
 * Delete a single expression from both the LL and PMM DBs.
 *
 * param llDbHandle   Handle of the PMLL DB to use.
 * param pmmDbHandle  Handle of the PMM DB to use.
 * param llIndex      LL index of the rule record to delete.
 * param pmmIndex     PMM index of the rule record to delete.
 * retval             "true" upon success, "false" otherwise.
 */
static bool
_pmm_exp_delete(
  unsigned int  llDbHandle,
  handle_t      pmmDbHandle,
  uint32_t      llIndex,
  uint32_t      pmmIndex
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: "
             "%s(llDbHandle=%u, pmmDbHandle=%"PRI_HANDLE", "
             "llIndex=%u, pmmIndex=%u).", __func__, llDbHandle, 
             pmmDbHandle, llIndex, pmmIndex);

  pmll_status_t     pmllStatus = pmll_ok_e;
  bool              status     = true;
  pm_rule_record_t *exp_p      = NULL;


  /* Get the pointer to the expression record. */
  exp_p = db_record_by_index_get(pmmDbHandle, pmmIndex);
  if (NULL == exp_p) {
    fprintf(stdout, "Expression with index %u does not exist.", pmmIndex);
    return (false);
  }
    
  if (llIndex != pmmIndex) {
    /* We can do this comparison since the same DB module is used by
     * both PMM and LL modules and the records are added and removed
     * to/from both DBs at the same time. */
    LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "LL and PMM indexes are "
               "different (llIndex=%u, pmmIndex=%u.", llIndex, pmmIndex);
    status = false;
  }
  else {
    /* Delete the expression from the LL database. */
    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Deleting expression with index %u "
               "from PMLL DB with handle=%u.", llIndex, llDbHandle);
    pmllStatus = pmll_exp_delete(llDbHandle, llIndex);
    if (pmll_ok_e != pmllStatus) {
      fprintf(stdout, "Deleting expression with LL index=%u from the LL "
              "DB failed with the following error: \"%s\"\n", 
              llIndex, pmll_error_string_get(pmllStatus));
      status = false;
    }
    else {
      /* Delete the expression from the PMM expression DB. */
      LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Deleting expression with "
                 "index %u from PMM DB with handle=%"PRI_HANDLE".", pmmIndex, 
                 pmmDbHandle);
      db_status_t dbStatus = db_record_by_index_delete(pmmDbHandle, pmmIndex);
      if (db_ok_e != dbStatus) {
        LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "Failed to delete "
                   "expression with index %u from the PMM expression DB.  "
                   "%s", pmmIndex, db_error_string_get(dbStatus));
        status = false;
      }
      else {
        /* Free the expression record. */
        mem_free(exp_p);
      }
    }
  }

  return status;
} /* _pmm_exp_delete */


/*
 * Delete all the expressions in the PMM and PMLL DBs.
 *
 * param pmmDbHandle    Handle of the PMM DB to use.
 * retval               0 upon success, an error code otherwise.
 */
static int
_pmm_exp_all_delete(
  handle_t  pmmDbHandle
  )
{
  uint32_t           pmmExpIndex = IDX_NULL_INDEX;
  _pmm_exp_record_t *exp_p       = NULL;
  uint32_t           counter     = 0;
  _pmm_db_t         *pmmDb_p     = pmmDbHandle;
  bool               boolStatus  = true;
  int                status      = 0;
  

  while (NULL != (exp_p = db_record_next_get(pmmDb_p->expDbHandle, 
                                             &pmmExpIndex))) {
    pmmExpIndex = exp_p->pmmIndex;
    boolStatus = _pmm_exp_delete(pmmDb_p->llDbHandle, pmmDb_p->expDbHandle, 
                                 exp_p->llIndex, exp_p->pmmIndex);
    if (false == boolStatus) {
      status = EIO;
    }
    counter++;
    if (counter > PM_PATTERN_MAX_NUM) {
      LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "Must break out from the "
                 "delete all expression loop.");
      break;
    }
  } /* while - for all expressions in the DB */

  return status;
} /* _pmm_exp_all_delete */


/*
 * Delete all the rules in the PMM and PMLL DBs.
 *
 * param pmmDbHandle    Handle of the PMM DB to use.
 * retval               0 upon success, an error code otherwise.
 */
static int
_pmm_rule_all_delete(
  handle_t  pmmDbHandle
  )
{
  uint32_t            pmmRuleIndex = IDX_NULL_INDEX;
  _pmm_rule_record_t *rule_p       = NULL;
  uint32_t            counter      = 0;
  _pmm_db_t          *pmmDb_p      = pmmDbHandle;
  bool                boolStatus   = true;
  int                 status       = 0;


  while (NULL != (rule_p = db_record_next_get(pmmDb_p->ruleDbHandle, 
                                              &pmmRuleIndex))) {
    pmmRuleIndex = rule_p->pmmIndex;
    boolStatus = _pmm_rule_delete(pmmDb_p->llDbHandle, pmmDb_p->ruleDbHandle, 
                                  rule_p->llIndex, rule_p->pmmIndex);
    if (false == boolStatus) {
      status = EIO;
    }
    counter++;
    if (counter > PMLL_RULE_MAX_NUM) {
      LOG_STRING(LOG_ERROR, _PMM_MODULE_NAME, "Must break out from the "
                 "delete all rule loop.");
      break;
    }
  } /* while - for all expressions in the DB */

  return status;
} /* _pmm_rule_all_delete */


/* Destroy the indicated PMM database.
 *
 * param pmmDbHandle  Handle of the PMM DB to destroy.
 * retval             true upon success; false otherwise.
 */
static bool
_pmm_db_destroy(
  handle_t  pmmDbHandle
  )
{
  PmlaError_t    pmlaStatus   = pmlaSuccess_c;
  pmll_status_t  pmllStatus   = pmll_ok_e;
  db_status_t    dbStatus     = db_ok_e;
  bool           returnStatus = true;
  _pmm_db_t     *pmmDb_p      = pmmDbHandle;
 

  if (HANDLE_NULL == pmmDb_p) {
    return true;
  }
  

  /* Shut down the PMLA communication channel used by PMLL. */
  if (HANDLE_NULL != pmmDb_p->pmlaForPmllHandle) {
    pmlaStatus = pmlaClose(pmmDb_p->pmlaForPmllHandle);
    if (pmlaSuccess_c != pmlaStatus) {
      LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to destroy the %s "
                 "connection used by %s.  \"%s\"\n", PMLA_MODULE_NAME, 
                 PMLL_MODULE_NAME, pmlaErrorString(pmlaStatus));
      returnStatus = false;
    }
  }


  /* Shut down the PMLA communication channel used by PMM. */
  if (HANDLE_NULL != pmmDb_p->pmlaForPmmHandle) {
    pmlaStatus = pmlaClose(pmmDb_p->pmlaForPmmHandle);
    if (pmlaSuccess_c != pmlaStatus) {
      LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to destroy the %s "
                 "connection used by %s.  \"%s\"\n", PMLA_MODULE_NAME, 
                 _PMM_MODULE_NAME, pmlaErrorString(pmlaStatus));
      returnStatus = false;
    }
  }
 

  /* Delete all the expressions and rules in the PMM expression and
   * rule DBs. */
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Deleting all the rule records.");
  _pmm_rule_all_delete(pmmDbHandle);
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Deleting all the expression "
             "records.");
  _pmm_exp_all_delete(pmmDbHandle);
  

  /* Destroy the PMLL DB. */
  if (_PMM_NULL_PMLL_DB_HANDLE != pmmDb_p->llDbHandle) {
    LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Destroying the PMLL DB.");
    pmllStatus = pmll_db_destroy(pmmDb_p->llDbHandle);
    if (pmll_ok_e != pmllStatus) {
      LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to destroy the "
                 "PMLL DB.  \"%s\"\n", pmll_error_string_get(pmllStatus));
      returnStatus = false;
    }
  }
  

  /* Destroy the PMM rule and expression DBs. */
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Destroying the PMM rule DB.");
  dbStatus = db_db_destroy(pmmDb_p->ruleDbHandle);
  if (db_ok_e != dbStatus) {
    LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to destroy the PMM rule "
               "DB.  \"%s\"\n", db_error_string_get(dbStatus));
    returnStatus = false;
  }
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Destroying the PMM expression "
             "DB.");
  dbStatus = db_db_destroy(pmmDb_p->expDbHandle);
  if (db_ok_e != dbStatus) {
    LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to destroy the PMM "
               "expression DB.  \"%s\"\n", db_error_string_get(dbStatus));
    returnStatus = false;
  }
  
  /* Free the PMM DB record. */
  mem_free(pmmDb_p);
  
  return true;
} /* _pmm_db_destroy */


/* Create a PMM database.
 *
 * param appParams_p  Parameters for pmm application and this DB.
 * retval             Handle of the newly created PMM DB upon success;
 *                    a NULL handle otherwise.
 */
static handle_t
_pmm_db_create(
  _pmm_app_params_t *appParams_p
  )
{
  PmlaError_t       pmlaStatus = pmlaSuccess_c;
  bool              statusOk   = true;
  pmll_status_t     pmllStatus = pmll_ok_e;
  db_status_t       dbStatus   = db_ok_e;
  pmll_db_params_t  pmllDbParams;
  memset(&pmllDbParams, 0, sizeof(pmll_db_params_t));
  

  _pmm_db_t *pmmDb_p = mem_calloc(1, sizeof(_pmm_db_t));
  if (NULL == pmmDb_p) {
    fprintf(stdout, "Failed to allocate %Zd bytes of memory needed for "
            "a new %s DB.\n", sizeof(_pmm_db_t), _PMM_MODULE_NAME);
    return HANDLE_NULL;
  }

  /* Reset the PMM DB. */
  pmmDb_p->llDbHandle        = _PMM_NULL_PMLL_DB_HANDLE;
  pmmDb_p->pmlaForPmllHandle = HANDLE_NULL;
  pmmDb_p->pmlaForPmmHandle  = HANDLE_NULL;
  pmmDb_p->expDbHandle       = HANDLE_NULL;
  pmmDb_p->ruleDbHandle      = HANDLE_NULL;
  pmmDb_p->option8572rev1_0  = appParams_p->option8572rev1_0Flag;

  /* Create the PMM expression DB. */
  dbStatus = db_db_create(PM_PATTERN_MAX_NUM, "PMM expression DB",
                          &pmmDb_p->expDbHandle);
  if (db_ok_e != dbStatus) {
    fprintf(stdout, "Failed to create the PMM expression DB.  %s\n",
            db_error_string_get(dbStatus));
    statusOk = false;
  }


  if (true == statusOk) {
    /* Create the PMM rule DB. */
    dbStatus = db_db_create(PMLL_RULE_MAX_NUM, "PMM rule DB", 
                            &pmmDb_p->ruleDbHandle);
    if (db_ok_e != dbStatus) {
      fprintf(stdout, "Failed to create the PMM rule DB.  %s\n", 
              db_error_string_get(dbStatus));
      statusOk = false;
    }
  }


  if (true == statusOk) {
    /* Create a PMLA connection to the PM H/W to be used by the PMM. */
    pmlaStatus = _pmm_pmla_connection_create(appParams_p->targetIpv4Address, 
                                             appParams_p->targetIpv4Port, 
                                             appParams_p->targetChannelId,
                                             appParams_p->pmlaChannelTimeout, 
                                             &pmmDb_p->pmlaForPmmHandle);
    if (pmlaSuccess_c != pmlaStatus) {
      fprintf(stdout, "Failed to create a %s control channel to be used by "
              "the %s module.  %s\n", PMLA_MODULE_NAME, _PMM_MODULE_NAME, 
              pmlaErrorString(pmlaStatus));
      statusOk = false;
    }
  }


  /* Retrieve the target specific parameters requried to create a PMLL DB. */
  if (true == statusOk) {
    if (true == appParams_p->hwSimFlag) {
      /* The H/W simulation mode is on.  We use a predefined values
       * for the DB parameters.  Note that the H/W simulation on this
       * level is an unsupported feature and can be removed at any
       * time.  We use constants and not macros to emphasize the
       * volatality of the H/W simulation feature. */
      pmllDbParams.dxeSreTableSize   = 65536;
      pmllDbParams.sreSessionCtxSize = 32768;
      pmllDbParams.sreSessionCtxNum  = 1024;
      pmllDbParams.sreRuleNum        = PM_STATEFUL_RULE_MAX_NUM;
    }
    else {
      statusOk = _pmm_target_params_get(pmmDb_p->pmlaForPmmHandle,
                                        &pmllDbParams);
      if (false == statusOk) {
        fprintf(stdout, "Failed to retrieve platform specific DB "
                "parameters.\n");
      }
    }
  }
    

  if (true == statusOk) {
    /* Create the PMLL DB. */
    pmllDbParams.pmlaFunctions.pmlaBulkBeginFunction_p      = 
      pmlaSendBulkBegin;
    pmllDbParams.pmlaFunctions.pmlaBulkEndFunction_p        = pmlaSendBulkEnd;
    pmllDbParams.pmlaFunctions.pmlaFlushFunction_p          = pmlaFlush;
    pmllDbParams.pmlaFunctions.pmlaReadFunction_p           = pmlaRecv;
    pmllDbParams.pmlaFunctions.pmlaWriteFunction_p          = pmlaSend;
    pmllDbParams.pmlaFunctions.pmlaErrorStringGetFunction_p = pmlaErrorString; 

    pmllStatus = pmll_db_create(&pmllDbParams, &pmmDb_p->llDbHandle);
    if (pmll_ok_e != pmllStatus) {
      fprintf(stdout, "Failed to create the PMLL DB.  \"%s\"\n", 
              pmll_error_string_get(pmllStatus));
      statusOk = false;
    }
  }


  if (true == statusOk) {
    /* Create a PMLA connection to the PM H/W and associate the handle
     * of this connection with the created PMLL DB. */
    pmlaStatus = _pmm_pmla_connection_create(appParams_p->targetIpv4Address, 
                                             appParams_p->targetIpv4Port, 
                                             appParams_p->targetChannelId,
                                             appParams_p->pmlaChannelTimeout, 
                                             &pmmDb_p->pmlaForPmllHandle);
    if (pmlaSuccess_c != pmlaStatus) {
      fprintf(stdout, "Failed to create a %s control channel to be used by "
              "the %s module.  \"%s\"\n", PMLA_MODULE_NAME, PMLL_MODULE_NAME, 
              pmlaErrorString(pmlaStatus));
      statusOk = false;
    }
    else {
      pmllStatus = pmll_connection_handle_set(pmmDb_p->llDbHandle, 
                                              pmmDb_p->pmlaForPmllHandle);
      if (pmll_ok_e != pmllStatus) {
        fprintf(stdout, "Failed to set the %s control channel handle in "
                "the %s DB.  \"%s\"\n", PMLA_MODULE_NAME, PMLL_MODULE_NAME, 
                pmll_error_string_get(pmllStatus));
        statusOk = false;
      }
    }
  }


  if (true == statusOk) {
    return pmmDb_p;
  }
  else {
    (void)_pmm_db_destroy(pmmDb_p);
  }
    
  return HANDLE_NULL;
} /* _pmm_db_create */


/*
 * Generic delete command.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_delete(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, 
             (NULL == cmd_p)? "NULL":cmd_p, cmd_p, context_p);

  char               *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t             argc        = 0;
  int32_t             i           = 0;
  _pmm_exp_record_t  *exp_p       = NULL;
  _pmm_rule_record_t *rule_p      = NULL;
  cli_status_t        cliStatus   = cli_error_e;
  handle_t            pmmDbHandle = *((handle_t *)context_p);
  _pmm_db_t          *pmmDb_p     = pmmDbHandle;
  int                 status      = EINVAL;
  
  
  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }

  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s %s|%s %s"
            "\n\t%s %s|%s %s <name1> [<name2> ... <name%u>]\n",
            _pmm_delete_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_delete_cmd_sg, _pmm_help_keyword_sg,
            _pmm_delete_cmd_sg, _pmm_exp_keyword_sg, _pmm_rule_keyword_sg, 
            _pmm_all_keyword_sg,
            _pmm_delete_cmd_sg, _pmm_exp_keyword_sg, _pmm_rule_keyword_sg, 
            _pmm_name_keyword_sg, _PMM_PARAM_MAX_NUM - 3
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command is used to delete previously added expressions "
        "\n\tor rules.  One or more expressions or rules can be deleted with "
        "\n\tone command.  The number of the expression or rule names "
        "\n\taccepted by the command is limited by the number of arguments "
        "\n\tallowed in a CLI command."
        "\n\t"
        "\n\tNote that when a request had been made to delete all items of a "
        "\n\tgiven kind and the operation completed with an error then, in "
        "\n\tgeneral, only the items that could be deleted were deleted while"
        "\n\tthe other items were not deleted.  For example, when deleting "
        "\n\tall the expressions, the expressions that are part of rules "
        "\n\tcannot be deleted.\n",
        _pmm_delete_cmd_sg);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the operation is to be performed on all "
              "\n\t   the items, e.g., all the expressions or all the rules.",
              _pmm_all_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the operation is to be performed on an"
              "\n\t   expression(s).", _pmm_exp_keyword_sg);
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the items are to be deleted by name.", 
              _pmm_name_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the operation is to be performed on "
              "\n\t   a rule(s).",
              _pmm_rule_keyword_sg);
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else if (argc < 2) {
    fprintf(stdout, _pmm_too_few_params_sg, _pmm_delete_cmd_sg);
  }
  else if (0 == strcmp(argv_p[1], _pmm_exp_keyword_sg)) {
    /* Validate the number of parameters. */
    if (argc < 3) { 
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_exp_keyword_sg); 
    }
    else {
      /* Process the _pmm_exp_keyword_sg option. */
      if (0 == strcmp(argv_p[2], _pmm_all_keyword_sg)) {
        /* Delete all the expressions in the LL and PMM DBs. */
        status = _pmm_exp_all_delete(pmmDbHandle);
      } /* if - delete all the expressions */
      else if (0 == strcmp(argv_p[2], _pmm_name_keyword_sg)) {
        /* Delete the specified expressions.  Validate the number of
         * parameters. */
        if (argc < 4) { 
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_name_keyword_sg); 
        }

        status = 0;
        for (i = 3;i < argc;i++) {
          /* Check if the expression with the specified name exists. */
          exp_p = db_record_by_name_get(pmmDb_p->expDbHandle, argv_p[i]);
          if (NULL == exp_p) {
            /* An expression with the specified name does not exist. */
            fprintf(stdout, "A regular expression with name \"%s\" does "
                    "not exist.\n", argv_p[i]);
            status = EINVAL;
          }
          else {
            /* Delete the expression from both the LL and PMM DBs. */
            if (true == _pmm_exp_delete(pmmDb_p->llDbHandle, 
                                        pmmDb_p->expDbHandle, 
                                        exp_p->llIndex, exp_p->pmmIndex)) {
              fprintf(stdout, "Successfully deleted expression with name "
                      "\"%s\".\n", argv_p[i]);
            }
          } /* else - the expression exists in the PMM DB */
        } /* for - for all names in the command line */
      } /* else - delete the named expressions */
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_exp_keyword_sg);
      }
    } /* else - there is a name/all parameter(s). */
  } /* else if - this is the _pmm_exp_keyword_sg option. */
  else if (0 == strcmp(argv_p[1], _pmm_rule_keyword_sg)) {
    /* Validate the number of parameters. */
    if (argc < 3) { 
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_rule_keyword_sg); 
    }
    else {
      /* Process the _pmm_rule_keyword_sg option. */
      if (0 == strcmp(argv_p[2], _pmm_all_keyword_sg)) {
        /* Delete all the rules in the LL and PMM DBs. */
        status = _pmm_rule_all_delete(pmmDbHandle);
      } /* if - delete all the rules. */
      else if (0 == strcmp(argv_p[2], _pmm_name_keyword_sg)) {
        /* Delete the specified rules.  Validate the number of parameters. */
        if (argc < 4) { 
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_name_keyword_sg); 
        }

        status = 0;
        for (i = 3;i < argc;i++) {
          /* Check if the rule with the specified name exists. */
          rule_p = db_record_by_name_get(pmmDb_p->ruleDbHandle, argv_p[i]);
          if (NULL == rule_p) {
            /* An rule with the specified name does not exist. */
            fprintf(stdout, "A rule with name \"%s\" does not exist.\n",
                    argv_p[i]);
            status = EINVAL;
          }
          else {
            /* Delete the rule from both the LL and PMM DBs. */
            if (true == _pmm_rule_delete(pmmDb_p->llDbHandle, 
                                         pmmDb_p->ruleDbHandle, 
                                         rule_p->llIndex, rule_p->pmmIndex)) {
              fprintf(stdout, "Successfully deleted rule with name "
                      "\"%s\".\n", argv_p[i]);
            }
          } /* else - the rule exists in the PMM DB */
        } /* for - for all names in the command line. */
      } /* else - delete the named rules */
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], 
                _pmm_rule_keyword_sg);
      }
    } /* else - there is a name parameter(s). */
  } /* else if - this is the _pmm_rule_keyword_sg option. */
  else {
    fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_delete_cmd_sg);
  }
  
  return status;
} /* _pmm_pm_menu_delete */


/*
 * Generic commit command.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_commit(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, (NULL == cmd_p)? 
             "NULL":cmd_p, cmd_p, context_p);

  char          *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t        argc                          = 0;
  char           expName_s[PM_NAME_MAX_LENGTH] = "";
  pmll_status_t  pmllStatus                    = pmll_ok_e;
  cli_status_t   cliStatus                     = cli_error_e;
  handle_t       pmmDbHandle                   = *((handle_t *)context_p);
  _pmm_db_t     *pmmDb_p                       = pmmDbHandle;
  int            status                        = EINVAL;


  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }

  
  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s\n",
            _pmm_commit_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_commit_cmd_sg, _pmm_help_keyword_sg,
            _pmm_commit_cmd_sg
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command is used to configure the Pattern Matching "
        "\n\t(PM) H/W with the expressions that have been added to the "
        "\n\tsystem.  It is important to know that only the first,"
        "\n\tor initial, invocation of the %s command results in an"
        "\n\toptimal distribution of the pattern records in the PM H/W.  "
        "\n\tSuch optimization offers an increased performance of the "
        "\n\tPM H/W.  The second and subsequent, or incremental, "
        "\n\tinvocations of the %s command cannot perform such "
        "\n\toptimization.  Therefore, it is encouraged to make the first "
        "\n\tcommit with as final a state of the expression database as "
        "\n\tpossible.  The incremental commits should be infrequent.  "
        "\n\tNote also that as part of the initial commit the PM H/W is "
        "\n\treset, i.e., all the previously committed patterns are "
        "\n\tinvalidated.\n",
        _pmm_commit_cmd_sg, _pmm_commit_cmd_sg, _pmm_commit_cmd_sg);
      fprintf(stdout, "Parameters:" "\n\tN/A");
      _PMM_QM_STRING_DISPLAY();
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else if (argc >= 2) {
    fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_commit_cmd_sg);
  }
  else {
    /* Process the "commit" command.  Take a snapshot of the curtime */
    pmllStatus = pmll_commit(pmmDb_p->llDbHandle, expName_s);
    if (pmll_ok_e != pmllStatus) {
      if (pmll_failed_to_commit_pattern_e == pmllStatus) {
        fprintf(stdout, "Failed to commit expression with name \"%s\".\n",
                expName_s);
      }
      else {
        fprintf(stdout, "The commit failed with the following error: "
                "\"%s\".\n", pmll_error_string_get(pmllStatus));
      }
    }
    else {
      fprintf(stdout, "Successfully committed changes made to the data "
              "base of expressions.\n");
      status = 0;
    }

  } /* else - the "commit" command. */
  
  return status;
} /* _pmm_pm_menu_commit */


/*
 * Pings the PM H/W.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_ping(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, (NULL == cmd_p)? 
             "NULL":cmd_p, cmd_p, context_p);

  char          *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t        argc        = 0;
  bool           boolStatus  = false;
  int32_t        count       = _PMM_DEFAULT_PING_COUNT;
  int32_t        i           = 0;
  cli_status_t   cliStatus   = cli_error_e;
  int32_t        nextArg     = 1;
  bool           errorFlag   = false;
  handle_t       pmmDbHandle = *((handle_t *)context_p);
  _pmm_db_t     *pmmDb_p     = pmmDbHandle;
  int            status      = EINVAL;
  

  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }

  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s [%s <value>]\n",
            _pmm_ping_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_ping_cmd_sg, _pmm_help_keyword_sg,
            _pmm_ping_cmd_sg, _pmm_count_keyword_sg
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command is used to send ping request messages to the"
        "\n\tPattern Matching (PM) H/W.  The number of the ping request"
        "\n\tmessages is specified using the %s option.  If the %s "
        "\n\toption is not specified then %u ping requests are sent.  No "
        "\n\tdata is sent in a ping request.\n"
        "\n\tThe second and subsequent ping requests are sent when the "
        "\n\treply to the previous ping request is received.\n", 
        _pmm_ping_cmd_sg, _pmm_count_keyword_sg, _pmm_count_keyword_sg, 
        _PMM_DEFAULT_PING_COUNT);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      fprintf(stdout, "\n\tcount"
              "\n\t   The number of the ping request messages to be sent.");
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else {
    if (argc > 1) { 
      /* There are options specified.  Since all of the options are
       * optional we can process them all at once. */
      while (nextArg < argc) {
        if (0 == strcmp(argv_p[nextArg], _pmm_count_keyword_sg)) {
          if (nextArg + 1 >= argc) {
            fprintf(stdout, _pmm_too_few_params_sg, _pmm_count_keyword_sg); 
            errorFlag = true;
            break;
          }
          else {
            /* The count is specified.  Get the value. */
            if ((false == cli_int32get(argv_p[nextArg + 1], &count)) || 
                (count < 0)) {
              fprintf(stdout, "The count value of \"%s\" is invalid.\n", 
                      argv_p[nextArg + 1]);
              errorFlag = true;
              break;
            }
          }
          nextArg += 2;
        }
        else {
          /* This must be an invalid option. */
          fprintf(stdout, _pmm_invalid_param_sg, argv_p[nextArg], 
                  _pmm_ping_cmd_sg);
          errorFlag = true;
          break;
        }
      } /* while - process all the options. */
    } /* if - there are options specified. */
    

    /* If there were no errors while reading the options then proceed
       to send the ping request(s). */
    if (false == errorFlag) {
      status = 0;
      if (count > 0) {
        fprintf(stdout, "Pinging the PM H/W...\n");
        for (i = 0;i < count;i++) {
          boolStatus = _pmm_ping(pmmDb_p->pmlaForPmmHandle);
          if (false == boolStatus) {
            fprintf(stdout, "  An attempt to ping the PM H/W failed.\n");
            status = EIO;
          }
          else {
            fprintf(stdout, "Successfully pinged the PM H/W (%u/%u).\n",
                    i + 1, count);
          }
        }
      }
    }
  }  

  return status;
} /* _pmm_pm_menu_ping */


/*
 * Generic show command.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_show(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, (NULL == cmd_p)? 
             "NULL":cmd_p, cmd_p, context_p);

  char          *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t        argc        = 0;
  int32_t        i           = 0;
  db_status_t    dbStatus    = db_error_e;
  pmll_status_t  pmllStatus  = pmll_ok_e;
  cli_status_t   cliStatus   = cli_error_e;  
  handle_t       pmmDbHandle = *((handle_t *)context_p);
  _pmm_db_t     *pmmDb_p     = pmmDbHandle;
  int            status      = EINVAL;


  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }


  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s %s %s"
            "\n\t%s %s %s <expname> [<expname1> ... <expname%u>]"
            "\n\t%s %s"
            "\n\t%s %s %s"
            "\n\t%s %s %s <rulename> [<rulename1> ... <rulename%u>]"
            "\n\t%s %s %s"
            "\n\t%s %s %s"
            "\n\t%s %s %s\n",
            _pmm_show_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_show_cmd_sg, _pmm_attributes_keyword_sg,
            _pmm_show_cmd_sg, _pmm_exp_keyword_sg, _pmm_all_keyword_sg,

            _pmm_show_cmd_sg, _pmm_exp_keyword_sg, _pmm_name_keyword_sg, 
            _PMM_PARAM_MAX_NUM - 3,

            _pmm_show_cmd_sg, _pmm_help_keyword_sg,
            _pmm_show_cmd_sg, _pmm_rule_keyword_sg, _pmm_all_keyword_sg,

            _pmm_show_cmd_sg, _pmm_rule_keyword_sg, _pmm_name_keyword_sg, 
            _PMM_PARAM_MAX_NUM - 3,

            _pmm_show_cmd_sg, _pmm_stats_keyword_sg, _pmm_ll_keyword_sg,
            _pmm_show_cmd_sg, _pmm_table_keyword_sg, 
            _pmm_equivalence_keyword_sg, _pmm_show_cmd_sg, 
            _pmm_version_keyword_sg, _pmm_ll_keyword_sg
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command can be used to display the fields of the records "
        "\n\tadded to the system, e.g., the expression or rule records.  "
        "\n\tThe command can also be used to display version information of "
        "\n\tsome S/W components, e.g., the Linker-Loader.\n",
        _pmm_show_cmd_sg);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Displays the values of the attributes that can be set "
              "\n\t   using the %s command.", 
              _pmm_attributes_keyword_sg, _pmm_set_cmd_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Displays the information about the specified "
              "\n\t   expression(s).  If no expression name is specified "
              "\n\t   the information about all expressions is displayed.", 
              _pmm_exp_keyword_sg);
      fprintf(stdout, "\n\texpname"
              "\n\t   Name of an expression.");
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the option should operate on the "
              "\n\t   Linker-Loader module.", _pmm_ll_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Displays the information about the specified rule(s).  "
              "\n\t   If no rule name is specified the information about all "
              "\n\t   rules is displayed.", _pmm_rule_keyword_sg);
      fprintf(stdout, "\n\trulename"
              "\n\t   Name of a rule.");
      fprintf(stdout, "\n\t%s"
              "\n\t   Displays the statistics for the indicated module.", 
              _pmm_stats_keyword_sg);
      _PMM_VERSION_STRING_DISPLAY();
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else if (argc < 2) {
    fprintf(stdout, _pmm_too_few_params_sg, _pmm_show_cmd_sg); 
  }
  else if ((argc > 1) && (0 == strcmp(argv_p[1], _pmm_exp_keyword_sg))) {
    /* This is the "exp" option.  Validate the number of parameters. */
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_exp_keyword_sg); 
    }
    else {
      /* Process the _pmm_exp_keyword_sg option. */
      if (0 == strcmp(argv_p[2], _pmm_all_keyword_sg)) {
        /* Display all the expressions. */
        (void)db_record_all_show(pmmDb_p->expDbHandle, _pmm_exp_show);
      
        fprintf(stdout, "total number of expressions = %u\n",
                db_record_number_get(pmmDb_p->expDbHandle));
        fprintf(stdout, "total number of rules       = %u\n", 
                db_record_number_get(pmmDb_p->ruleDbHandle));
        status = 0;
      } /* if - show all the expressions */
      else if (0 == strcmp(argv_p[2], _pmm_name_keyword_sg)) {
        /* Show the specified expressions.  Validate the number of
         * parameters. */
        if (argc < 4) { 
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_name_keyword_sg); 
        }

        status = 0;
        for (i = 3;i < argc;i++) {
          dbStatus = db_record_by_name_show(pmmDb_p->expDbHandle, argv_p[i], 
                                            _pmm_exp_show);
          if (db_name_is_not_in_use_e == dbStatus) {
            fprintf(stdout, "Regular expression with name \"%s\" does not "
                    "exist.\n", argv_p[i]);
            status = EINVAL;
          }
        } /* for - for all names in the command line */
      } /* else - show the named expressions */
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_exp_keyword_sg);
      }
    } /* else - there is a name/all parameter(s). */
  } /* else if - this is the _pmm_exp_keyword_sg option. */
  else if ((argc > 1) && (0 == strcmp(argv_p[1], _pmm_rule_keyword_sg))) {
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_rule_keyword_sg); 
    }
    else {
      /* Process the _pmm_rule_keyword_sg option. */
      if (0 == strcmp(argv_p[2], _pmm_all_keyword_sg)) {
        /* Display all the rules. */
        (void)db_record_all_show(pmmDb_p->ruleDbHandle, _pmm_rule_show);

        fprintf(stdout, "total number of expressions = %u\n",
                db_record_number_get(pmmDb_p->expDbHandle));
        fprintf(stdout, "total number of rules       = %u\n", 
                db_record_number_get(pmmDb_p->ruleDbHandle));
        status = 0;
      }
      else if (0 == strcmp(argv_p[2], _pmm_name_keyword_sg)) {
        /* Show the specified rules.  Validate the number of parameters. */
        if (argc < 4) { 
          fprintf(stdout, _pmm_too_few_params_sg, _pmm_name_keyword_sg); 
        }

        status = 0;
        for (i = 3;i < argc;i++) {      
          dbStatus = db_record_by_name_show(pmmDb_p->ruleDbHandle, argv_p[i], 
                                            _pmm_rule_show);
          if (db_name_is_not_in_use_e == dbStatus) {
            fprintf(stdout, "Rule with name \"%s\" does not exist.\n",
                    argv_p[i]);
            status = EINVAL;
          }
        } /* for - for all names in the command line. */
      }
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], 
                _pmm_rule_keyword_sg);
      }
    } /* else - there is a name/all parameter(s). */
  } /* else if - this is the _pmm_rule_keyword_sg option. */
  else if ((argc > 1) && (0 == strcmp(argv_p[1], _pmm_version_keyword_sg))) {
    /* This is the "version" option. */
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_version_keyword_sg);
      return 0;
    }
    if ((argc > 1) && (0 == strcmp(argv_p[2], _pmm_ll_keyword_sg))) {
      if (argc > 3) {
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_ll_keyword_sg);
        return 0;
      }
      char  version_s[PMLL_VERSION_STR_LENGTH];

      /* Get and display the LL API version. */
      fprintf(stdout, "Version of the linker-loader API is       : %s\n", 
              pmll_version_str_get(pmll_api_version_get(), version_s));


      /* Get and display the versions of the supported expression and
       * rule records. */
      uint32_t  expVersionNum  = pmll_supported_exp_record_versions_num_get();
      uint32_t  ruleVersionNum = pmll_supported_rule_record_versions_num_get();
      uint32_t  tableSize      = _PMM_MAX(expVersionNum, ruleVersionNum);
      uint32_t  j              = 0;
      uint32_t *versionTable_p = mem_calloc(tableSize, sizeof(uint32_t));

      if (NULL == versionTable_p) {
        fprintf(stdout, "Failed to allocate memory to retrieve the "
                "record version numbers supported by the linker-loader.\n");
        status = ENOMEM;
      }
      else {
        pmllStatus = pmll_supported_exp_record_versions_get(versionTable_p,
                                                            tableSize);
        if (pmll_ok_e != pmllStatus) {
          fprintf(stdout, "Failed to retrieve exp. record versions supported "
                  "by the linker-loader.  \"%s\"\n", 
                  pmll_error_string_get(pmllStatus));
          status = EIO;
        }
        else {
          status = 0;
          fprintf(stdout, "Versions of the supported exp. records are: ");
          for (j = 0;j < expVersionNum;j++) {
            fprintf(stdout, "%s ", pmll_version_str_get(versionTable_p[j],
                                                        version_s));
          }
          fprintf(stdout, "\n");
        }
        
        pmllStatus = pmll_supported_rule_record_versions_get(versionTable_p,
                                                             tableSize);
        if (pmll_ok_e != pmllStatus) {
          fprintf(stdout, "Failed to retrieve rule record versions supported "
                  "by the linker-loader.  \"%s\"\n", 
                  pmll_error_string_get(pmllStatus));
          status = EIO;
        }
        else {
          status = 0;
          fprintf(stdout, "Versions of the supported rule records are: ");
          for (j = 0;j < ruleVersionNum;j++) {
            fprintf(stdout, "%s ", pmll_version_str_get(versionTable_p[j],
                                                        version_s));
          }
          fprintf(stdout, "\n");
        }
      
        /* Free the version table memory. */
        mem_free(versionTable_p);
      }
    }
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], 
              _pmm_version_keyword_sg);
    }
  } /* else if - this is the _pmm_version_keyword_sg option. */
  else if ((argc > 1) && (0 == strcmp(argv_p[1], _pmm_stats_keyword_sg))) {
    /* This is the "stats" option. */
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_stats_keyword_sg);
      return 0;
    }
    if ((0 == strcmp(argv_p[2], _pmm_ll_keyword_sg))) {
      if (argc > 3) {
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_ll_keyword_sg);
        return 0;
      }
      else {
        pmll_stats_t llStats;
        
        pmllStatus = pmll_stats_get(pmmDb_p->llDbHandle, &llStats);
        if (pmll_ok_e != pmllStatus) {
          fprintf(stdout, "Failed to retrieve the LL statistics.  \"%s\"\n", 
                  pmll_error_string_get(pmllStatus));
          status = EIO;
        }
        else {
          status = 0;
          /* Print the LL stats. */
          fprintf(stdout, "Expression and pattern statistics:\n");
          fprintf(stdout, "\tMaximum number of patterns               : "
                  "%6u\n",  llStats.patternMaxNum);
          fprintf(stdout, "\tNumber of configured special patterns    : "
                  "%6u\n",  llStats.specialPatternNum);
          fprintf(stdout, "\tNumber of configured one-byte patterns   : "
                  "%6u\n",  llStats.oneBytePatternNum);
          fprintf(stdout, "\tNumber of configured two-byte patterns   : "
                  "%6u\n",  llStats.twoBytePatternNum);
          fprintf(stdout, "\tNumber of configured variable patterns   : "
                  "%6u\n",  llStats.variablePatternNum);
          fprintf(stdout, "\tTotal number of configured patterns      : "
                  "%6u\n",  llStats.totalPatternNum);
          fprintf(stdout, "\tNumber of configured expressions         : "
                  "%6u\n",  llStats.expNum);
          fprintf(stdout, "\tSize of the variable trigger             : "
                  "%6u [symbols]\n",  llStats.variableTriggerSize);

          fprintf(stdout, "Rule and reaction statistics:\n");
          fprintf(stdout, "\tMaximum number of stateful rules         : "
                  "%6u\n",  llStats.statefulRuleMaxNum);
          fprintf(stdout, "\tMaximum number of stateless rules        : "
                  "%6u\n",  llStats.statelessRuleMaxNum);
          fprintf(stdout, "\tMaximum number of rules                  : "
                  "%6u\n",  llStats.totalRuleMaxNum);
          fprintf(stdout, "\tNumber of configured stateful rules      : "
                  "%6u\n",  llStats.statefulRuleNum);
          fprintf(stdout, "\tNumber of configured stateless rules     : "
                  "%6u\n",  llStats.statelessRuleNum);
          fprintf(stdout, "\tNumber of configured rules               : "
                  "%6u\n",  llStats.totalRuleNum);
          fprintf(stdout, "\tNumber of configured end of SUI reactions: "
                  "%6u\n", llStats.endOfSuiReactionNum);

          fprintf(stdout, "DXE/SRE table statistics:\n");
          fprintf(stdout, "\ttotal number of entries                  : "
                  "%6u\n", llStats.dxeSreEntryNum);
          fprintf(stdout, "\tnumber of base entries                   : "
                  "%6u\n", llStats.dxeSreBaseEntryNum);
          fprintf(stdout, "\tnumber of extension entries              : "
                  "%6u\n", llStats.dxeSreExtensionEntryNum);
          fprintf(stdout, "\tnumber of allocated extension entries    : "
                  "%6u\n", llStats.dxeSreAllocatedExtensionEntryNum);
          fprintf(stdout, "\tnumber of available extension entries    : "
                  "%6u\n", llStats.dxeSreAvailableExtensionEntryNum);
          
          fprintf(stdout, "SRE context session statistics:\n");
          fprintf(stdout, "\tNumber of sessions                       : "
                  "%6u\n",  llStats.sreSessionCtxNum);
          fprintf(stdout, "\tSize of a single session                 : "
                  "%6u [bytes]\n",  llStats.sreSessionCtxSize);
          fprintf(stdout, "\tSize of the digest area                  : "
                  "%6u [bytes]\n",  llStats.sreSessionDigestSize);
          fprintf(stdout, "\tSize of the session flags area           : "
                  "%6u [bytes]\n",  llStats.sreSessionFlagsSize);
          fprintf(stdout, "\tSize of the context areas                : "
                  "%6u [bytes]\n",  llStats.sreSessionCtxAreaSize);
          fprintf(stdout, "\tSize of allocated context areas          : "
                  "%6u [bytes]\n",  llStats.sreAllocatedSessionCtxAreaSize);
          fprintf(stdout, "\tSize of available context areas          : "
                  "%6u [bytes]\n",  llStats.sreAvailableSessionCtxAreaSize);
        }
      }
    }
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_stats_keyword_sg);
    }
  } /* else if - this is the _pmm_stats_keyword_sg option. */
  else if ((argc > 1) && 
           (0 == strcmp(argv_p[1], _pmm_attributes_keyword_sg))) {
    /* Display the value of the variable trigger size. */
    uint32_t  variableTriggerSize = 0;
    
    pmllStatus = pmll_variable_trigger_size_get(pmmDb_p->llDbHandle, 
                                                &variableTriggerSize);
    if (pmll_ok_e != pmllStatus) {
      fprintf(stdout, "Failed to retrieve the value of the variable trigger "
              "size.  \"%s\"\n", pmll_error_string_get(pmllStatus));
      status = EIO;
    }
    else {
      status = 0;
      fprintf(stdout, "variable trigger size: %u\n", variableTriggerSize);
    }
  } /* else if - this is the _pmm_attributes_keyword_sg option. */
  else if ((argc > 1) && (0 == strcmp(argv_p[1], _pmm_table_keyword_sg))) {
    /* This is the "table" option. */
    if (argc < 3) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_table_keyword_sg); 
    }
    else if (0 == strcmp(argv_p[2], _pmm_equivalence_keyword_sg)) {
      /* Process the _pmm_equivalence_keyword_sg option. */
      if (argc > 3) {
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_equivalence_keyword_sg); 
      }
      else {
        uint8_t   equivalenceTable[PMP_EQUIVALENCE_ENTRY_SIZE];
        
        pmllStatus = pmll_equivalence_table_get(pmmDb_p->llDbHandle, 
                                                equivalenceTable);
        if (pmll_ok_e != pmllStatus) {
          fprintf(stdout, "Failed to retrieve the equivalence table.  "
                  "\"%s\"\n", pmll_error_string_get(pmllStatus));
          status = EIO;
        }
        else {
          status = 0;
          fprintf(stdout, "Equivalence table:\n");
          mem_memory_dump(stdout, equivalenceTable, PMP_EQUIVALENCE_ENTRY_SIZE,
                          16, true, false, equivalenceTable, true);
        }
      }
    }
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_table_keyword_sg);
    }
  }
  else if (argc > 1) {
    fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_show_cmd_sg);
  }

  return status;
} /* _pmm_pm_menu_show */


/*
 * Generic read command.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_read(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, (NULL == cmd_p)? 
             "NULL":cmd_p, cmd_p, context_p);

  char                    *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t                  argc          = 0;
  bool                     boolStatus    = false;
  cli_status_t             cliStatus     = cli_error_e;
  uint32_t                 attributeSize = 0;
  handle_t                 pmmDbHandle   = *((handle_t *)context_p);
  _pmm_db_t               *pmmDb_p       = pmmDbHandle;
  int                      status        = EINVAL;
  pmp_hw_revision_t        hwRevision;
  pmp_protocol_revision_t  protoRevision;
  pmp_statistics_attr_t    statistics;
  

  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }
  
  
  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s %s %s"
            "\n\t%s %s %s\n",
            _pmm_read_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_read_cmd_sg, _pmm_help_keyword_sg,
            _pmm_read_cmd_sg, _pmm_stats_keyword_sg, _pmm_hw_keyword_sg,
            _pmm_read_cmd_sg, _pmm_version_keyword_sg, _pmm_hw_keyword_sg
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command can be used to read information from the PM "
        "\n\tH/W.\n", _pmm_read_cmd_sg);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      _PMM_HW_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that statistics collected by a sub-system "
              "\n\t   are to be read.  The following keyword indicates the "
              "\n\t   sub-system to read the statistics from.", 
              _pmm_stats_keyword_sg);
      _PMM_VERSION_STRING_DISPLAY();
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else {
    /* Process the "read" command. */
    if (argc < 2) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_read_cmd_sg); 
    }
    else if (0 == strcmp(argv_p[1], _pmm_version_keyword_sg)) {
      if (argc < 3) {
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_version_keyword_sg); 
      }
      else if (argc > 3) { 
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_version_keyword_sg);
      }
      else {
        if (0 == strcmp(argv_p[2], _pmm_hw_keyword_sg)) {
          boolStatus = _pmm_attribute_read(pmmDb_p->pmlaForPmmHandle,
                                           pmp_hardware_revision_attr_id_e,
                                           &hwRevision, &attributeSize);
          if (true != boolStatus) {
            fprintf(stdout, "An attempt to read hardware revision failed.\n");
          }
          else if (sizeof(hwRevision) != attributeSize) {
            fprintf(stdout, "Expected to read %Zd bytes long PM H/W "
                    "revision but got %u bytes instead.\n", 
                    sizeof(hwRevision), attributeSize);
          }
          else {
            boolStatus = _pmm_attribute_read(pmmDb_p->pmlaForPmmHandle,
                                             pmp_protocol_revision_attr_id_e,
                                             &protoRevision, &attributeSize);
            if (true != boolStatus) {
              fprintf(stdout, "An attempt to read protocol revision "
                      "failed.\n");
            }
            else if (sizeof(protoRevision) != attributeSize) {
              fprintf(stdout, "Expected to read %Zd bytes long PMP "
                      "protocol revision but got %u bytes instead.\n", 
                      sizeof(protoRevision), attributeSize);
            }
            else {
              status = 0;
              fprintf(stdout, "SOC Family       : 0x%4.4x\n", 
                      PMP_PMHWTOHS(hwRevision.socFamily));
              fprintf(stdout, "SOC Member       : 0x%4.4x\n", 
                      PMP_PMHWTOHS(hwRevision.socMember));
              fprintf(stdout, "Core ID          : 0x%4.4x\n", 
                      PMP_PMHWTOHS(hwRevision.coreId));
              fprintf(stdout, "Core Major       : 0x%2.2x\n", 
                      hwRevision.coreMajor);
              fprintf(stdout, "Core Minor       : 0x%2.2x\n", 
                      hwRevision.coreMinor);
              fprintf(stdout, "Core Options     : 0x%2.2x\n",
                      hwRevision.coreIntegrationOptions);
              fprintf(stdout, "Core Configs     : 0x%2.2x\n",
                      hwRevision.coreConfigurationOptions);
              fprintf(stdout, "Protocol Major   : 0x%2.2x\n", 
                      protoRevision.protocolMajor);
              fprintf(stdout, "Protocol Minor   : 0x%2.2x\n", 
                      protoRevision.protocolMinor);
            }
          }
        }
        else {
          fprintf(stdout, _pmm_invalid_param_sg, argv_p[2],
                  _pmm_version_keyword_sg);
        }
      }
    } /* else if - process the version option. */
    else if (0 == strcmp(argv_p[1], _pmm_stats_keyword_sg)) {
      if (argc < 3) {
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_stats_keyword_sg); 
      }
      else if (argc > 3) { 
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_stats_keyword_sg);
      }
      else {
        if (0 == strcmp(argv_p[2], _pmm_hw_keyword_sg)) {
          attributeSize = 0;
          boolStatus = _pmm_attribute_read(pmmDb_p->pmlaForPmmHandle, 
                                           pmp_statistics_attr_id_e,
                                           &statistics, &attributeSize);
          if (true != boolStatus) {
            fprintf(stdout, "An attempt to read the PM H/W statistics "
                    "failed.\n");
          }
          else if (sizeof(statistics) != attributeSize) {
            fprintf(stdout, "Expected to read %Zd bytes long statistics "
                    "attribute but got %u bytes instead.\n", 
                    sizeof(statistics), attributeSize);
          }
          else {
            status = 0;
            /* Dump the current and aggregated counts here */
            fprintf(stdout, "The PM H/W Statistics:");
            fprintf(stdout, "                     Current");
            fprintf(stdout, "       Previous");
            fprintf(stdout, "          Delta\n");
            _PMM_DISP_STATS("PM Input Bytes           (KES)", 
                            pmInputBytes);
            _PMM_DISP_STATS("PM Output Report Bytes   (SRE)",
                            pmOutputBytes);
            _PMM_DISP_STATS("PM Trigger 1B Hits       (KES)",
                            pmTriggerOneByteHits);
            _PMM_DISP_STATS("PM Trigger 2B Hits       (KES)",
                            pmTriggerTwoByteHits);
            _PMM_DISP_STATS("PM Trigger Variable Hits (KES)",
                            pmTriggerVariableHits);
            _PMM_DISP_STATS("PM Trigger Special Hits  (KES)",
                            pmTriggerSpecialHits);
            _PMM_DISP_STATS("PM Confidence Stage Hits (KES)",
                            pmConfidenceHits);
            _PMM_DISP_STATS("PM Matches               (DXE)",
                            pmMatches);
            _PMM_DISP_STATS("PM SR Execution by DXE   (SRE)",
                            pmDxeExecutions);
            _PMM_DISP_STATS("PM SR Execution by SUI   (SRE)",
                            pmEndOfSuiExecutions);
            _PMM_DISP_STATS("PM SUI With Matches      (DXE)",
                            pmSuiMatchingPatterns);
            _PMM_DISP_STATS("PM SUI With Reports      (SRE)",
                            pmSuiGeneratingReports);
            _PMM_DISP_STATS("PM Input SUIs            (KES)",
                            pmInputSuis);
            _PMM_DISP_STATS("PM Matches with DRCC     (DXE)",
                            pmSelectedMatches);
            _PMM_DISP_STATS("Deflate Input Bytes      (DFL)",
                            dfInputBytes);
            _PMM_DISP_STATS("Deflate Output Bytes     (DFL)",
                            dfOutputBytes);
            _PMM_DISP_STATS("Deflate Work Units       (DFL)",
                            dfDecompressions);

            /* Update the internal snapshot for the next iteration */
            memcpy(&pmmDb_p->snapshot, &statistics, sizeof(statistics));
          }
        }
        else {
          fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], 
                  _pmm_stats_keyword_sg);
        }
      }
    } /* else if - process the stats. option. */
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_read_cmd_sg);
    }
  } /* else - process the "read" command. */
  
  return status;
} /* _pmm_pm_menu_read */


/* 
 * Generic reset command.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_reset(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, (NULL == cmd_p)? 
             "NULL":cmd_p, cmd_p, context_p);

  char         *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t       argc        = 0;
  bool          boolStatus  = true;
  cli_status_t  cliStatus   = cli_error_e;
  handle_t      pmmDbHandle = *((handle_t *)context_p);
  _pmm_db_t    *pmmDb_p     = pmmDbHandle;
  int           status      = EINVAL;


  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }

  
  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s %s %s\n",
            _pmm_reset_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_reset_cmd_sg, _pmm_help_keyword_sg,
            _pmm_reset_cmd_sg, _pmm_stats_keyword_sg, _pmm_hw_keyword_sg
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command can be used to reset the PM H/W statistic "
        "counters.\n", _pmm_reset_cmd_sg);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      _PMM_HW_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that statistic counters should be reset.", 
              _pmm_stats_keyword_sg);
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else {
    /* Process the "read" command. */
    if (argc < 2) {
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_read_cmd_sg); 
    }
    else if (0 == strcmp(argv_p[1], _pmm_stats_keyword_sg)) {
      /* Process the "stats" option. */
      if (argc < 3) {
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_stats_keyword_sg); 
        return 0;
      }
      if (0 == strcmp(argv_p[2], _pmm_hw_keyword_sg)) {
        /* Reset the PM H/W stats. */
        if (argc > 3) { 
          fprintf(stdout, _pmm_too_many_params_sg, _pmm_hw_keyword_sg);
        }
        else {
          fprintf(stdout, "Resetting the PM H/W statistics...\n");
          
          /* Reset the snapshot stats. */
          memset(&pmmDb_p->snapshot, 0, sizeof(pmp_statistics_attr_t));

          /* Reset the aggregate PM H/W stats. counters. */
          boolStatus = _pmm_attribute_write(pmmDb_p->pmlaForPmmHandle,
                                            pmp_statistics_attr_id_e,
                                            NULL, 0);
          if (true != boolStatus) {
            fprintf(stdout, "An attempt to reset the PM H/W statistics "
                    "failed.\n");
          }
          else {
            status = 0;
            fprintf(stdout, "Successfully reset the PM H/W statistics.\n");
          }
        }
      } /* if - _pmm_hw_keyword_sg */
      else {
        fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], 
                _pmm_stats_keyword_sg);
      }
    }
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_reset_cmd_sg);
    }
  } /* else - process the "read" command. */
  
  return status;
} /* _pmm_pm_menu_reset */


/*
 * Generic set command.
 *
 * param  cmd_p  String with the arguments for the command. 
 * retval        Returns 0 upon success or an error code otherwise.
 */
static int
_pmm_pm_menu_set(
  char *cmd_p,
  void *context_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(cmd_p=%p="
             "\"%s\", context_p=%p).", __func__, (NULL == cmd_p)? 
             "NULL":cmd_p, cmd_p, context_p);

  char          *argv_p[_PMM_PARAM_MAX_NUM];
  int32_t        argc            = 0;
  pmll_status_t  pmllStatus      = pmll_ok_e;
  cli_status_t   cliStatus       = cli_error_e;
  char           badHexValue_s[] = 
    "Failed to convert the \"%s\" string to a hexadecimal value.\n";
  handle_t       pmmDbHandle     = *((handle_t *)context_p);
  _pmm_db_t     *pmmDb_p         = pmmDbHandle;
  int            status          = EINVAL;
 

  /* Process the command line parametes. */
  cliStatus = cli_command_parse(cmd_p, &argc, argv_p, _PMM_PARAM_MAX_NUM, 
                                _pmm_delimiters_sg);
  if(cliStatus != cli_ok_e) {
    fprintf(stdout, "%s\n", cli_error_string_get(cliStatus));
    return EINVAL;
  }


  /* Process the help options. */
  if ((argc >= 2) &&
      ((0 == strcmp(argv_p[1], _pmm_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _pmm_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)))) {
    status = 0;
    fprintf(stdout,
            "Synopsis:"
            "\n\t%s %s|%s"
            "\n\t%s %s"
            "\n\t%s %s %s <size>"
            "\n\t%s %s %s <value>\n",
            _pmm_set_cmd_sg, _pmm_qm_keyword_sg, _pmm_h_keyword_sg,
            _pmm_set_cmd_sg, _pmm_help_keyword_sg,
            _pmm_set_cmd_sg, _pmm_attribute_keyword_sg, 
            _pmm_variablesize_keyword_sg, _pmm_set_cmd_sg, 
            _pmm_table_keyword_sg, _pmm_equivalence_keyword_sg 
      );
    if (0 == strcmp(argv_p[1], _pmm_help_keyword_sg)) {
      fprintf(
        stdout, 
        "Description:"
        "\n\tThe %s command can be used to alter values of the modifiable "
        "\n\tparameters in the DB.\n", _pmm_set_cmd_sg);
      fprintf(stdout, "Parameters:");
      _PMM_QM_STRING_DISPLAY();
      _PMM_HSTRING_DISPLAY();
      _PMM_HELP_STRING_DISPLAY();
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the LL equivalence table is to be set."
              "\n\t   The new values for the table are specified as a string "
              "\n\t   representing %u hexadecimal byte values.  For example, "
              "\n\t   00010203...fcfdfeff.",
              _pmm_equivalence_keyword_sg, PMP_EQUIVALENCE_ENTRY_SIZE);
      fprintf(stdout, "\n\tsize"
              "\n\t   The desired size of the variable trigger.");
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the command is for a table.",
              _pmm_table_keyword_sg);
      fprintf(stdout, "\n\t%s"
              "\n\t   Indicates that the value of the LL variable trigger "
              "\n\t   size is to be set.", _pmm_variablesize_keyword_sg);
      fprintf(stdout, "\n");
    }
  } /* if - h or help. */
  else if (argc < 2) {
    fprintf(stdout, _pmm_too_few_params_sg, _pmm_set_cmd_sg); 
  }
  else if (0 == strcmp(argv_p[1], _pmm_attribute_keyword_sg)) {
    if (argc < 3) { 
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_attribute_keyword_sg); 
    }
    else if (0 == strcmp(argv_p[2], _pmm_variablesize_keyword_sg)) {
      if (argc < 4) { 
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_variablesize_keyword_sg); 
      }
      else if (argc > 4) {
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_variablesize_keyword_sg);
      }
      else {
        /* Process the _pmm_variablesize_keyword_sg option. */
        int32_t  variableTriggerSize = 0;
        
        if ((false == cli_int32get(argv_p[3], &variableTriggerSize)) || 
            (variableTriggerSize < 0)) {
          fprintf(stdout, "Variable trigger size value of \"%s\" is "
                  "invalid.\n", argv_p[3]);
        }
        else {
          pmllStatus = pmll_variable_trigger_size_set(pmmDb_p->llDbHandle, 
                                                      variableTriggerSize);
          if (pmll_ok_e != pmllStatus) {
            fprintf(stdout, "Failed to set the variable trigger size.  "
                    "\"%s\"\n", pmll_error_string_get(pmllStatus));
          }
          else {
            /* The operation was successful. */
            status = 0;
          }
        }
      } /* else - right number of params for variable size keyword. */
    } /* else if - variable trigger size processing. */
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], 
              _pmm_attribute_keyword_sg);
    }
  } /* else if - attribute(s) processing. */
  else if (0 == strcmp(argv_p[1], _pmm_table_keyword_sg)) {
    if (argc < 3) { 
      fprintf(stdout, _pmm_too_few_params_sg, _pmm_table_keyword_sg); 
    }
    else if (0 == strcmp(argv_p[2], _pmm_equivalence_keyword_sg)) {
      /* This is the "equivalence" option. */
      if (argc < 4) { 
        fprintf(stdout, _pmm_too_few_params_sg, _pmm_equivalence_keyword_sg); 
      }
      else if (argc > 4) {
        fprintf(stdout, _pmm_too_many_params_sg, _pmm_equivalence_keyword_sg);
      }
      else {
        /* The size of hexValue defined below is larger than the
         * required PMP_EQUIVALENCE_ENTRY_SIZE bytes so that if the
         * user makes a mistake and specifies more bytes we can tell
         * him/her that. */
        uint8_t   hexValue[2 * PMP_EQUIVALENCE_ENTRY_SIZE];
        uint32_t  hexValueSize = 0;
        
        
        if (false == cli_hex_get(argv_p[3], hexValue, sizeof(hexValue), 
                                 &hexValueSize)) {
          fprintf(stdout, badHexValue_s, argv_p[3]);
        }
        else if (PMP_EQUIVALENCE_ENTRY_SIZE != hexValueSize) {
          fprintf(stdout, "Expected a %u-byte long hexadecimal "
                  "value; the received value of \"%s\" represents "
                  "%u byte(s).\n", PMP_EQUIVALENCE_ENTRY_SIZE, argv_p[3],
                  hexValueSize);
        }
        else {
          pmllStatus = pmll_equivalence_table_set(pmmDb_p->llDbHandle,
                                                  hexValue);
          if (pmll_ok_e != pmllStatus) {
            fprintf(stdout, "Failed to set the equivalence table.  "
                    "\"%s\"\n", pmll_error_string_get(pmllStatus));
          }
          else {
            /* The operation was successful. */
            status = 0;
          }
        }
      }
    } /* if - this is the _pmll_equivalence_keyword_sg option. */
    else {
      fprintf(stdout, _pmm_invalid_param_sg, argv_p[2], _pmm_table_keyword_sg);
    }
  } /* else if - this is the _pmll_table_keyword_sg option. */
  else {
    fprintf(stdout, _pmm_invalid_param_sg, argv_p[1], _pmm_set_cmd_sg);
  }

  return status;
} /* _pmm_pm_menu_set */


/*
 * Prints the help message on how to use the PMM application. 
 */
static void
_pmm_help_show(
  char *appName_p
  )
{
  char *name_p                         = strdup(appName_p);
  char *baseName_p                     = appName_p;
  char  ipv4Address_s[INET_ADDRSTRLEN] = "";
  

  if (NULL != name_p) {
    baseName_p = basename(name_p);
  }
  

  fprintf(stdout, "Usage:");
  fprintf(stdout, "\n\t%s [<options>]", baseName_p);
  fprintf(stdout, "\n\n");


  fprintf(stdout, "Options:");  
  fprintf(stdout, "\n  %s, %s <id>"
          "\n\tSet the target channel ID to be used.  The default channel"
          "\n\tID is %u.\n", 
          _PMM_CMD_ARG_SHORT_TARGET_CHANNEL, _PMM_CMD_ARG_LONG_TARGET_CHANNEL,
          _PMM_PMLA_TARGET_CHANNEL_ID);
  fprintf(stdout, "\n  %s, %s"
          "\n\tTurn on the exit-on-error flag.  This flag makes the "
          "\n\t%s application terminate upon encountering an error.  "
          "\n\tThis behavior could be useful in situations when the "
          "\n\t%s application runs in a non-interactive mode."
          "\n\tNote that, if present, the commands in the PMLL debug "
          "\n\tsub-menu do not currently implement this option.\n", 
          _PMM_CMD_ARG_SHORT_EXIT_ON_ERROR, _PMM_CMD_ARG_LONG_EXIT_ON_ERROR, 
          baseName_p, baseName_p);
  fprintf(stdout, "\n  %s, %s"
          "\n\tDisplay this help information.\n", 
          PMAPP_CmdArgShortHelp_d, PMAPP_CmdArgLongHelp_d);
  fprintf(stdout, "\n  %s, %s <filename>"
          "\n\tSet the name of the log file.  If this option is not "
          "\n\tspecified, no logs are generated.\n", 
          PMAPP_CmdArgShortLogFile_d, PMAPP_CmdArgLongLogFile_d);
  fprintf(stdout, "\n  %s <level>"
          "\n\tSet the logging level to the specified value.\n", 
          PMAPP_CmdArgLongLogLevel_d);
  fprintf(stdout, "\n  %s <ipv4address|hostname>[:<ipv4port>]"
          "\n\tSet the address of the PM H/W remote target.  The default "
          "\n\tIPv4 address is %s and the default port is %d.  "
          "\n\tNote that if the PM H/W is locally connected this option "
          "\n\thas no meaning. \n", 
          _PMM_CMD_ARG_TARGET_ADDRESS,
          _pmm_ipv4if_string_from_address_get(_PMM_PMLA_TARGET_IP_ADDRESS,
                                              ipv4Address_s), 
          _PMM_PMLA_TARGET_IP_PORT);
  fprintf(stdout, "\n  %s"
          "\n\tCompile for 8572 rev 1.0 silicon.", _PMM_CMD_ARG_8572_REV_1_0);
  fprintf(stdout, "\n\n");


  fprintf(stdout, "Example:");
  fprintf(stdout, "\n\t%s %s /dev/stdout %s -1\n", baseName_p, 
          PMAPP_CmdArgShortLogFile_d, PMAPP_CmdArgLongLogLevel_d);
  fprintf(stdout, "\n");


  free(name_p);
} /* _pmm_help_show */


/*
 * Parses all of the command line arguments.
 *
 * param  argn         Number of arguments pmm was invoked with.
 * param  args         The actual command line argument strings.
 * param  appParams_p  The extracted command line argument values.
 * retval              0 upon success;  -1 otherwise.
 */
static int
_pmm_parse_arguments(
  int                argn, 
  char              *args[], 
  _pmm_app_params_t *appParams_p
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s(argn=%d, "
             "args=%p, appParams_p=%p).", __func__, argn, args, appParams_p);

  int   arg               = 1;
  char *tooFewParams_s    =
    "Insufficient number of parameters for the \"%s\" option.\n";


  /* Initialize the application argument values. */
  memset(appParams_p, 0, sizeof(_pmm_app_params_t));

  appParams_p->hwSimFlagOptSetFlag   = false;
  appParams_p->logLevelOptSetFlag    = false;
  appParams_p->logFileNameOptSetFlag = false;
  appParams_p->targetOptSetFlag      = false;
  appParams_p->hwSimFlag             = false;
  appParams_p->exitOnErrorFlag       = false;
  appParams_p->option8572rev1_0Flag  = false;
  appParams_p->logLevel              = PMAPP_DefaultLogLevel_d;
  appParams_p->logFileName_p         = _PMM_DEFAULT_LOG_FILE_NAME;
  appParams_p->targetIpv4Address     = _PMM_PMLA_TARGET_IP_ADDRESS;
  appParams_p->targetIpv4Port        = _PMM_PMLA_TARGET_IP_PORT;
  
  appParams_p->targetChannelId       = _PMM_PMLA_TARGET_CHANNEL_ID;
  appParams_p->pmlaChannelTimeout    = _PMM_PMLA_TIMOUT;


  /* Walk through all the command line arguments */
  while (arg < argn) {
    if (0 == strcmp(args[arg], _PMM_CMD_ARG_PM_hw_simulation)) {
      appParams_p->hwSimFlagOptSetFlag = true;
      appParams_p->hwSimFlag           = true;
    }
    else if ((0 == strcmp(args[arg], _PMM_CMD_ARG_SHORT_EXIT_ON_ERROR)) ||
             (0 == strcmp(args[arg], _PMM_CMD_ARG_LONG_EXIT_ON_ERROR))) {
      appParams_p->exitOnErrorFlag = true;
    }
    else if ((0 == strcmp(args[arg], PMAPP_CmdArgShortHelp_d)) ||
             (0 == strcmp(args[arg], PMAPP_CmdArgLongHelp_d))) {
      _pmm_help_show(args[0]);
      return -1;
    }
    else if (0 == strcmp(args[arg], PMAPP_CmdArgLongLogLevel_d)) {
      appParams_p->logLevelOptSetFlag = true;
      /* Try to get the log level value. */
      arg++;
      if(arg >= argn) {
        fprintf(stdout, tooFewParams_s, PMAPP_CmdArgLongLogLevel_d);
        return -1;
      }
      if (false == cli_uint32get(args[arg], &appParams_p->logLevel)) {
        fprintf(stdout, "The log level value of \"%s\" is invalid.\n",
                args[arg]);
        return -1;
      }
    }
    else if ((0 == strcmp(args[arg], PMAPP_CmdArgShortLogFile_d)) ||
             (0 == strcmp(args[arg], PMAPP_CmdArgLongLogFile_d))) {
      appParams_p->logFileNameOptSetFlag = true;
      /* Try to get the log file name. */
      arg++;
      if(arg >= argn) {
        fprintf(stdout, tooFewParams_s, args[arg - 1]);
        return -1;
      }
      appParams_p->logFileName_p = strdup(args[arg]);
      if (NULL == appParams_p->logFileName_p) {
        fprintf(stdout, "Failed to allocate memory for the log file name.\n");
        return -1;
      }
    }
    else if (0 == strcmp(args[arg], _PMM_CMD_ARG_TARGET_ADDRESS)) {
      appParams_p->targetOptSetFlag = true;
      /* Try to get the IPv4 address and optionally port values. */
      arg++;
      if(arg >= argn) {
        fprintf(stdout, tooFewParams_s, _PMM_CMD_ARG_TARGET_ADDRESS);
        return -1;
      }
      if (false == _pmm_ipv4if_address_from_string_get(
            args[arg], &appParams_p->targetIpv4Address, 
            &appParams_p->targetIpv4Port)) {
        fprintf(stdout, "The address[:port] value of \"%s\" is invalid.\n", 
                args[arg]);
        return -1;
      }
    }
    else if ((0 == strcmp(args[arg], _PMM_CMD_ARG_SHORT_TARGET_CHANNEL)) ||
             (0 == strcmp(args[arg], _PMM_CMD_ARG_LONG_TARGET_CHANNEL))) {
      /* Try to get the channel ID value. */
      arg++;
      if(arg >= argn) {
        fprintf(stdout, tooFewParams_s, args[arg - 1]);
        return -1;
      }
      if (false == cli_uint32get(args[arg], &appParams_p->targetChannelId)) {
        fprintf(stdout, "The channel ID value of \"%s\" is invalid.\n",
                args[arg]);
        return -1;
      }
    }
    else if (0 == strcmp(args[arg], _PMM_CMD_ARG_8572_REV_1_0)) {
      appParams_p->option8572rev1_0Flag = true;
    }
    else {
      fprintf(stdout, "Invalid argument: \"%s\"\n", args[arg]);
      _pmm_help_show(args[0]);
      return -1;
    }
    
    arg++;
  }


  /* If the H/W simulation mode is on we need to set the target
   * channel value to be negative.  Note that H/W simulation on this
   * level is an unsupported feature and can be removed at any time. */
  if (true == appParams_p->hwSimFlag) {
    /* Turn on the PM H/W simulation.  Keep in mind that this is a
     * partial simulation. */
    appParams_p->targetChannelId = -1;
  }
  
  return 0;
} /* _pmm_parse_arguments */


/*
 * Initialize the PMM module.
 *
 * NOTE: At this time the PMM module supports only one PMM and one LL
 *       DBs.  The module would have to be modified to support
 *       multiple PMM/LL DBs.
 *
 * param  appParams_p  Structure with the program argument values.
 * param  cliHandle_p  Where to store the handle of the created CLI menu.
 * retval              0 upon success;  -1 otherwise.
 */
static int
_pmm_module_init(
  _pmm_app_params_t *appParams_p,
  handle_t          *cliHandle_p
  )
{
  cli_status_t   cliStatus                      = cli_error_e;
  idx_status_t   idxStatus                      = idx_error_e;
  db_status_t    dbStatus                       = db_error_e;
  pmll_status_t  pmllStatus                     = pmll_error_e;
  handle_t       logHandle                      = HANDLE_NULL;
  uint32_t       cliMenuOption                  = CLI_MENU_NO_OPTION;
  char           ipv4Address_s[INET_ADDRSTRLEN] = "";
  

  /* Set logging to write the logs to a file. */
  if ((NULL == appParams_p->logFileName_p) || 
      (0 == appParams_p->logFileName_p[0])) {
    /* The log file name has not been specified. */
    log_handle_set(logHandle);
  }
  else {
    logHandle = log_log_to_file(appParams_p->logFileName_p);
    if (HANDLE_NULL == logHandle) {
      fprintf(stdout, "Failed to create the \"%s\" log file.  \"%s\"\n", 
              appParams_p->logFileName_p, strerror(errno));
    }
  }  

  /* Set the log level. */
  log_mask_set(appParams_p->logLevel);
  LOG_STRING(LOG_INFO, _PMM_MODULE_NAME, "Start logging for the PMM "
             "application (logLevel=%#x, logFileName=%s", 
             appParams_p->logLevel, appParams_p->logFileName_p);


  if(appParams_p->exitOnErrorFlag) {
    cliMenuOption = CLI_MENU_EXIT_ON_ERROR_OPTION;
  }
  /* Create the PMM CLI menus and register the command handlers. */
  cliStatus = cli_create_menu("pmm", "PMM main menu", cliHandle_p, 
                              HANDLE_NULL, cliMenuOption);
  if ((HANDLE_NULL == *cliHandle_p) || (cliStatus != cli_ok_e)) {
    fprintf(stdout, "Failed to create the PMM main menu.  %s\n", 
            cli_error_string_get(cliStatus));
    return(-1);
  }

  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_add_cmd_sg, 
                               "add expressions or rules",
                               &_pmm_db_handle_sg, _pmm_pm_menu_add, 
                               CLI_SHOW_EXEC_TIME_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_commit_cmd_sg, 
                               "commit previously added expressions and rules",
                               &_pmm_db_handle_sg, _pmm_pm_menu_commit, 
                               CLI_SHOW_EXEC_TIME_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_delete_cmd_sg, 
                               "delete previously added expressions or rules", 
                               &_pmm_db_handle_sg, _pmm_pm_menu_delete, 
                               CLI_NO_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_ping_cmd_sg, 
                               "ping the pattern matching H/W", 
                               &_pmm_db_handle_sg, _pmm_pm_menu_ping, 
                               CLI_NO_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_read_cmd_sg, 
                               "read information from the pattern matching "
                               "H/W", &_pmm_db_handle_sg, _pmm_pm_menu_read, 
                               CLI_SHOW_EXEC_TIME_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_reset_cmd_sg, 
                               "reset statistics, etc.", 
                               &_pmm_db_handle_sg, _pmm_pm_menu_reset, 
                               CLI_NO_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_set_cmd_sg, 
                               "set modifiable parameters", 
                               &_pmm_db_handle_sg, _pmm_pm_menu_set, 
                               CLI_NO_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  cliStatus = cli_register_cmd(*cliHandle_p, _pmm_show_cmd_sg, 
                               "display expressions, rules, etc.", 
                               &_pmm_db_handle_sg, _pmm_pm_menu_show, 
                               CLI_NO_CMD_FLAG);
  if (cli_ok_e != cliStatus) return -1;
  
  /* Initialize the IDX module. */
  idxStatus = idx_module_init();
  if (idx_ok_e != idxStatus) {
    fprintf(stdout, "Failed to initialize the IDX module.  %s\n",
            idx_error_string_get(idxStatus));
    return -1;
  }
  
  /* Initialize the DB module. */
  dbStatus = db_module_init();
  if (db_ok_e != dbStatus) {
    fprintf(stdout, "Failed to initialize the DB module.  %s\n",
            db_error_string_get(dbStatus));
    return -1;
  }

  /* Initialize the PMLL module. */
  pmllStatus = pmll_module_init(_PMM_INITIAL_PMLL_HANDLE_TABLE_SIZE, true);
  if (pmll_ok_e != pmllStatus) {
    fprintf(stdout, "Failed to initialize the PMLL module.  \"%s\"\n",
            pmll_error_string_get(pmllStatus));
    return -1;
  }

  
  /* Create the PMM DB. */
  _pmm_db_handle_sg = _pmm_db_create(appParams_p);
  if (HANDLE_NULL == _pmm_db_handle_sg) {
    fprintf(stdout, "Failed to create the PMM DB for target with address "
            "%s, port %u and channel %d.\n",
            _pmm_ipv4if_string_from_address_get(appParams_p->targetIpv4Address,
                                                ipv4Address_s), 
            appParams_p->targetIpv4Port, appParams_p->targetChannelId);
    return -1;
  }
  else {
    if (true == appParams_p->targetOptSetFlag) {
      fprintf(stdout, "Successfully created the PMM DB for target with "
              "address %s, port %u and channel %d.\n",
              _pmm_ipv4if_string_from_address_get(
                appParams_p->targetIpv4Address,
                ipv4Address_s), 
              appParams_p->targetIpv4Port, appParams_p->targetChannelId);
    }
    else {
      fprintf(stdout, "Successfully created the PMM DB.\n");
    }

    /* Initialize the PMLL debug sub-module. */
    _pmm_db_t *pmmDb_p = _pmm_db_handle_sg;

    pmllStatus = pmll_debug_init(*cliHandle_p, &pmmDb_p->llDbHandle);
    if (pmll_ok_e != pmllStatus) {
      fprintf(stdout, "Failed to initialize the PMLL debug sub-module.  "
              "\"%s\"  Continuing anyway.\n", 
              pmll_error_string_get(pmllStatus));
    }
  }

  return 0;
} /* _pmm_module_init */


/* 
 * Runs the PMM module.
 *
 * param  cliHandle  CLI handle to use.
 * retval            0 upon success;  -1 otherwise.
 */
static int
_pmm_module_run(
  handle_t  cliHandle
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s().", __func__);

  char         *homeEnvVariable_p = "HOME";
  char         *homeDir_p         = getenv(homeEnvVariable_p);
  char         *historyFileName_p = ".pmmhistory";
  char         *historyFilePath_p = historyFileName_p;
  int           status            = 0;
  bool          freeMeFlag        = false;
  

  /* We try to open the pmm history file in the user's home directory. */
  if (NULL == homeDir_p) {
    fprintf(stdout, "Failed to retrieve the \"%s\" environment variable "
            "needed to build the %s history file name.  Attempting to store "
            "the history file in the current directory.\n", 
            homeEnvVariable_p, _PMM_MODULE_NAME);
  }
  else {
    /* Build the file name string. */
    historyFilePath_p = mem_calloc(1, strlen(homeDir_p) + 
                                   strlen(historyFileName_p) + 2);
    if (NULL == historyFilePath_p) {
      fprintf(stdout, "Failed to allocate memory needed to open the %s "
              "history file in the user home directory.  Attempting to store "
              "the history file in the current directory.\n", 
              _PMM_MODULE_NAME);
      historyFilePath_p = historyFileName_p;
    }
    else {
      freeMeFlag = true;
      strcat(historyFilePath_p, homeDir_p);
      strcat(historyFilePath_p, "/");
      strcat(historyFilePath_p, historyFileName_p);
    }
  }
  

  /* Start the PMM CLI loop.  This loop runs until the CLI exits. */
  status = cli_start(cliHandle, historyFilePath_p);
  if (status != 0) {
    fprintf(stdout, "CLI module exited with an error code of %d.\n", status);
  }

  if (true == freeMeFlag) {
    mem_free(historyFilePath_p);
  }
  
  return status;
} /* _pmm_module_run */


/* 
 * Shuts down the PMM module.
 *
 * param cliHandle  CLI handle to use.
 */
static void
_pmm_module_shutdown(
  handle_t  cliHandle
  )
{
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Entering function: %s().", __func__);

  cli_status_t   cliStatus  = cli_error_e;
  pmll_status_t  pmllStatus = pmll_ok_e;
  

  /* Destroy the PMM menus. */
  LOG_STRING(LOG_TEST, _PMM_MODULE_NAME, "Destroying the PMM menus.");
  cliStatus = cli_destroy_menu(cliHandle);
  if (cliStatus != cli_ok_e) {
    LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to destroy the PMM "
               "menus.  \"%s\"\n", cli_error_string_get(cliStatus));
  }


  /* Destroy the PMM DB. */
  if (false == _pmm_db_destroy(_pmm_db_handle_sg)) {
    fprintf(stdout, "Failed to destroy the PMM DB.\n");
  }
  

  /* Shutdown the PMLL module. */
  pmllStatus = pmll_module_shutdown();
  if (pmll_ok_e != pmllStatus) {
    LOG_STRING(LOG_WARNING, _PMM_MODULE_NAME, "Failed to shutdow the PMLL "
               "module.  \"%s\"\n", pmll_error_string_get(pmllStatus));
  }
  

#ifdef PMM_DEBUG
  mem_show(stdout, "Memory usage summary:\n");
#endif /* PMM_DEBUG */

} /* _pmm_module_shutdown */








/*--------------------- Public Function Definitions ---------------*/

/*
 * The main entry point for the PMM module (application).
 *
 * retval  0 upon success;  -1 otherwise.
 */
int 
main(int argn, char *args[])
{
  uint32_t              status    = 0;
  handle_t              cliHandle = HANDLE_NULL;
  _pmm_app_params_t     appParams;
  
  /* Parse the PMM module arguments. */
  if(0 != _pmm_parse_arguments(argn, args, &appParams)) {
    /* Nothing else to do here since the above function call took care
     * of all the user notification */
    return(-1);
  }


  /* Initialize the PMM module. */
  if(0 != _pmm_module_init(&appParams, &cliHandle)) {
    fprintf(stdout, "Failed to initialize the PMM module.\n");
    return(-1);
  }

  /* Run the PMM module. */
  status = _pmm_module_run(cliHandle);
  
 
  /* Shut down the PMM module. */
  _pmm_module_shutdown(cliHandle);
    

  fprintf(stdout, "Terminating the PMM application.\n\n");

  return status;
} /* main */

