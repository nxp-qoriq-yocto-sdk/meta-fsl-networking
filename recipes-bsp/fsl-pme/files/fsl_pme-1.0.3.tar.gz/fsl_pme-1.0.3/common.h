/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef VERIFICATION_PM_DMA_COMMON_H
#define VERIFICATION_PM_DMA_COMMON_H

#include <common-user.h>
#define RENAME_PM2PME
#include <driver.h>

#define USAGE_CLEAR	"          "
#define USAGE_ERROR	"Error, usage:   "

static inline int parse_int(const char *arg, int *val, const char *s)
{
	char *cptr;
	long lval = strtol(arg, &cptr, 0);
	if((((lval == LONG_MAX) || (lval == LONG_MIN)) && (errno == ERANGE)) ||
			(*cptr != '\0')) {
		fprintf(stderr, "ERROR, invalid parameter '%s' for %s\n",
			arg, s);
		return -1;
	}
	*val = (int)lval;
	return 0;
}

static inline int parse_uint(const char *arg, unsigned int *val, const char *s)
{
	char *cptr;
	unsigned long lval = strtoul(arg, &cptr, 0);
	if(((lval == ULONG_MAX) && (errno == ERANGE)) || (*cptr != '\0')) {
		fprintf(stderr, "ERROR, invalid parameter '%s' for %s\n",
			arg, s);
		return -1;
	}
	*val = (unsigned int)lval;
	return 0;
}

static inline int parse_uint_ex(const char *arg, unsigned int *val, const char *s,
				const char *valid_eos, char **cptr)
{
	unsigned long lval = strtoul(arg, cptr, 0);
	if(((lval == ULONG_MAX) && (errno == ERANGE)) ||
			((**cptr != '\0') && !strchr(valid_eos, **cptr))) {
		fprintf(stderr, "ERROR, invalid parameter '%s' for %s\n",
			arg, s);
		return -1;
	}
	*val = (unsigned int)lval;
	return 0;
}

static inline int parse_uchar(const char *arg, unsigned char *val, const char *s)
{
	char *cptr;
	unsigned long lval = strtoul(arg, &cptr, 0);
	if(((lval == ULONG_MAX) && (errno == ERANGE)) || (*cptr != '\0')) {
		fprintf(stderr, "ERROR, invalid parameter '%s' for %s\n",
			arg, s);
		return -1;
	}
	*val = (unsigned char)lval;
	return 0;
}

static inline int parse_addr(const char *arg, void **val, const char *s)
{
	char *cptr;
	unsigned long lval = strtoul(arg, &cptr, 0);
	if(((lval == ULONG_MAX) && (errno == ERANGE)) || (*cptr != '\0')) {
		fprintf(stderr, "ERROR, invalid parameter '%s' for %s\n",
			arg, s);
		return -1;
	}
	*val = (void *)lval;
	return 0;
}

#endif /* !defined(VERIFICATION_PM_DMA_COMMON_H) */
