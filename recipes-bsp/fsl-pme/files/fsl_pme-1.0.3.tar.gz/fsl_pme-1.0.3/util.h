/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef VERIFICATION_PM_DMA_UTIL_PRIVATE_H
#define VERIFICATION_PM_DMA_UTIL_PRIVATE_H

#include "common.h"

int ckill(int argc, char *argv[]); /* Avoid conflicts with 'kill' */
int creset(int argc, char *argv[]); /* Avoid conflicts with 'reset' */
int cload(int argc, char *argv[]); /* Avoid conflicts with 'load' */
int cunload(int argc, char *argv[]);
int monitor(int argc, char *argv[]);
int writeback(int argc, char *argv[]);
#ifndef PLATFORM_8572_ds_git
int reg(int argc, char *argv[]);
int cds(int argc, char *argv[]);
int fix3794(int argc, char *argv[]);
int lock(int argc, char *argv[]);
int unlock(int argc, char *argv[]);
int invalidate(int argc, char *argv[]);
#endif

#endif /* !defined(VERIFICATION_PM_DMA_UTIL_PRIVATE_H) */

