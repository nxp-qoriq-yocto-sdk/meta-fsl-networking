/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"

static int usage(int verbose, int retval)
{
	fprintf(stderr, "%sunload <channel-num> [-nb]\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose) {
		fprintf(stderr, "%s    Unload a channel\n", USAGE_CLEAR);
		fprintf(stderr, "%s    -nb won't wait for device-destruction\n",
				USAGE_CLEAR);
	}
	return retval;
}

#define DEFAULT_BLOCKING_MAX	10	/* seconds */

int cunload(int argc, char *argv[])
{
	int fd, blocking = 1, blocking_timeout = DEFAULT_BLOCKING_MAX;
	struct pme_ctrl_channel l = {
		.cmd = CHANNEL_UNLOAD,
		.block = 1
	};
#define ARGINC	{argc--;argv++;}

	if(argc < 2) return usage(1, 0);
	ARGINC;
	if(!argc) return usage(1, -1);
	if(parse_uchar(*argv, &l.channel, "<channel-num>"))
		return usage(1, -1);
	ARGINC;
	if(argc > 1) return usage(1, -1);
	if(argc) {
		if(strcmp(*argv, "-nb"))
			return usage(1, -1);
		blocking = 0;
	}
	fd = open(PME_CTRL_PATH, O_RDONLY);
	if(fd < 0) {
		perror("opening control device failed");
		return -1;
	}
	if(ioctl(fd, PME_CTRL_IOCTL_CHANNEL, &l)) {
		perror("PM_CTRL_IOCTL_CHANNEL failed");
		return -1;
	}
	close(fd);
	if(blocking) {
		char cpath[32];
		struct stat devstat;
		sprintf(cpath, PME_CHANNEL_PATH, l.channel);
		while(blocking_timeout-- && !stat(cpath, &devstat))
			sleep(1);
		if(!blocking_timeout) {
			fprintf(stderr, "ERROR, timeout waiting for destruction "
					"of '%s'\n", cpath);
			return -1;
		}
		printf("channel device deleted: %s\n", cpath);
	}
	return 0;
}
