/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"

struct subfn {
	const char *name;
	int (*fn)(int, char **);
};

static struct subfn fns[] = {
	{ "kill", ckill },
	{ "reset", creset },
	{ "load", cload },
	{ "unload", cunload },
	{ "monitor", monitor },
	{ "writeback", writeback },
#ifndef PLATFORM_8572_ds_git
	{ "reg", reg },
	{ "cds", cds },
	{ "fix3794", fix3794 },
	{ "lock", lock },
	{ "unlock", unlock },
	{ "invalidate", invalidate},
#endif
	{ NULL, NULL }
};

static int usage(void)
{
	struct subfn *fnptr = fns;
	fprintf(stderr, "Error, usage: pm_util <fn> [opts]\n");
	fprintf(stderr, "where <fn> is one of;\n");
	while(fnptr->name)
		(fnptr++)->fn(-1, NULL);
	return -1;
}

int main(int argc, char *argv[])
{
	struct subfn *fnptr = fns;

	if(argc < 2)
		return usage();
	while(fnptr->name && strcmp(fnptr->name, argv[1]))
		fnptr++;
	if(!fnptr->name)
		return usage();
	return fnptr->fn(argc - 1, argv + 1);
}
