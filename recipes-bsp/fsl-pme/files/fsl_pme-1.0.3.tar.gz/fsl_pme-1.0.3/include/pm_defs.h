/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/************************************************************************
*   File Name : pm_defs.h
*
*   This file contains the public interface definitions that are
*   common to all the different Pattern Matching modules, e.g., the
*   compilers, linker-loader, Pattern Matching Manager (PMM), etc.
*
************************************************************************/
#ifndef PM_DEFS_H_INCLUDE
#define PM_DEFS_H_INCLUDE




/*--------------------- Include Files -----------------------------*/

#include <generic_types.h>






/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the maximum number of patterns that are
 * supported by the PM system. */
#define PM_PATTERN_MAX_NUM                      16000


/* This macro defines the maximum number of stateful rules that can
 * be supported by the PM H/W. */
#define PM_STATEFUL_RULE_MAX_NUM                8192


/* This macro defines the maximum length of the name strings used in
 * the pattern matching modules (the value should include the
 * terminating NULL character). */
#define PM_NAME_MAX_LENGTH                      32


/* This macro defines the size of the key element entry in an
 * expression record.  */
#define PM_KEY_ELEMENT_ENTRY_SIZE               136


/* This macro defines the size of the confirmation entry in an
 * expression record. */
#define PM_CONFIRMATION_ENTRY_SIZE              512


/* This macro defines the maximum size of a rule.  Strictly speaking
 * it defines the maximum size of a reaction in a rule.  Reaction is
 * the part of a rule that is associated with a specific expression. */
#define PM_MAX_REACTION_SIZE                    248


/* The next two macros define the rule and regex record types. */
#define PM_COMPILED_RULE_RECORD_TYPE            0xa9b8c7d6
#define PM_COMPILED_REGEX_RECORD_TYPE           0xa8b7c6d5


/* The next macro defines the size of the equivalence table. */
#define PM_EQUIVALENCE_TABLE_SIZE               256


/* This macro defines the default PM equivalence table. */
#define PM_DEFAULT_EQUIVALENCE_TABLE                                     \
  {                                                                      \
      0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,     /* ........ */ \
      0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,     /* ........ */ \
      0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,     /* ........ */ \
      0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,     /* ........ */ \
      0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,     /*  !"#$%&' */ \
      0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,     /* ()*+,-./ */ \
      0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,     /* 01234567 */ \
      0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,     /* 89:;<=>? */ \
      0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,     /* @ABCDEFG */ \
      0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,     /* HIJKLMNO */ \
      0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,     /* PQRSTUVW */ \
      0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,     /* XYZ[\]^_ */ \
      0x60, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,     /* `ABCDEFG */ \
      0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,     /* HIJKLMNO */ \
      0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,     /* PQRSTUVW */ \
      0x58, 0x59, 0x5a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,     /* XYZ{|}~. */ \
      0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,     /* ........ */ \
      0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e, 0x8f,     /* ........ */ \
      0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,     /* ........ */ \
      0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f,     /* ........ */ \
      0xa0, 0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,     /* ........ */ \
      0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,     /* ........ */ \
      0xb0, 0xb1, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7,     /* ........ */ \
      0xb8, 0xb9, 0xba, 0xbb, 0xbc, 0xbd, 0xbe, 0xbf,     /* ........ */ \
      0xc0, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,     /* ........ */ \
      0xc8, 0xc9, 0xca, 0xcb, 0xcc, 0xcd, 0xce, 0xcf,     /* ........ */ \
      0xd0, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7,     /* ........ */ \
      0xd8, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0xde, 0xdf,     /* ........ */ \
      0xe0, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7,     /* ........ */ \
      0xe8, 0xe9, 0xea, 0xeb, 0xec, 0xed, 0xee, 0xef,     /* ........ */ \
      0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,     /* ........ */ \
      0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff      /* ........ */ \
   }


/* The next two macros define the binary expression and rule record
 * versions supported. */
#define PM_REGEX_BIN_RECORD_V_1_0_1             0x00010001  
#define PM_REGEX_BIN_RECORD_V_2_0_0             0x00020000  
#define PM_RULE_BIN_RECORD_V_1_0_0              0x00010000  

#define PM_PME_VERSION_1_1                      0x00000101

#define PM_SI_VERSION_1_0                       0x00000100
#define PM_SI_VERSION_1_1                       0x00000101



/*--------------------- Type Definitions---------------------------*/

/* This type defines the pattern record. */
typedef struct pm_pattern_record_t {
  uint8_t                     keyElementEntry[PM_KEY_ELEMENT_ENTRY_SIZE];
  uint8_t                     confirmationEntry[PM_CONFIRMATION_ENTRY_SIZE];
  struct pm_pattern_record_t *nextPatternRecord_p;
} pm_pattern_record_t;
    

/* This type defines the version 1.0.1 of the PMLL expression record
 * (this value is available as the PMLL_EXP_RECORD_V_1_0_1 macro).
 * The user is expected to use the data in the regular expression
 * compiler generated pm_exp_bin_record_t record to build the version
 * 1.0.1 of the PMLL expression record as defined below.  The user is
 * also expected to cast the version specific PMLL record, e.g.,
 * pm_exp_record_v_1_0_1_t, to the generic PMLL record type
 * pm_exp_record_t and use this generic type in the PMLL functions. */
typedef struct {
  char                 name_s[PM_NAME_MAX_LENGTH];
  pm_pattern_record_t  patterns;
} pm_exp_record_v_1_0_1_t;


/* This type defines the generic PMLL expression record as accepted by
 * the PMLL functions. */
typedef uint8_t *pm_exp_record_t;


/* This type defines the supported reaction event type values. */
typedef enum {
  pm_null_reaction_event_type_e       =  0,
  pm_pattern_reaction_event_type_e    =  1,
  pm_end_of_sui_reaction_event_type_e =  2,

  pm_last_reaction_event_type_e       = pm_end_of_sui_reaction_event_type_e
} pm_reaction_event_type_t;


/* This type defines a reaction that is a part of a rule record. */
typedef struct pm_reaction_entry_t {
  uint32_t                    reactionEventType;
  char                        expName_s[PM_NAME_MAX_LENGTH];
  struct pm_reaction_entry_t *nextReactionEntry_p;
  uint32_t                    reactionSize;
  uint8_t                     reactionData[PM_MAX_REACTION_SIZE];
} pm_reaction_entry_t;


/* This type defines the version 1.0.0 of the PMLL rule record  
 * (this value is available as the PMLL_RULE_RECORD_V_1_0_0 macro).
 * The user is expected to use the data in the stateful rule compiler
 * generated pm_rule_bin_record_t record to build the version 
 * 1.0.0 of the PMLL rule record as defined below.  The user is
 * also expected to cast the version specific PMLL record, e.g.,
 * pm_rule_record_v_1_0_0_t, to the generic PMLL record type
 * pm_rule_record_t and use this generic type in the PMLL functions. */
typedef struct ruleRecord_t {
  char                 name_s[PM_NAME_MAX_LENGTH];
  uint32_t             reactionNum; /* number of reactions in the rule */
  pm_reaction_entry_t *reactionEntry_p;
} pm_rule_record_v_1_0_0_t;


/* This type defines the generic PMLL rule record as accepted by the
 * PMLL functions. */
typedef uint8_t *pm_rule_record_t;


/* The next two types describe the binary record as generated by the
 * Regular Expression Compiler (REC) for a single regular expression.
 * Note that these types ARE NOT an exact definition of the binary
 * regex record.  The reason for not being exact is because a number
 * of the fields in the record have variable length.  Each variable
 * length field is preceded with a field specifying the actual length
 * of the field that follows.  Note that while some fields, e.g., the
 * expression string, have variable length by definition and can vary
 * from record to record, some other fields, e.g., the key element or
 * confirmation entries, have fixed lengths and have the same length
 * in all the records.  The letter fields use the concept of variable
 * length to accommodate any future changes in the length of these
 * fields. */
typedef struct {
  uint32_t  triggerEntryLength;
  uint8_t  *triggerEntry_p;         /* field size is triggerEntryLength */
  uint32_t  keyElementEntryLength;
  uint8_t  *keyElementEntry_p;      /* field size is keyElementEntryLength */
  uint32_t  confirmationEntryLength;
  uint8_t  *confirmationEntry_p;    /* field size is confirmationEntryLength */
} pm_pattern_bin_entry_t;


typedef struct {
  uint32_t                type;              /* e.g. PM_COMPILED_REGEX_RECORD_TYPE */
  uint32_t                record_version;    /* e.g., PM_REGEX_BIN_RECORD_V_1_0_1 */
  uint32_t                pme_version;
  uint32_t                silicon_version;
  uint32_t                nameStringLength;
  char                   *nameString_p;          /* field size is nameLength */
  uint32_t                expressionStringLength;
  char                   *expressionString_p;    /* f. size is expression_s */
  uint32_t                optionStringLength;
  char                   *optionString_p;        /* f. size is optionsLength */
  uint32_t                patternEntryNum;       /* num. of patterns in exp. */
  pm_pattern_bin_entry_t *patternEntry_p;
} pm_exp_bin_record_t;


/* This type describes the part of a binary record that contains  one
 * reaction, i.e., rule data for one expression, that is used by the
 * rule.  Each of the reactions in a rule will have a sub-record like
 * this.  This sub-record is generated by the Stateful Rule Compiler
 * (SRC).  Please see the comments for the pm_pattern_bin_entry_t type
 * for more details. */
typedef struct {
  uint32_t  eventType;               /* type of the event */
  uint32_t  expNameStringLength;     /* name of the expression */
  char     *expNameString_p;         /* field size is nameLength */
  uint32_t  reactionSize; 
  uint8_t  *reaction_p;              /* field size is ruleInExpSize */
} pm_reaction_bin_entry_t;


/* This type describes the binary record as generated by the Stateful
 * Rule Compiler (SRC) for a single rule.  Please see the comments for
 * the pm_pattern_bin_entry_t type for more details. */
typedef struct {
  uint32_t                 type;
  uint32_t                 version;      /* e.g., PM_RULE_BIN_RECORD_V_1_0_0 */
  uint32_t                 ruleNameStringLength;
  char                    *ruleNameString_p;  /* name of the rule */
  uint32_t                 reactionEntryNum;  /* number of exps. in the rule */
  pm_reaction_bin_entry_t *reactionEntry_p;
} pm_rule_bin_record_t;







/*--------------------- Private Global Data Definitions -----------*/








/*--------------------- Function Declarations ---------------------*/







/*--------------------- Function Definitions ----------------------*/








#endif /* PM_DEFS_H_INCLUDE */

