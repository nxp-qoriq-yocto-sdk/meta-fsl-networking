/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
*   File Name : generic_types.h
*
*   This file contains generic type definitions.
*
****************************************************************************/
#ifndef GENTYPES_H_INCLUDE
#define GENTYPES_H_INCLUDE



/**********************************************************************
 * Include Files
 **********************************************************************/

#include <inttypes.h>  /* for the standard integer types and their 
                          printing format specifier macros */
#include <stdbool.h>   /* for the bool type */






/**********************************************************************
 * Macro Definitions
 **********************************************************************/

/* The next two macros define the format to use to print handles
 * defined using the handle_t type and a NULL handle. */
#define PRI_HANDLE    "p"
#define HANDLE_NULL   NULL


/* The code in this file depends on the __BYTE_ORDER macro to be
 * defined.  We check here if it is defined. */
#include <byteswap.h>
#include <endian.h>
#include <netinet/in.h>

#ifndef __BYTE_ORDER
#  error "__BYTE_ORDER is not defined."
#else
#  if __BYTE_ORDER == __BIG_ENDIAN
#  else
#    if __BYTE_ORDER == __LITTLE_ENDIAN  
#    else
#      error "__BYTE_ORDER is neither __BIG_ENDIAN nor __LITTLE_ENDIAN."
#    endif
#  endif
#endif

/* The macros below are used to perform translations from the host to
 * the PE H/W and from the PE H/W to the host formats.  We also define
 * the "ll" versions of the ntoh/hton macros if they are not available. */
#if !defined(htonll) || !defined(ntohll)
#  if __BYTE_ORDER == __BIG_ENDIAN
#    define htonll(x)                      (x)
#    define ntohll(x)                      (x)
#  else /* __BYTE_ORDER == __LITTLE_ENDIAN */
#    define htonll(x)                      (bswap_64 (x))
#    define ntohll(x)                      (bswap_64 (x))
#  endif
#endif




/**********************************************************************
 * Type Definitions
 **********************************************************************/

/* This type defines a generic handle type.  The PRI_HANDLE macro
 * should be used as a format when printing such handles. */
typedef void* handle_t;






/**********************************************************************
 * Private Global Data Definitions
 **********************************************************************/







/**********************************************************************
 * Function Declarations
 **********************************************************************/







/**********************************************************************
 * Function Definitions
 **********************************************************************/








#endif /* GENTYPES_H_INCLUDE */

