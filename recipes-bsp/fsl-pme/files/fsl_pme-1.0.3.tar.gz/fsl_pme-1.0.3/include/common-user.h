/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef COMMON_USER_H
#define COMMON_USER_H

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <inttypes.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <linux/types.h>

/* If you have a parameter to a function that is not used, you can avoid the
 * consequent warning by declaring it with the UNUSED macro. It has the
 * side-effect that if you later start using the parameter, the compiler will
 * complain (which will remind you to get rid of the UNUSED declaration).
 *
 * Eg.
 *      int main(int argc, char **argv) {
 *          printf("%d\n", argc);
 *          return 0;
 *      }
 *      
 * compiler complains; "warning: unused parameter 'argv'"
 * Replace it with;
 * 
 *      int main(int argc, UNUSED(char **,argv)) {
 *          printf("%d\n", argc);
 *          return 0;
 *      }
 */
#define UNUSED(type,foo) __attribute__((unused)) type junk_123456_##foo

/* This allows you to use code or macro parameters as strings. Eg.
 *
 *      // this macro returns non-zero if cond was satisfied
 *      #define wait_for(cond,secs) \
 *              ({ \
 *                  int __secs = (secs); \
 *                  printf("Waiting for: " stringify(cond) "\n"); \
 *                  while(!(cond) && __secs--) \
 *                      sleep(1); \
 *                  (cond); \
 *              })
 *
 * Then, if you then write something like;
 *
 *      #define MYTIMEOUT 5
 *      printf("After " stringify(MYTIMEOUT) " seconds, result %d\n",
 *          wait_for(1 + 1 == 3, 5));
 *
 * you will see the output;
 *
 *      Waiting for: 1 + 1 == 3
 *      After 5 seconds, result 0
 */
#define __stringify_tmp(a) #a
#define stringify(a) __stringify_tmp(a)



#endif /* COMMON_USER_H */
