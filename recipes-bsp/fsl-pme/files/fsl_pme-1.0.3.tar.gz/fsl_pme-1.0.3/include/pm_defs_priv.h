/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/************************************************************************
*   File Name : pm_defs_priv.h
*
*   This file contains the private interface definitions that can be
*   used by different Pattern Matching modules, e.g., the compilers,
*   linker-loader, etc., but not by the user modules, e.g., the
*   Pattern Matching Manager (PMM).
*
************************************************************************/
#ifndef PM_DEFS_PRIV_H_INCLUDE
#define PM_DEFS_PRIV_H_INCLUDE




/*--------------------- Include Files -----------------------------*/

/* The code in this file depends on the __BYTE_ORDER macro to be
 * defined.  We check here if it is defined. */
#include <byteswap.h>
#include <endian.h>
#ifndef __BYTE_ORDER
#  error "__BYTE_ORDER is not defined."
#endif


#include <generic_types.h>
#include <pm_defs.h>
#include <pmp.h>






/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the size of the trigger type in the binary file. */
#define _PM_TRIGGER_TYPE_SIZE                   4

/* This macro defines the size of the confidence mask type in the binary
 * file.*/
#define _PM_CONFIDENCE_MASK_TYPE_SIZE           2

/* This macro defines the size of the confidence mask alignment in the
 * binary file. */
#define _PM_CONFIDENCE_MASK_ALIGNMENT_SIZE      2

/* This macro defines the number of the symbols in the key element. */
#define _PM_KEY_ELEMENT_SYMBOL_NUM             64


/* This macro defines the maximum number of test lines in a single
 * confirmation record. */
#define _PM_CONFIRMATION_ENTRY_TEST_LINES_NUM  30


/* This macro defines the size (in bytes) of a test line. */
#define _PM_TEST_LINE_SIZE                     16


/* This macro defines the size (in bytes) of a cache line. */
#define _PM_CACHE_LINE_SIZE                    32


/* This macro defines the size (in bytes) of a compare value in a test
 * line. */
#define _PM_TEST_LINE_COMP_VALUE_SIZE          8


/* This macro is used to let the compiler know to pack a data structure. */
#define _PM_PACKED                             __attribute__((packed))


/* This macro defines the name used for the end-of-SUI reactions. */
#define _PM_END_OF_SUI_NAME                    "##END_OF_SUI##"









/*--------------------- Type Definitions---------------------------*/

/* This type defines the possilbe symbol types, as used in the
 * definition of a symbol (_pm_symbol_t) below. */
typedef enum {
  _pm_class_symbol_type_e       = 0,  /* 'c' */
  _pm_user_group_symbol_type_e  = 1,  /* 'u' */
  _pm_symbol_symbol_type_e      = 2,  /* 's' */
  _pm_equivalence_symbol_type_e = 3   /* 'e' */
} _pm_symbol_type_t;


/* This type defines the supported trigger types. */
typedef enum {
  _pm_null_trigger_type_e                      =  0,
  _pm_variable_trigger_type_e                  =  1,
  _pm_two_byte_trigger_type_e                  =  2,
  _pm_one_byte_trigger_type_e                  =  3,
  /* The remaining triggers are the special triggers.  We use the
   * _pm_special_trigger_type_e trigger type in situations when we
   * refer to the entire set of the special triggers, and the other
   * special triggers when we refer to specific special triggers. */
  _pm_special_trigger_type_e                   =  4,
  _pm_start_of_stream_trigger_type_e           =  5,
  _pm_start_of_unit_trigger_type_e             =  6,
  _pm_start_of_stream_multiline_trigger_type_e =  7,
  _pm_start_of_unit_multiline_trigger_type_e   =  8,
  _pm_end_of_unit_multiline_trigger_type_e     =  9,
  _pm_end_of_stream_multiline_trigger_type_e   = 10,
  _pm_end_of_unit_trigger_type_e               = 11,
  _pm_end_of_stream_trigger_type_e             = 12,
} _pm_trigger_type_t;


/* This type defines the symbol as used in the key element. */
typedef struct {
  union {
    uint8_t  code;
    struct {
#   if __BYTE_ORDER == __LITTLE_ENDIAN
      uint8_t  type     : 2;  /* see _pm_symbol_type_t for values */
      uint8_t  unused   : 5;
      uint8_t  validFlag: 1;  /* 1 - valid; 0 - not valid */
#   else
#     if __BYTE_ORDER == __BIG_ENDIAN  
      uint8_t  validFlag: 1;  /* 1 - valid; 0 - not valid */
      uint8_t  unused   : 5;
      uint8_t  type     : 2;  /* see _pm_symbol_type_t for values */
#     else
#       error "__BYTE_ORDER is neither __LITTLE_ENDIAN nor __BIG_ENDIAN."
#     endif
#   endif
    };
  } _PM_PACKED;
  uint8_t  value;
} _PM_PACKED _pm_symbol_t;


/* This type defines the supported values of the confidence mask type. */
typedef enum {
  _pm_null_confidence_mask_type_e   =  0,
  _pm_anchor_confidence_mask_type_e =  1,
} _pm_confidence_mask_type_p;


/* This type defines the supported values of the anchor confidence
 * mask alignment. */
typedef enum {
  _pm_null_confidence_mask_alignment_e = 0,
  _pm_32_confidence_mask_alignment_e   = 32,
} _pm_confidence_mask_alignment_p;


/* This type defines the key element entry. */
typedef struct {
  uint32_t      triggerType;            /* _pm_trigger_type_t */
  uint16_t      confidenceMaskType;     /* _pm_confidence_mask_type_p */
  uint16_t      confidenceMaskAlignment;/* _pm_confidence_mask_alignment_t */
  _pm_symbol_t  symbols[_PM_KEY_ELEMENT_SYMBOL_NUM];  
} _PM_PACKED _pm_key_element_entry_t;


/* This type defines a test line. */
typedef struct {
  union {
    uint8_t  testLine[_PM_TEST_LINE_SIZE];
    struct {
#   if __BYTE_ORDER == __LITTLE_ENDIAN
      /* byte with bits 120-127 */
      struct {
        uint8_t  captureCode  : 4;  /* capture code */
        uint8_t  unused2      : 1;
        uint8_t  cautiousFlag : 1;  /* 1 - a flag used in handling repeats */
        uint8_t  pecFlag      : 1;  /* 1 - Parallel Element Compare record */
        uint8_t  unused1      : 1;
      } _PM_PACKED;
      /* byte with bits 112-119 */
      struct {
        uint8_t  passLink     : 5;
        uint8_t  unused       : 2;
        uint8_t  side         : 1;  /* 0/1 - left/right from the L/R marker */
      } _PM_PACKED;
      /* byte with bits 104-111 */
      struct {
        uint8_t  altLink      : 5;  /* next alternate TL to use */
        uint8_t  unused       : 3;  /* next TL to use after pass */
      } _PM_PACKED;
      /* byte with bits 96-103 */
      struct {
        uint8_t  minRepeatNum : 7;  /* minimum repeat number for this TL */
        uint8_t  unused       : 1;
      } _PM_PACKED;
      /* byte with bits 88-95 */
      struct {
        uint8_t  maxRepeatNum : 7;  /* maximum repeat number for this TL */
        uint8_t  unused       : 1;
      } _PM_PACKED;
#   else
#     if __BYTE_ORDER == __BIG_ENDIAN  
      /* byte with bits 120-127 */
      struct {
        uint8_t  unused1      : 1;
        uint8_t  pecFlag      : 1;  /* 1 - Parallel Element Compare record */
        uint8_t  cautiousFlag : 1;  /* 1 - a flag used in handling repeats */
        uint8_t  unused2      : 1;
        uint8_t  captureCode  : 4;  /* capture code */
      } _PM_PACKED;
      /* byte with bits 112-119 */
      struct {
        uint8_t  side         : 1;  /* 0/1 - left/right from the L/R marker */
        uint8_t  unused       : 2;
        uint8_t  passLink     : 5;
      } _PM_PACKED;
      /* byte with bits 104-111 */
      struct {
        uint8_t  unused       : 3;  /* next TL to use after pass */
        uint8_t  altLink      : 5;  /* next alternate TL to use */
      } _PM_PACKED;
      /* byte with bits 96-103 */
      struct {
        uint8_t  unused       : 1;
        uint8_t  minRepeatNum : 7;  /* minimum repeat number for this TL */
      } _PM_PACKED;
      /* byte with bits 88-95 */
      struct {
        uint8_t  unused       : 1;
        uint8_t  maxRepeatNum : 7;  /* maximum repeat number for this TL */
      } _PM_PACKED;
#     else
#       error "__BYTE_ORDER is neither __LITTLE_ENDIAN nor __BIG_ENDIAN."
#     endif
#   endif
      /* byte with bits 80-87 (87-80) */
      uint8_t   elementCode;
      /* byte with bits 64-79 (79-64) */
      uint8_t   compType1;
      uint8_t   compType2;
      /* byte with bits  0-63 (63-0) */
      uint8_t   compValue[_PM_TEST_LINE_COMP_VALUE_SIZE];
    } _PM_PACKED;
  } _PM_PACKED;
} _PM_PACKED _pm_test_line_t;


/* This type defines the head test line. */
typedef struct {
  union {
    uint8_t  headTestLine[_PM_TEST_LINE_SIZE];
    struct {
#   if __BYTE_ORDER == __LITTLE_ENDIAN
      /* byte with bits 120 - 127 */
      struct {
        int8_t  startPosition: 7;  /* start position in the 1st TL */
        int8_t  unused       : 1;
      } _PM_PACKED;
      /* byte with bits 112 - 119 */
      struct {
        uint8_t  validTlNum  : 5; /*  number of valid TLs */
        uint8_t  unused      : 2;
        uint8_t  reportFlag  : 1;  /* 1 - report a match; 0 - do not report */
      } _PM_PACKED;
#   else
#     if __BYTE_ORDER == __BIG_ENDIAN  
      /* byte with bits 127 - 120 */
      struct {
        int8_t  unused       : 1;
        int8_t  startPosition: 7;  /* start position in the 1st TL */
      } _PM_PACKED;
      /* byte with bits 119 - 112 */
      struct {
        uint8_t  reportFlag  : 1;  /* 1 - report a match; 0 - do not report */
        uint8_t  unused      : 2;
        uint8_t  validTlNum  : 5; /* number of valid TLs */
      } _PM_PACKED;
#     else
#       error "__BYTE_ORDER is neither __LITTLE_ENDIAN nor __BIG_ENDIAN."
#     endif
#   endif
      uint8_t   unused1;         /* 111 - 104 */
      uint8_t   set;             /* 103 -  96 expression set */
      uint16_t  unused2;         /*  95 -  80 */
      uint16_t  subsetMask;      /*  79 -  64 subset mask */
      uint32_t  reactionIdx;     /*  63 -  32 first reaction index */
      uint32_t  tag;             /*  31 -   0 user tag */
    } _PM_PACKED;
  } _PM_PACKED;
} _PM_PACKED _pm_head_test_line_t;


/* This type defines the "extension" test line. */
typedef struct {
  union {
    uint8_t  extTestLine[_PM_TEST_LINE_SIZE];
    struct {
      uint32_t  unused;   /* 127 - 96 */
      uint32_t  ext1Idx;  /*  95 - 64 */
      uint32_t  ext2Idx;  /*  63 - 32 */
      uint32_t  ext3Idx;  /*  31 -  0 */
    } _PM_PACKED;
  } _PM_PACKED;
} _PM_PACKED _pm_ext_test_line_t;


/* This type defines the confirmation entry. */
typedef struct {
  _pm_head_test_line_t  headTestLine;
  _pm_ext_test_line_t   extTestLine;
  _pm_test_line_t       testLines[_PM_CONFIRMATION_ENTRY_TEST_LINES_NUM];
} _PM_PACKED _pm_confirmation_entry_t;









/*--------------------- Private Global Data Definitions -----------*/








/*--------------------- Function Declarations ---------------------*/







/*--------------------- Function Definitions ----------------------*/








#endif /* PM_DEFS_PRIV_H_INCLUDE */

