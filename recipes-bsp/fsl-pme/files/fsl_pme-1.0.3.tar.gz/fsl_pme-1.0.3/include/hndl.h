/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 * File Name : hndl.h
 *
 * This file defines the public interface to the HaNDLe (HNDL) module.
 * 
 * The HNDL module allows the user to create an association between
 * pointers to generic user-defined objects and abstract handles to
 * these objects.  Such associations are useful when the object
 * identifiers needs to be abstracted from the physical implementation
 * of the objects.  This concept is similar to the concept used for
 * file descriptors where the open() call returns an abstract file 
 * descriptor.
 *
 * Once an HNDL handle has been created for an object, the object can
 * be identified by that abstract handle rather then by a direct
 * pointer to the object.  
 * 
 * The user of the HNDL module must first initialize the HNLD module
 * with a call to the hndl_module_init() function and then create the
 * handle table with a call to the hndl_table_create() function.
 * The handle table will keep the pointer and handle associations for
 * all the objects.  The size of the table should correspond to the
 * number of the objects that will require a handles.  The handle
 * table can be configured to expand automatically but in the current
 * implementation the table never shrinks.  Once the handle table has
 * been created, the user can allocate new or free existing handles
 * and extract object pointers associated with the specified handles.
 *
 * Once the services offered by the HNDL module are not needed any
 * more the handle table can be destroyed with a call to the
 * hndl_table_destroy() function.
 *
 *****************************************************************************/
#ifndef HNDL_H_INCLUDE
#define HNDL_H_INCLUDE




/*--------------------- Include Files --------------------------------------*/

#include <generic_types.h>








/*--------------------- Macro Definitions-----------------------------------*/

/* This macro defines the abbreviated name for this module. */
#define HNDL_MODULE_NAME                      "HNDL"


/* This macro defines the NULL table ID. */
#define HNDL_NULL_TABLEID                     NULL


/* This macro defines the maximum size (including the NULL termination
 * character) of a HNDL name. */
#define HNDL_NAME_MAX_SIZE                     32







/*--------------------- Type Definitions------------------------------------*/

/* This type defines the different error codes that can be returned by
 * the functions in the HNDL module. */
typedef enum {
  /* HNDL: Operation successful. */
  hndl_ok_e                         =  0,

  /* HNDL: Operation failed. */
  hndl_error_e                      =  1,

  /* HNDL: Invalid HNDL handle. */
  hndl_invalid_handle_e             =  2,

  /* HNDL: Ran out of memory. */
  hndl_out_of_memory_e              =  3,

  /* HNDL: NULL pointer parameter. */
  hndl_null_ptr_parameter_e         =  4,

  /* HNDL: Internal error: more error codes than strings are defined. */
  hndl_too_few_error_strings_e      =  5,

  /* HNDL: Internal error: more error strings than codes are defined. */
  hndl_too_many_error_strings_e     =  6,

  /* HNDL: Handle table is full. */
  hndl_handle_table_full_e          =  7,

  /* HNDL: Zero initial table size is invalid. */
  hndl_zero_initial_table_size_e    =  8,

  hndl_last_error_code_e,
  hndl_ensure_this_enum_is_signed_e = -1  /* do not use! */
} hndl_status_t;


/* This type defines the ID of a handle table. */
typedef void *hndl_table_id_t;









/*--------------------- Private Global Data Definitions --------------------*/








/*--------------------- Function Declarations ------------------------------*/

/*
 * Returns an error string for the passed in error code.
 *
 * param errorCode Error code to use.
 * retval          Error string corresponding to the error code passed.
 */
const char *
hndl_error_string_get(
  hndl_status_t errorCode);


/*
 * Allocate a handle for the passed in object.
 *
 * param tableId   ID of the handle table to use.
 * param object_p  Pointer to the object to be associated with the
 *                 returned handle.
 * param handle_p  Pointer to an area where the allocated handle is to
 *                 be stored.
 * retval          hndl_ok_e upon success;  An error code otherwise.
 *                 When hndl_ok_e is returned the allocated handle is
 *                 returned through the handle_p parameter.
 */
hndl_status_t
hndl_handle_allocate(
  hndl_table_id_t  tableId,
  void            *object_p,
  unsigned int    *handle_p);


/*
 * Free a handle.
 *
 * param tableId  ID of the handle table to use.
 * param handle   Handle to free.
 */
void
hndl_handle_free(
  hndl_table_id_t  tableId,
  unsigned int     handle);


/*
 * Initializes the HNDL module.
 *
 * return value  hndl_ok_e upon success; an error code otherwise.
 */
hndl_status_t
hndl_module_init(void);


/*
 * Get the pointer to the object associated with the given handle.
 *
 * param tableId  ID of the handle table to use.
 * param handle   Handle to use.
 */
void *
hndl_object_from_handle_get(
  hndl_table_id_t  tableId,
  unsigned int     handle);


/* Creates a table of generic handles.
 *
 * param initialTableSize  The initial number of handles in the table.
 * param name_p            Name of the handle table.  The name cannot
 *                         be longer than HNDL_NAME_MAX_SIZE
 *                         (including the NULL terminating character).
 *                         When the name is longer than
 *                         (HNDL_NAME_MAX_SIZE - 1) than only the
 *                         first (HNDL_NAME_MAX_SIZE - 1) characters
 *                         of the name are used. 
 * param expandFlag        Flag indicating if the table can be expanded once
 *                         there are no handles available in the table.
 * param tableId_p         Pointer to an area where the ID of the created
 *                         handle table is to be stored. 
 * return value            hndl_ok_e upon success;  An error code
 *                         otherwise.  When hndl_ok_e is returned the ID of
 *                         the new table of handles is returned through the
 *                         tableId_p parameter. 
 */
hndl_status_t
hndl_table_create(
  const char      *name_p,
  uint32_t         initialTableSize,
  bool             expandFlag,
  hndl_table_id_t *tableId_p);


/* 
 * Destroys the indicated handle table.
 *
 * param tableId  ID of the handle table to destroy.
 */
hndl_status_t
hndl_table_destroy(
  hndl_table_id_t  tableId);


/*
 * Shows the entries in the indicated handle table.
 *
 * param tableId  Table ID of the handle table to use.
 */
void
hndl_table_entries_show(
  hndl_table_id_t  tableId);


/*
 * Shows the entries in the indicated main handle table structure.
 *
 * param tableId  ID of the handle table to use.
 */
void
hndl_table_show(
  hndl_table_id_t  tableId);









/*--------------------- Function Definitions -------------------------------*/








#endif /* HNDL_H_INCLUDE */

