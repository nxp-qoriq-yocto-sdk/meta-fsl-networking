/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __PMSRC_H__
#define __PMSRC_H__

#include <pm_defs.h>

#define PMSRC_DEFAULT_STRING_PAD 80
#define PMSRC_MAX_STRING_PAD_SIZE 16384

/* --------------------------------------------------------------------------
 * Define error codes.
 *
 * WARNING: Do not remove error codes.
 *          Do not change error code values.
 *          All new error codes must be added to end and enumerated correctly.
 * --------------------------------------------------------------------------*/
typedef enum
{
   /* 0  - Success                                          */
   pmsrc_ok_e                                          = 0,

   /* 1  - Warning                                          */
   pmsrc_warnings_e                                    = 1,

   /* 2  - Error opening input file                         */
   pmsrc_input_file_open_e                             = 2,

   /* 3  - Error opening output file                        */
   pmsrc_output_file_open_e                            = 3,

   /* 4  - No output file present                           */
   pmsrc_no_output_file_e                              = 4,

   /* 5  - Compile failed                                   */
   pmsrc_compile_failed_e                              = 5,

   /* 6  - Unexpected NULL list pointer passed to function  */
   pmsrc_null_list_pointer_e                           = 6,

   /* 7  - No output written to output file                 */
   pmsrc_no_output_written_e                           = 7,

   /* 8  - Internal error code strings do not match enum    */
   pmsrc_code_string_mismatch_e                        = 8,

   /* 9  - Undefined state name                             */
   pmsrc_undefined_state_name_e                        = 9,

   /* 10 - Duplicate state name                             */
   pmsrc_duplicate_state_name_e                        = 10,

   /* 11 - Internal error                                   */
   pmsrc_internal_error_e                              = 11,

   /* 12 - Malloc failure - system likely out of memory     */
   pmsrc_malloc_failure_e                              = 12,

   /* 13 - Stack function passed empty stack                */
   pmsrc_empty_stack_e                                 = 13,

   /* 14 - Name already in use                              */
   pmsrc_name_exists_e                                 = 14,

   /* 15 - Input file is empty                              */
   pmsrc_empty_input_e                                 = 15,

   /* 16 - Unrecognized debugging option                    */
   pmsrc_unrecognized_debug_option_e                   = 16,

   /* 17 - Unrecognized report pad option                   */
   pmsrc_unrecognized_report_pad_option_e              = 17,

   /* 18 - Unrecognized string pad option                   */
   pmsrc_unrecognized_string_pad_option_e              = 18,

   /* 19 - Invalid option                                   */
   pmsrc_invalid_option_e                              = 19,

   /* 20- String pad option too large                      */
   pmsrc_string_pad_option_too_large_e                 = 20,

   /* 21 - Unrecognized report constant size option         */
   pmsrc_unrecognized_report_constant_size_option_e    = 21,

   /* 22 - Unrecognized allow conclusive option             */
   pmsrc_unrecognized_allow_conclusive_option_e        = 22,

   /* Used for error detection. Do not number this one     * 
    * and leave it last.                                   */
   pmsrc_last_error_code_e               // DO NOT MOVE OR REMOVE THIS!
} pmsrc_error_codes_t;

/*
 * Debug levels for stateful rule compiler.
 * These levels are masks which may be OR'ed together
 * for more detailed logs.
 */
typedef enum
{
   pmsrc_debug_off_e          = 0x00000000,
   pmsrc_debug_summary_e      = 0x00000001, // Summary level of info
   pmsrc_debug_test_e         = 0x00000002, // Show test info
} pmsrc_debug_levels_t;

/*
 * Available report pad sizes.
 */
typedef enum
{
   pmsrc_report_pad_none_e = 0,  // No report padding
   pmsrc_report_pad4_e     = 4,  // Pad to 4 byte boundary
} pmsrc_report_pad_t;

/*
 * Available report constant sizes.
 * Constants given in reports will be padded up to this size.
 * Constants bigger than this size will have to be explictly padded
 * or an error will occur.
 */
typedef enum
{
   pmsrc_report_cnst_sz2_e = 0,  // Pad to 2 bytes
   pmsrc_report_cnst_sz4_e = 1,  // Pad to 4 bytes
   pmsrc_report_cnst_sz6_e = 2,  // Pad to 6 bytes
   pmsrc_report_cnst_sz8_e = 3,  // Pad to 8 bytes
} pmsrc_report_cnst_sz_t;

/*
 * Conclusive only OR conclusive and inconclusive matches allowed.
 */
typedef enum
{
   pmsrc_conclusive_only_matches_e             = 0,
   pmsrc_conclusive_and_inconclusive_matches_e = 1,
} pmsrc_match_type_t;

/*
 * A struct for module options.
 */
typedef struct pmsrc_module_options
{
   pmsrc_debug_levels_t   debug_level;         // Module debug level
   pmsrc_report_pad_t     report_pad;          // Align reports to this byte boundary. ex. 4 bytes
   uint32_t               string_pad;          // If no pad size is given for strings, use this.
   pmsrc_report_cnst_sz_t report_cnst_sz;      // Default size for contants in reports
   pmsrc_match_type_t     allow_inconclusive;  // Only match conclusive OR allow inconclusive matching as well
   bool                   warnings_are_errors; // Report warnings as errors.
   bool                   suppress_warnings;   // Suppress warning messages
} pmsrc_module_options_t;

/*
 * Compile a file of stateful rules.
 *
 * Parameters:
 *
 * input_file_name  - Full path to the file which contains the source
 *                    of the stateful rules to be compiled.
 *
 * output_file_name - Full path to where you want to store the compiled
 *                    stateful rule file.
 *
 * options_p        - Pointer to structure of options.
 *
 *                    Optional: Use NULL for default options.
 *
 * compile_msg_p    - Pointer to string for compile message.
 *
 *                    Optional: Use NULL for no string.
 *
 *                    NOTE    : You must free the string passed back if
 *                              it is non-NULL.
 *
 * Return:
 *
 *    A result code is returned (see pmsrc_error_codes_t above).
 */
pmsrc_error_codes_t pmsrc_compile (char                    *input_filename_p,
                                   char                    *output_filename_p,
                                   pmsrc_module_options_t  *options_p,
                                   char                   **compile_msg_p);

/*
 * Get the string associated with a stateful rule compiler error.
 *
 * Parameters:
 *
 * code - Error code of type pmsrc_error_codes_t.
 *
 * Return:
 *
 *   Pointer to a constant string containing the message.
 */
const char *pmsrc_get_error_string(pmsrc_error_codes_t code);

#endif /* __PMSRC_H__ */
