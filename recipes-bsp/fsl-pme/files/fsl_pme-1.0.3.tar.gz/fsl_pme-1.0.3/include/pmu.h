/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/************************************************************************
*   File Name : pmu.h
*
*   This file defines the public interface to the Pattern Matching
*   Utilities (PMU) module.
*
************************************************************************/
#ifndef PMU_H_INCLUDE
#define PMU_H_INCLUDE




/*--------------------- Include Files -----------------------------*/

#include <generic_types.h>






/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the abbreviated name for this module. */
#define PMU_MODULE_NAME                    "PMU"


/* The next few macros may be returned by some of the PMU functions. */
#define PMU_UNSUPPORTED_TABLE_ID            -1U
#define PMU_PLATFORM_SPECIFIC_TABLE_SIZE    -2U
#define PMU_MESSAGE_TYPE_IS_NOT_SUPPORTED   -3U









/*--------------------- Type Definitions---------------------------*/







/*--------------------- Private Global Data Definitions -----------*/








/*--------------------- Function Declarations ---------------------*/

char *
pmu_attribute_name_from_id_get(
  pmp_attribute_id_field_t  attributeId);


char *
pmu_msg_name_from_type_get(
  pmp_message_type_t  msgType);


uint32_t
pmu_msg_size_from_msg_type_get(
  pmp_message_type_t  msgType,
  pmp_table_id_t      tableID);


uint32_t
 pmu_table_max_index_get(
  pmp_table_id_t  tid);


char *
pmu_table_name_from_id_get(
  pmp_table_id_t  tableId);


uint32_t
pmu_table_entry_size_from_id_get(
  pmp_table_id_t  tableId);







/*--------------------- Function Definitions ----------------------*/






#endif /* PMU_H_INCLUDE */

