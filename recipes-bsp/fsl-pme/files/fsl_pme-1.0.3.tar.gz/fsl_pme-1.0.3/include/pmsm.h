/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __pmsm_h__
#define __pmsm_h__

/**********************************************************************
 * File:  pmsm.h
 *
 * Description:
 *   This file holds the Pattern Matching Statistics Manager API 
 *   delcaration.
 *
 * (c) COPYRIGHT 2005-Present Freescale Semiconductor Inc.
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <generic_types.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/un.h>

/**********************************************************************
 * Types
 **********************************************************************/

/* Connection socket address (sa must be of type struct sockaddr_un) */
#define PMSM_SOCK_FAMILY          AF_UNIX
#define PMSM_SOCK_PATH            "/tmp/pmsm.sock"
#define PMSM_SOCK_SET(sa, saLen)  {                                           \
                                      if ( (strlen(PMSM_SOCK_PATH) +          \
                                            sizeof(sa.sun_family)) > saLen ) {\
                                          sa.sun_family = AF_UNSPEC;          \
                                      } else {                                \
                                          sa.sun_family = PMSM_SOCK_FAMILY;   \
                                          strcpy(sa.sun_path, PMSM_SOCK_PATH);\
                                      }                                       \
                                  }

/* Command code supported by the statistics manager (bitmask that can be
 * ored together to perform multiple commands at once)
 */
#define PMSM_CMD_RESET            0x01
#define PMSM_CMD_QUERY            0x02

/* Group of statistics that can be queried and/or reset to on the statistics
 * manager.
 */
#define PMSM_GROUP_PM_KES         0x01
#define PMSM_GROUP_PM_DXE         0x02
#define PMSM_GROUP_PM_SRE         0x04
#define PMSM_GROUP_DEFLATE        0x08
/* Channel 0-3 (comment this out until driver supports these statistis) */
#ifdef PMSM_DRIVER_SUPPORT_CHANNEL_STATISTICS
#define PMSM_GROUP_CHANNEL0       0x10
#define PMSM_GROUP_CHANNEL1       0x20
#define PMSM_GROUP_CHANNEL2       0x40
#define PMSM_GROUP_CHANNEL3       0x80
#define PMSM_GROUP_CHANNEL(chan)  (((chan)<<4)&0xf0)
#define PMSM_GROUP_CHANNEL_ALL    ( PMSM_GROUP_CHANNEL0 |                     \
                                    PMSM_GROUP_CHANNEL1 |                     \
                                    PMSM_GROUP_CHANNEL2 |                     \
                                    PMSM_GROUP_CHANNEL3 )
#else
#define PMSM_GROUP_CHANNEL_ALL    0x00
#endif /* PMSM_DRIVER_SUPPORT_CHANNEL_STATISTICS */
#define PMSM_GROUP_PM_ALL         ( PMSM_GROUP_PM_KES |                       \
                                    PMSM_GROUP_PM_DXE |                       \
                                    PMSM_GROUP_PM_SRE )
#define PMSM_GROUP_ALL            ( PMSM_GROUP_PM_ALL |                       \
                                    PMSM_GROUP_DEFLATE |                      \
                                    PMSM_GROUP_CHANNEL_ALL )

/* Note that the statistics manager stores the statisitics attribute in
 * the upstream in the same order listed above using the structures below.
 * For example, if the PMSM_GROUP_ALL group code is used, then the application
 * can find the statistics in the following order:
 * 
 */

/* Statistics structures (Structures are in network order; use ntohll macro) */

/* KES */
typedef struct
{
    uint64_t inputByte;          /* # of input bytes fed to KES block */
    uint64_t inputSui;           /* # of input SUI fed to KES block */
    uint64_t triggerOneByteHit;  /* # of 1B trigger hit in KES block */
    uint64_t triggerTwoByteHit;  /* # of short trigger hit in KES block */
    uint64_t triggerVariableHit; /* # of variable trigger hit in KES block */
    uint64_t triggerSpecialHit;  /* # of special trigger hit in KES block */
    uint64_t confidenceHit;      /* # of confidence hit in KES block */
} PmsmKesStats_t;

/* DXE */
typedef struct
{
    uint64_t patternMatch;       /* Number of patterns matched in DXE block */
    uint64_t suiMatch;           /* Number of SUI with one or more matches */
    uint64_t matchWithinDrcc;    /* Number of patterns matched within DRCC */
} PmsmDxeStats_t;

/* SRE */
typedef struct
{
    uint64_t dxeWithSrExecution; /* Number of SR executions caused by DXE */
    uint64_t suiWithSrExecution; /* Number of SR executions caused by SUI */
    uint64_t suiWithSrReport;    /* Number of SUI generating rule reports */
    uint64_t reportByte;         /* Number of bytes generated in SR reports */
} PmsmSreStats_t;

/* Deflate */
typedef struct
{
    uint64_t consumedByte;       /* Number of bytes consumed by Deflate */
    uint64_t producedByte;       /* Number of bytes produced by Deflate */
    uint64_t consumedWorkUnit;   /* Number of work units consumed by Deflate */
} PmsmDeflateStats_t;

/* Channel 0-3 (comment this out until driver supports these statistis) */
#ifdef PMSM_DRIVER_SUPPORT_CHANNEL_STATISTICS
typedef struct
{
    uint64_t truncation;         /* Number of notifications truncated by DMA */
    uint64_t readByte;           /* Number of bytes read by DMA */
    uint32_t fbHighWatermark;    /* High level watermark of free buffer pool */
    uint32_t fbLowWatermark;     /* Low level watermark of free buffer pool */
    uint32_t fbNumAllocation;    /* Number of free buffer allocation */
    uint32_t fbNumDeallocation;  /* Number of free buffer deallocation */
    uint32_t fbNumBuffer;        /* Current number of free buffers */
} PmsmChannelStats_t;
#endif /* PMSM_DRIVER_SUPPORT_CHANNEL_STATISTICS */

#endif /* __pmsm_h__ */
