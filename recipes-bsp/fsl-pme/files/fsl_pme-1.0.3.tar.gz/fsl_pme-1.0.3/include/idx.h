/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : idx.h
 *
 *   This file defines the public interface to the InDeX (IDX)
 *   management module.
 *
 ****************************************************************************/
#ifndef IDX_H_INCLUDE
#define IDX_H_INCLUDE




/*--------------------- Include Files -----------------------------*/

#include <inttypes.h>


#include <generic_types.h>





/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the abbreviated name for this module. */
#define IDX_MODULE_NAME                     "IDX"


/* This macro defines the NULL index value. */
#define IDX_NULL_INDEX                      -1U


/* This macro defines the maximum size (including the NULL termination
 * character) of an IDX name. */
#define IDX_NAME_MAX_SIZE                   32








/*--------------------- Type Definitions---------------------------*/

// This type defines the different error codes that can be returned by
// the functions in the IDX module.
typedef enum {
  /* "IDX: Operation successful." */
  idx_ok_e                          =  0,

  /* "IDX: Operation failed." */
  idx_error_e                       =  1,

  /* "IDX: Invalid IDX handle." */
  idx_invalid_idx_handle_e          =  2,

  /* "IDX: More error codes than strings are defined." */
  idx_too_few_error_strings_e       =  3,

  /* "IDX: More error strings than codes are defined." */
  idx_too_many_error_strings_e      =  4,

  /* "IDX: Invalid maximum index." */
  idx_invalid_max_index_e           =  5,

  /* "IDX: Ran out of memory." */
  idx_out_of_memory_e               =  6,

  /* "IDX: NULL pointer parameter." */
  idx_null_ptr_parameter_e          =  7,

  /* "IDX: Index table is full." */
  idx_idx_table_is_full_e           =  8,


  idx_last_error_code_e,
  idx_ensure_this_enum_is_signed_e  = -1  /* do not use! */
} idx_status_t;


/* This type defines the IDX table statistics. */
typedef struct {
  char      name_s[IDX_NAME_MAX_SIZE]; /* table name */
  uint32_t  idxMaxNum;                 /* max. number of entries in table */
  uint32_t  allocatedIdxNum;           /* # of currently allocated indexes */
  uint32_t  availableIdxNum;           /* # of currently available indexes */
} idx_stats_t;






/*--------------------- Private Global Data Definitions -----------*/








/*--------------------- Function Declarations ---------------------*/

/*
 * Retrieve the number of the currently allocated indexes in the table.
 *
 * param handle  Handle to the index table to use.
 * retval        The number of currently allocated indexes on
 *               success;  IDX_NULL_INDEX on failure.
 */
uint32_t
idx_allocated_idx_num_get(
  handle_t  handle);


/*
 * Return error string for the passed in error code.
 *
 * param errorCode  Error code to use.
 * retval           Error string corresponding to the error code passed.
 */
const char *
idx_error_string_get(
  idx_status_t  errorCode);


/*
 * Free all the indexes in the specified table.
 *
 * param handle  Handle to the index table to use.
 */
void
idx_index_all_free(
  handle_t  handle);


/*
 * Allocate a new index.
 *
 * param handle  Handle to the index table to use.
 * retval        A positive integer on success; IDX_NULL_INDEX on
 *               failure.
 */
uint32_t
idx_index_allocate(
  handle_t  handle);


/*
 * Mark the indicated index as allocated.
 *
 * param handle  Handle to the index table to use.
 * param idx     The index to mark as allocated.
 */
void
idx_index_allocated_set(
  handle_t  handle,
  uint32_t  idx);


/*
 * Allocate a block of consecutive indexes.
 *
 * param handle          Handle to the index table to use.
 * param blockSize       Number of the consecutive indexes to be allocated.
 * param alignedToValue  If different than 0, then the returned index
 *                       is aligned to this value.  For example with
 *                       a block size of 8 and the alignedToValue 16,
 *                       the returned index will be a multiple of 16.
 * retval                A positive integer indicating the first of the
 *                       indexes in the allocated block on success;
 *                       IDX_NULL_INDEX on failure. 
 */
uint32_t
idx_index_block_allocate(
  handle_t  handle,
  uint32_t  blockSize,
  uint32_t  alignedToValue);


/*
 * Free a block of consequtive indexes.
 *
 * param handle     Handle to the index table to use.
 * param startIdx   The first index in the block.
 * param blockSize  Size of the block of indexes to be freed.
 */
void
idx_index_block_free(
  handle_t  handle,
  uint32_t  startIdx,
  uint32_t  blockSize);


/*
 * Free an index.
 *
 * param handle  Handle to the index table to use.
 * param idx     The index to free.
 */
void
idx_index_free(
  handle_t  handle,
  uint32_t  idx);


/*
 * Get the next allocated index.
 *
 * NOTE: Passing the IDX_NULL_INDEX will result in returning the
 *       smallest allocated index.
 *
 * param handle  Handle of the IDX table to use.
 * param idx     The search for the next allocated index is started
 *               from this passed in index.
 * retval        Next (with respect to the passed in index) allocated
 *               index if such an index exists; IDX_NULL_INDEX if
 *               such an index does not exist.
 */
uint32_t
idx_index_next_allocated_get(
  handle_t  handle,
  uint32_t  idx);


/*
 * Create a new index table.
 * 
 * param indexMaxNum  Maximum index value in the table to be created.
 *                    The indexes range from 1 to indexMaxNum.
 * param name_p       Pointer to table name string.
 * param handle_p     Pointer to where the handle of the created
 *                    index tabel should be stored.
 * retval             idx_ok_e on success; and error code otherwise.
 *                    When idx_ok_e is returned the handle of the
 *                    newly created index table is stored in handle_p.
 */
idx_status_t
idx_index_table_create(
  uint32_t    indexMaxNum,
  const char *name_p,
  handle_t   *handle_p);


/*
 * Destroy an index table.
 *
 * param handle  Handle to the index table to destroy.
 * retval        idx_ok_e on success, an error code otherwise.
 */
idx_status_t
idx_index_table_destroy(
  handle_t  handle);


/*
 * Show the entries in the index table.
 *
 * param handle  Handle to the index table to use.
 */
void
idx_index_table_entries_show(
  handle_t  handle);


/*
 * Show the entries in the main index table structure.
 *
 * param handle  Handle to the index table to use.
 */
void
idx_index_table_show(
  handle_t  handle);


/*
 * Check if the passed handle is valid.
 *
 * param handle  Handle to the index table to check.
 * retval        true if the handle is valid; false if the handle is
 *               not valid or upon an error.                
 */
bool
idx_is_handle_valid(
  handle_t  handle);


/*
 * Check if the passed index is allocated.
 *
 * param handle  Handle to the index table to use.
 * param idx     The index to check.
 * retval        true if the index is allocated or upon an error;
 *               false otherwise.
 */
bool
idx_is_index_allocated(
  handle_t  handle,
  uint32_t  idx);


/*
 * Check if the passed index is valid.
 *
 * param handle  Handle to the index table to use.
 * param idx     The index to check.
 * retval        true if the index is valid; false if the index is
 *               not valid or upon an error.
 *                
 */
bool
idx_is_index_valid(
  handle_t  handle,
  uint32_t  idx);


/*
 * Retrieve the number of the entries in the table.
 *
 * param handle  Handle to the index table to use.
 * retval        The number of entries in the table on success;
 *               IDX_NULL_INDEX on failure.
 */
uint32_t
idx_max_idx_num_get(
  handle_t  handle);


/*
 * Initialize the IDX module.
 *
 * retval  idx_ok_e upon success; an error code otherwise.
 */
idx_status_t
idx_module_init(void);


/*
 * Get the statistics for the indicated index table.
 *
 * param handle      Handle to the index table to use.
 * param idxStats_p  Pointer to area where the retrieved index table
 *                   statistics are to be stored.
 * retval            idx_ok_e on success, an error code otherwise.  When
 *                   idx_ok_e is returned then the valied index table
 *                   statistics are returned through the idxStats_p
 *                   variable. 
 */
idx_status_t
idx_stats_get(
  handle_t     handle,
  idx_stats_t *idxStats_p);










/*--------------------- Function Definitions ----------------------*/








#endif /* IDX_H_INCLUDE */

