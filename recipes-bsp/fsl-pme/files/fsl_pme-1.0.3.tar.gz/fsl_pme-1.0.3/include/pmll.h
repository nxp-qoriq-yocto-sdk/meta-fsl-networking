/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/************************************************************************
 *   File Name : pmll.h
 *
 *   This file defines the public interface to the Pattern Matching
 *   Linker Loader (PMLL) module.
 *
 ************************************************************************/
#ifndef PMLL_H_INCLUDE
#define PMLL_H_INCLUDE




/*--------------------- Include Files ----------------------------------*/

#include <generic_types.h>
#include <pm_defs.h>
#include <pmp.h>








/*--------------------- Macro Definitions-------------------------------*/

/* This macro defines the abbreviated name for this module. */
#define PMLL_MODULE_NAME                       "PMLL"


/* This macro defines the numeric version of the PMLL API. */
#define PMLL_API_VERSION                       0x00010000


/* This macro defines the maximum length of the version string. */
#define PMLL_VERSION_STR_LENGTH                16


/* This macro defines the maximum number of rules supported by PMLL. */
#define PMLL_RULE_MAX_NUM                      16000


/* This macro defines the NULL (expression or rule) index value. */
#define PMLL_NULL_INDEX                        -1U


/* The next two macros define the PMLL expression and rule record
 * versions supported by PMLL. */
#define PMLL_EXP_RECORD_V_1_0_1                0x00010001  
#define PMLL_RULE_RECORD_V_1_0_0               0x00010000  










/*--------------------- Type Definitions--------------------------------*/

/* This type defines the different error codes that can be returned by
 * the PMLL functions. */
typedef enum {
  /* Generic success code. */
  pmll_ok_e                                     =  0, 

  /* Generic error code. */
  pmll_error_e                                  =  1,

  /* Too few error strings are defined. */
  pmll_too_few_error_strings_e                  =  2,

  /* Too many error strings are defined. */
  pmll_too_many_error_strings_e                 =  3, 

  /* Unsupported record version was passed in. */
  pmll_unsupported_record_version_e             =  4, 

  /* NULL pointer passed in. */
  pmll_null_pointer_parameter_e                 =  5, 

  /* Memory allocation failed. */
  pmll_out_of_memory_e                          =  6, 

  /* Name length is 0 or too long. */
  pmll_invalid_name_e                           =  7, 

  /* Expression name is already in use. */
  pmll_exp_name_is_in_use_e                     =  8, 

  /* Expression is not in the name table. */
  pmll_exp_is_not_in_name_db_e                  =  9,

  /* Trigger type could not be determ. */
  pmll_no_trigger_type_e                        = 10, 

  /* Unsupported trigger type. */
  pmll_unsupported_trigger_type_e               = 11,

  /* Row format definition table is too small. */
  pmll_too_few_trig_row_format_defs_e           = 12, 

  /* Row format definition table is too big. */
  pmll_too_many_trig_row_format_defs_e          = 13, 

  /* Failed to commit a pattern. */
  pmll_failed_to_commit_pattern_e               = 14, 

  /* PM H/W entry write failed. */
  pmll_entry_write_failed_e                     = 15, 

  /* Unexpected confirmation record size. */
  pmll_bad_confirmation_rec_size_e              = 16, 

  pmll_module_not_initialized_e                 = 17, 
  /* module has not been initialized. */

  /* Unexpected size of the trigger record. */
  pmll_bad_trigger_rec_size_e                   = 18, 

  /* Parameter has an invalid value. */
  pmll_invalid_parameter_value_e                = 19, 

  /* Too many one-byte patterns. */
  pmll_too_many_one_byte_patterns_e             = 20, 

  /* Too many two-byte patterns. */
  pmll_too_many_two_byte_patterns_e             = 21, 

  /* Too many variable patterns. */
  pmll_too_many_variable_patterns_e             = 22, 

  /* Too many special patterns. */
  pmll_too_many_special_patterns_e              = 23, 

  /* Too many  patterns. */
  pmll_too_many_patterns_e                      = 24, 

  /* Invalid pattern DB handle. */
  pmll_invalid_db_handle_e                      = 25, 

  /* Table index value is too big. */
  pmll_table_index_too_big_e                    = 26, 

  /* Pattern not in the confidence table. */
  pmll_pattern_not_in_confid_table_e            = 27, 

  /* Bad logic. */
  pmll_bad_logic_e                              = 28, 

  /* Too many reactions in a rule. */
  pmll_too_many_reactions_in_rule_e             = 29, 

  /* There are no reactions in rule. */
  pmll_no_reactions_in_rule_e                   = 30, 

  /* Size of a reaction is too big. */
  pmll_reaction_too_big_e                       = 31, 

  /* NULL reaction pointer in rule. */
  pmll_null_reaction_pointer_in_rule_e          = 32, 

  /* Rule name is already in use. */
  pmll_rule_name_is_in_use_e                    = 33, 

  /* Too many rules. */
  pmll_too_many_rules_e                         = 34, 

  /* Rule is not in the name table. */
  pmll_rule_is_not_in_name_db_e                 = 35, 

  /* Expression is used in a rule(s). */
  pmll_exp_is_used_in_rule_e                    = 36, 

  /* Failed to initialize a mutex. */
  pmll_failed_to_init_mutex_e                   = 37, 

  /* Failed to destroy a mutex. */
  pmll_failed_to_destroy_mutex_e                = 38, 

  /* No more records are defined. */
  pmll_no_more_records_e                        = 39, 

  /* Failed to create a name DB. */
  pmll_failed_to_create_name_db_e               = 40, 

  /* Failed to add an expression to a name DB. */
  pmll_failed_to_add_exp_to_name_db_e           = 41, 

  /* Failed to add a rule to a name DB. */
  pmll_failed_to_add_rule_to_name_db_e          = 42, 

  /* Index is not in use. */
  pmll_index_is_not_in_use_e                    = 43, 

  /* Failed to create a reset table. */
  pmll_failed_to_create_reset_table_e           = 44, 

  /* Failed to create a block table. */
  pmll_failed_to_create_block_table_e           = 45, 

  /* Failed to create a CLI menu. */
  pmll_failed_to_create_cli_menu_e              = 46, 

  /* Failed to register a CLI command. */
  pmll_failed_to_register_cli_command_e         = 47, 

  /* Too few confirmation blocks. */
  pmll_too_few_confirmation_blocks_e            = 48, 

  /* Ran out of extension blocks. */
  pmll_out_of_extension_blocks_e                = 49, 

  /* Failed to create the rule ID table. */
  pmll_failed_to_create_rule_id_table_e         = 50, 

  /* Run out of rule IDs. */
  pmll_out_of_rule_ids_e                        = 51, 

  /* Size of a reaction is too small. */
  pmll_reaction_too_small_e                     = 52, 

  /* Reaction instructions are misaligned. */
  pmll_misaligned_reaction_e                    = 53, 

  /* Failed to create rule ctx table. */
  pmll_failed_to_create_rule_ctx_table_e        = 54, 

  /* Session context area is too small. */
  pmll_session_ctx_area_too_small_e             = 55, 

  /* Cannot allocate a rule context area. */
  pmll_failed_to_alloc_rule_ctx_area_e          = 56, 

  /* Variable trigger size is out of range. */
  pmll_vtrigger_size_out_of_range_e             = 57, 

  /* Expressions are present in the LL DB. */
  pmll_exps_are_present_in_db_e                 = 58, 

  /* Unsupported reaction event type. */
  pmll_bad_reaction_event_type_e                = 59, 

  /* Session context area has bad size. */
  pmll_bad_session_ctx_area_size_e              = 60, 

  /* Failed to reset a table. */
  pmll_table_reset_failed_e                     = 61, 

  /* Failed to initialize the PMHI module. */
  pmll_pmhi_init_failed_e                       = 62, 

  /* Failed to set the atomic attribute. */
  pmll_failed_to_set_atomic_attr_e              = 63, 

  /* Failed to set the variable trigger size attribute. */
  pmll_failed_to_set_vtrig_size_attr_e          = 64, 

  /* Failed to set the end of SUI attribute. */
  pmll_failed_to_set_end_of_sui_attr_e          = 65, 

  /* Flush operation failed. */
  pmll_flush_failed_e                           = 66, 

  /* Failed to reset rule context(s). */
  pmll_failed_to_reset_rule_ctxs_e              = 67, 

  /* Failed to set the batch attribute. */
  pmll_failed_to_set_batch_attr_e               = 68, 

  /* PMLA channel is down. */
  pmll_pmla_channel_is_down_e                   = 69, 

  /* PMLA channel is not set. */
  pmll_pmla_channel_is_not_set_e                = 70, 

  /* Failed to create the handle table. */
  pmll_handle_table_create_failure_e            = 71, 

  /* Failed to destroy the handle table. */
  pmll_handle_table_destroy_failure_e           = 72, 

  /* Failed to allocate PMLL DB handle. */
  pmll_failed_to_allocate_handle_e              = 73, 

  /* Requested too many stateful rules. */
  pmll_too_many_stateful_rules_req_e            = 74, 

  /* Cannot register a null function. */
  pmll_cannot_register_null_pmla_func_e         = 75, 

  /* Failed to extract the rule type. */
  pmll_failed_to_extract_rule_type_e            = 76,

  /* Unexpected key element size. */
  pmll_unexpected_key_element_size_e            = 77,

  /* Unsupported confidence mask type. */
  pmll_unsupported_confidence_mask_type_e       = 78,

  /* Unsupported confidence mask alignment. */
  pmll_unsupported_confidence_mask_alignment_e  = 79,

  /* Key element data cannot be used with the specified anchored
   * confidence mask. */ 
  pmll_bad_key_element_data_for_anchor_mask_e   = 80,

  /* PMLL module is already initialized. */
  pmll_module_already_initialized_e             = 81,



  pmll_last_error_code_e,

  /* Do not use this entry!. */
  pmll_ensure_this_enum_is_signed_e             = -1  

} pmll_status_t;


/* This type defines statistics that can be read from LL. */
typedef struct {  
  /* DXE/SRE table statistics. ----------------------------------------------*/
  /* The total number of the DXE/SRE entries present in the DXE/SRE
   * table, i.e., this is the DXE/SRE table size.  This value is
   * specified in a call to the pmll_db_create() function. */ 
  uint32_t  dxeSreEntryNum;

  /* The number of the base entries in the DXE/SRE table.  For a given
   * release of PMLL this number is constant.  This number is also the
   * minimum size of the DXE/SRE table. */
  uint32_t  dxeSreBaseEntryNum;
  
  /* The number of the DXE/SRE extension entries, i.e., the number of
   * the "non-base" entries in the DXE/SRE table. */
   uint32_t  dxeSreExtensionEntryNum;

  /* The number of the currently allocated extension entries. */ 
  uint32_t  dxeSreAllocatedExtensionEntryNum;

  /* The number of the currently available extension entries. */
  uint32_t  dxeSreAvailableExtensionEntryNum;


  /* SRE session statistics. ------------------------------------------------*/
  /* The number of the SRE sessions.  This value is specified in a
   * call to the pmll_db_create() function. */
  uint32_t  sreSessionCtxNum;

  /* The size (in bytes) of each of the SRE sessions.  This value is
   * specified in a call to the pmll_db_create() function. */
  uint32_t  sreSessionCtxSize;

  /* The size (in bytes) of the session digest area.  This value
   * depends on the number of SRE rules as specified by the user in
   * a call to the pmll_db_create() function. */
  uint32_t  sreSessionDigestSize;

  /* The size (in bytes) of the session flags area.  This value is
   * constant for a given release of PMLL. */
  uint32_t  sreSessionFlagsSize;

  /* The size (in bytes) of the session context areas. */
  uint32_t  sreSessionCtxAreaSize;

  /* The size (in bytes) of the currently allocated session context areas. */
  uint32_t  sreAllocatedSessionCtxAreaSize;

  /* The size (in bytes) of the currently available session context areas. */
  uint32_t  sreAvailableSessionCtxAreaSize;
  

  /* Expression and pattern statistics. -------------------------------------*/
  /* The maximum number of patterns that can be configured.  This value is
   * constant for a given release of PMLL. */
  uint32_t patternMaxNum;
  
  /* The number of the currently configured expressions. */
  uint32_t  expNum;

  /* The number of the currently configured "special" patterns. */
  uint32_t  specialPatternNum;

  /* The number of the currently configured "one-byte" patterns. */
  uint32_t  oneBytePatternNum;

  /* The number of the currently configured "two-byte" patterns. */
  uint32_t  twoBytePatternNum;

  /* The number of the currently configured "variable" patterns. */
  uint32_t  variablePatternNum;

  /* The total number of the currently configured patterns. */
  uint32_t  totalPatternNum;

  /* The currently configured variable trigger size. */
  uint32_t  variableTriggerSize;


  /* Rule and reaction statistics. ------------------------------------------*/
  /* The maximum number of stateful rules.  This value is specified in
   * a call to the pmll_db_create() function. */
  uint32_t  statefulRuleMaxNum;

  /* The maximum number of stateless rules.  This value is constant
   * for a given release of PMLL. */
  uint32_t  statelessRuleMaxNum;

  /* The maximum number of all rules.  This value is constant for a
   * given release of PMLL. */
  uint32_t  totalRuleMaxNum;

  /* The number of the currently configured stateless rules. */
  uint32_t  statelessRuleNum;

  /* The number of the currently configured stateful rules. */
  uint32_t  statefulRuleNum;

  /* The number of the currently configured rules. */
  uint32_t  totalRuleNum;

  /* The number of the currently configured end-of-SUI reactions. */
  uint32_t  endOfSuiReactionNum;  
} pmll_stats_t;


/* The next few types define the signature of the user-definable PMLA
 * functions. */
typedef int pmll_pmla_bulk_begin_function_t     (handle_t pmlaHandle);
typedef int pmll_pmla_bulk_end_function_t       (handle_t pmlaHandle);
typedef int pmll_pmla_flush_function_t          (handle_t pmlaHandle);
typedef int pmll_pmla_read_function_t           (handle_t   pmlaHandle,
                                                 pmp_msg_t *msg_p);
typedef int pmll_pmla_write_function_t          (handle_t pmlaHandle,
                                                 pmp_msg_t *msg_p);
typedef const char *pmll_pmla_error_string_get_t(int errorCode);


/* This type defines the pointers to the user-definable PMLA functions. */
typedef struct {              
  pmll_pmla_bulk_begin_function_t *pmlaBulkBeginFunction_p;
  pmll_pmla_bulk_end_function_t   *pmlaBulkEndFunction_p;
  pmll_pmla_flush_function_t      *pmlaFlushFunction_p;
  pmll_pmla_read_function_t       *pmlaReadFunction_p;
  pmll_pmla_write_function_t      *pmlaWriteFunction_p;
  pmll_pmla_error_string_get_t    *pmlaErrorStringGetFunction_p;
} pmll_pmla_functions_t;


/* This type defines the parameters used while creating the PMLL DB. */
typedef struct {
  pmll_pmla_functions_t             pmlaFunctions;
  pmp_extension_block_num_attr_t    dxeSreTableSize;
  pmp_context_area_size_attr_t      sreSessionCtxSize;
  pmp_context_max_num_attr_t        sreSessionCtxNum;
  pmp_max_stateful_rule_num_attr_t  sreRuleNum;
} pmll_db_params_t;




  




/*--------------------- Private Global Data Definitions ---------------*/








/*--------------------- Function Declarations -------------------------*/

/*
 * Retrieve the version of the "running" PMLL API.
 *
 * This function can be used to retrieve the numeric value of the
 * PMLL API version
 *
 * retval  The version of the "running" PMLL API.
 */
uint32_t
pmll_api_version_get(void);


/* 
 * Commit the changes in the PMLL DB to the PM H/W.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param expName_p     Pointer to an area where an expression name can
 *                     be stored.  This area must be at least
 *                     PM_NAME_MAX_LENGTH bytes long.
 * retval              pmll_ok_e upon success; an error code
 *                     otherwise.  When the pmll_failed_to_commit_pattern_e
 *                     error code is returned, the name of the expression
 *                     that contained the pattern that caused the
 *                     failure is stored in the expName_p area.
 */
pmll_status_t
pmll_commit(
  unsigned int  pmllDbHandle,
  char         *expName_p);


/*
 * Get the PMLA connection handle for the specified PMLL shadow DB.
 *
 * Given a PMLL DB handle the function returns the PMLA handle
 * that is currently used by the PMLL shadow DB with the indicated
 * PMLL DB handle.  
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param pmlaHandle_p  Pointer to where the returned value of the PMLA
 *                     connection handle is to be stored.
 * retval              pmll_ok_e upon success; an error code
 *                     otherwise.  When pmll_ok_e is returned, the
 *                     pmlaHandle_p points to the retrieved PMLA handle.
 */
pmll_status_t
pmll_connection_handle_get(
  unsigned int  pmllDbHandle,
  handle_t     *pmlaHandle_p);


/*
 * Set the PMLA connection handle for the specified PMLL shadow DB.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param pmlaHandle    New value of the PMLA connection handle.
 * retval              pmll_ok_e upon success; an error code otherwise.
 */
pmll_status_t
pmll_connection_handle_set(
  unsigned int  pmllDbHandle,
  handle_t      pmlaHandle);


/*
 * Create and initialize a new PMLL DB.
 *
 * param pmllDbParams_p        Parmeters of the PMLL DB to be
 *                             created.  dxeSreTableSize defines the
 *                             size of the confirmation table.
 *                             sessionContextSize is the total size
 *                             (in bytes) of the session context
 *                             table.  sreSessionCtxNum is the number
 *                             of the available sessions.  sreRuleNum
 *                             is the maximum number of the stateful
 *                             rules.  
 * param pmllDbHandle_p        Pointer to an area where the DB handle
 *                             of the newly created DB is stored.
 * retval                      pmll_ok_e upon success; an error code
 *                             otherwise.  Upon success the handle of
 *                             the created PMLL DB is returned through
 *                             the pmllDbHandle_p parameter.  This
 *                             handle must be used in all the
 *                             subsequent calls that use the PMLL DB. 
 */
pmll_status_t
pmll_db_create(
  pmll_db_params_t *pmllDbParams_p,
  unsigned int     *pmllDbHandle_p);


/*
 * Destroy (deallocate) the indicated PMLL DB.
 *
 * param pmllDbHandle  Handle of the PMLL DB to destroy.
 * retval              pmll_ok_e upon success; an error code otherwise.
 */
pmll_status_t
pmll_db_destroy(
  unsigned int  pmllDbHandle);


/*
 * Initialize the PMLL debug sub-module.
 *
 * NOTE:  The PMLL debug sub-module is used internally and for
 *        debugging purposes only.  The debug sub-module is normally
 *        disabled and as such it is not available during normal
 *        operation of PMLL.  With the debug module disabled the
 *        invocation of this function has no meaning.
 *
 * param menuHandle  Handle of the menu in which the PMLL debug sub-menu
 *                   should be created.
 * param llDbHandle  Pointer to the handle of the LL DB.
 * retval            pmll_ok_e upon success; an error code otherwise.
 */
pmll_status_t
pmll_debug_init(
  handle_t      menuHandle,
  unsigned int *llDbHandle_p);


/*
 * Get a copy of the currently used equivalence table.
 *
 * param pmllDbHandle         Handle of the PMLL DB to use.
 * param equivalenceTable_p   Pointer to the first byte of an area
 *                            where a copy of the currently used
 *                            equivalence table is to be stored.  This
 *                            area must be at least
 *                            PMP_EQUIVALENCE_ENTRY_SIZE bytes long.
 * retval                     pmll_ok_e upon success; an error code
 *                            otherwise.  When pmll_ok_e is returned,
 *                            a copy of the currently used equivalence
 *                            table is stored in the area pointed to by
 *                            the equivalenceTable_p parameter.
 */
pmll_status_t
pmll_equivalence_table_get(
  unsigned int  pmllDbHandle,
  uint8_t      *equivalenceTable_p);


/*
 * Set new values in the equivalence table.
 *
 * NOTE: This function will fail if it is invoked when there are
 *       patterns defined in the PMLL DB.
 *
 * param pmllDbHandle         Handle of the PMLL DB to use.
 * param equivalenceTable_p   Pointer to the first byte of the
 *                            equivalence table containing the new
 *                            values to be used.  Note that the 
 *                            equivalence table should be
 *                            PMP_EQUIVALENCE_ENTRY_SIZE bytes long.
 * retval                     pmll_ok_e upon success; an error code
 *                            otherwise. 
 */
pmll_status_t
pmll_equivalence_table_set(
  unsigned int    pmllDbHandle,
  const uint8_t  *equivalenceTable_p);


/*
 * Given an error code the function returns the corresponding error string.
 *
 * param errorCode Error code to use.
 * retval          Error string corresponding to the error code
 *                 passed.  Note, that the returned error string must
 *                 not be altered.
 */
const char *
pmll_error_string_get(
  pmll_status_t  errorCode);


/* 
 * Add an expression to the PMLL DB.
 *
 * param pmllDbHandle      Handle of the PMLL DB to use.
 * param recordVersion     Version of the PMLL exp record passed in.
 * param genPmExpRecord_p  Generic PMLL expression record containing
 *                         the data of the expression to be added. 
 * param index_p           Pointer to an area where the index identifying
 *                         this added expression is to be stored.
 * retval                  pmll_ok_e upon success; an error code otherwise. 
 *                         When pmll_ok_e is returned, the index
 *                         associated with the newly added expression is
 *                         returned through the index_p parameter.  This
 *                         index can be used as a parameter to functions
 *                         that operate on expressions.
 */
pmll_status_t
pmll_exp_add(
  unsigned int           pmllDbHandle,
  uint32_t               recordVersion,
  const pm_exp_record_t *genPmExpRecord_p,
  uint32_t              *index_p);


/*
 * Delete all the expressions stored in the PMLL DB.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * retval              pmll_ok_e upon success; an error code otherwise. 
 */
pmll_status_t
pmll_exp_all_delete(
  unsigned int  pmllDbHandle);


/*
 * Delete the expression identified by the passed in index.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param idx           Index of the expression to be deleted.
 * retval              pmll_ok_e upon success; an error code otherwise. 
 */
pmll_status_t
pmll_exp_delete(
  unsigned int  pmllDbHandle,
  uint32_t  idx);


/*
 * Get the next valid expression index.
 *
 * This function can be used to "walk" through all the expressions in
 * the PMLL DB.  To get the first valid expression index in the PMLL
 * DB the idx parameter must be set to the PMLL_NULL_INDEX value.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param idx           The index to start the search for the next valid
 *                     expression. 
 * param nextIndex_p   Pointer to an area where the index of the next
 *                     valid expression is to be stored.
 * retval              pmll_ok_e upon success; an error code otherwise. 
 *                     When pmll_ok_e is returned, the area pointed to
 *                     by the nextIndex_p parameter contains the index
 *                     of the next valid expression in the PMLL DB.
 *                     pmll_no_more_records_e is returned when there are
 *                     no valid expression records with index values
 *                     greater than the passed in index value.
 */
pmll_status_t
pmll_exp_index_next_get(
  unsigned int  pmllDbHandle,
  uint32_t      idx,
  uint32_t     *nextIndex_p);


/*
 * Check if there exists an expression with the passed in name.
 *
 * param pmllDbHandle   Handle of the PMLL DB to use.
 * param name_p         The name to check.
 * param nameIsInUse_p  An area where the flag indicating whether an
 *                      expression with the specified name exists or
 *                      not is to be stored.
 * param index_p        An area where the index of the expression with
 *                      the specified name is to be stored.  
 * retval               pmll_ok_e upon success; an error code otherwise. 
 *                      When pmll_ok_e is returned the nameIsInUse_p
 *                      flag is set true if an expression with the
 *                      specified name exists or false if such an
 *                      expression does not exist.  When pmll_ok_e is
 *                      returned and the nameIsInUse_p flag is set to
 *                      true then the index associated with the expression
 *                      is returned through the index_p parameter (if it
 *                      is not NULL).
 */
pmll_status_t
pmll_exp_name_in_use(
  unsigned int  pmllDbHandle,
  const char   *name_p,
  bool         *nameIsInUse_p,
  uint32_t     *index_p);


/* 
 * Initialize the PMLL module.
 *
 * This function must be called before any other of the PMLL functions
 * are invoked.  The function can be invoked more than once but the
 * second and subsequent invocations do not have any effect on the
 * PMLL module.
 *
 * param initialDbHandleNum     This is the initial number of PMLL DB
 *                              handles that are to be created during
 *                              the PMLL module initialization time.
 * param expandDbHandleNumFlag  If set to true then the number of the
 *                              available PMLL DB handles is going to
 *                              expanded beyond the initialDbHandleNum
 *                              of handles when PMLL runs out of
 *                              available handles.  If set to false
 *                              then no new handles are added to the
 *                              handle pool.
 * retval  pmll_ok_e upon success; an error code otherwise.
 */
pmll_status_t
pmll_module_init(
  unsigned int  initialDbHandleNum,
  bool          expandDbHandleNumFlag);


/* 
 * Shuts down the PMLL module.
 *
 * This function can be called to destroy the global resources used by
 * the PMLL module.  At present the function destroys a handle table
 * that is used to maintain the PMLL DB handles.
 *
 * retval  pmll_ok_e upon success; an error code otherwise.
 */
pmll_status_t
pmll_module_shutdown(void);


/*
 * Retrieve the user-definable PMLA function pointers.
 *
 * param pmllDbHandle   Handle of the PMLL DB to use.
 * param functions_p    Location of where to store the retrieved PMLA
 *                      function pointers.
 * retval               pmll_ok_e upon success; an error code otherwise. 
 */
pmll_status_t
pmll_pmla_functions_get(
  unsigned int           pmllDbHandle,
  pmll_pmla_functions_t *functions_p);


/*
 * Set the PMLA functions.
 *
 * param pmllDbHandle   Handle of the PMLL DB to use.
 * param functions_p    Structure with pointers to all the
 *                      user-defined PMLA function.
 * retval               pmll_ok_e upon success; an error code otherwise. 
 */
pmll_status_t
pmll_pmla_functions_set(
  unsigned int          pmllDbHandle,
  pmll_pmla_functions_t *functions_p);


/* 
 * Add a rule to the PMLL DB.
 *
 * param pmllDbHandle       Handle of the PMLL DB to use.
 * param recordVersion      Version of the rule record.
 * param genPmRuleRecord_p  Record containing the data of the rule to
 *                          be added.  
 * param index_p            Pointer to an area where the index identifying
 *                          this added rule is to be stored.
 * retval                   pmll_ok_e upon success; an error code otherwise. 
 *                          When pmll_ok_e is returned, the index
 *                          associated with the newly added rule is
 *                          returned through the index_p parameter.  This 
 *                          index can be used as a parameter to functions
 *                          that operate on rules.
 */
pmll_status_t
pmll_rule_add(
  unsigned int            pmllDbHandle,
  uint32_t                recordVersion,
  const pm_rule_record_t *genPmRuleRecord_p,
  uint32_t               *index_p);


/*
 * Delete all the rules stored in the PMLL DB.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * retval              pmll_ok_e upon success; an error code otherwise. 
 */
pmll_status_t
pmll_rule_all_delete(
  unsigned int  pmllDbHandle);


/*
 * Delete the rule identified by the passed in index.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param idx           Index of the rule to be deleted.
 * retval              pmll_ok_e upon success; an error code otherwise. 
 */
pmll_status_t
pmll_rule_delete(
  unsigned int  pmllDbHandle,
  uint32_t      idx);


/*
 * Get the next valid rule index.
 *
 * This function can be used to "walk" through all the rules in the
 * PMLL DB.  To get the first valid rule index in the PMLL DB the idx 
 * parameter must be set to the PMLL_NULL_INDEX value.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param idx           The index to start the search for the next valid
 *                     rule.
 * param nextIndex_p   Pointer to an area where the index of the next
 *                    valid rule is to be stored.
 * retval             pmll_ok_e upon success; an error code otherwise. 
 *                    When pmll_ok_e is returned, the area pointed to
 *                    by the nextIndex_p parameter contains the index
 *                    of the next valid rule in the PMLL DB.
 *                    pmll_no_more_records_e is returned when there are
 *                    no valid rule records with index values greater
 *                    than the passed in index value.
 */
pmll_status_t
pmll_rule_index_next_get(
  unsigned int  pmllDbHandle,
  uint32_t      idx,
  uint32_t     *nextIndex_p);


/*
 * Check if there exists a rule with the passed in name.
 *
 * param pmllDbHandle   Handle of the PMLL DB to use.
 * param name_p         The name to check.
 * param nameIsInUse_p  An area where the flag indicating whether a
 *                      rule with the specified name exists or
 *                      not is to be stored.
 * param index_p        An area where the index of the rule with the
 *                      specified name is to be stored. 
 * retval               pmll_ok_e upon success; an error code otherwise. 
 *                      When pmll_ok_e is returned the nameIsInUse_p
 *                      flag is set true if a rule with the specified
 *                      name exists or false if such a rule does not
 *                      exist.  When pmll_ok_e is returned and the
 *                      nameIsInUse_p flag is set to true then the
 *                      index associated with the rule is returned
 *                      through the index_p parameter (if it is not NULL). 
 */
pmll_status_t
pmll_rule_name_in_use(
  unsigned int  pmllDbHandle,
  const char   *name_p,
  bool         *nameIsInUse_p,
  uint32_t     *index_p);


/*
 * Retrieve the PMLL statistics.
 *
 * param pmllDbHandle  Handle of the PMLL DB to use.
 * param llStats_p     Area where the PMLL statistics are to be stored.
 * retval              pmll_ok_e upon success; an error code otherwise. 
 *                     When pmll_ok_e is returned the retrieved PMLL
 *                     statistics are stored in the area pointed to by
 *                     the llStats_p parameter.
 */
pmll_status_t
pmll_stats_get(
  unsigned int  pmllDbHandle,
  pmll_stats_t *llStats_p);


/*
 * Retrieve the supported expression record versions.
 * 
 * NOTE:  This function is intended to be used together with the
 *        pmll_supported_exp_record_versions_num_get() function which can be
 *        used to determine the number of the supported versions and
 *        hence the size of the area pointed to by the versionTable_p
 *        parameter, or equivalently the value of the tableSize parameter.
 *
 * param versionTable_p  Pointer to an area where the supported
 *                       version numbers are to be stored.  It must
 *                       point to at least tableSize uint32_t entries.
 * param tableSize       Number of available entries in the passed in
 *                       version table (versionTable_p).  See the NOTE
 *                       above.
 * retval                pmll_ok_e upon success; an error code otherwise. 
 *                       When pmll_ok_e is returned, the entries in
 *                       the version table contain the supported
 *                       version numbers.  Unused entries in the table
 *                       are set to 0.
 */
pmll_status_t
pmll_supported_exp_record_versions_get(
  uint32_t *versionTable_p,
  uint32_t  tableSize);


/*
 * Retrieve the number of the supported expression record versions.
 *
 * NOTE:  his function is intended to be used with the
 *        pmll_supported_exp_record_versions_get() function.
 *
 * retval  The number of the supported expression record versions.
 */
uint32_t
pmll_supported_exp_record_versions_num_get(void);


/*
 * Retrieve the supported rule record versions.
 *
 * NOTE:  This function is intended to be used together with the
 *        pmll_supported_rule_record_versions_num_get() function which can be
 *        used to determine the number of the supported versions and
 *        hence the size of the area pointed to by the versionTable_p
 *        parameter, or equivalently the value of the tableSize parameter.
 *
 * param versionTable_p  Pointer to an area where the supported
 *                       version numbers are to be stored.  It must
 *                       point to at least tableSize uint32_t entries.
 * param tableSize       Number of available entries in the passed in
 *                       version table (versionTable_p).  See the NOTE
 *                       above.
 * retval                pmll_ok_e upon success; an error code otherwise. 
 *                       When pmll_ok_e is returned, the entries in
 *                       the version table contain the supported
 *                       version numbers.  Unused entries in the table
 *                       are set to 0.
 */
pmll_status_t
pmll_supported_rule_record_versions_get(
  uint32_t *versionTable_p,
  uint32_t  tableSize);


/*
 * Retrieve the number of the supported rule record versions.
 *
 * NOTE: This function is intended to be used with the
 *       pmll_supported_rule_record_versions_get() function.
 *
 * retval  The number of the supported rule record versions.
 */
uint32_t
pmll_supported_rule_record_versions_num_get(void);


/*
 * Get the size of the variable trigger.
 *
 * param pmllDbHandle           Handle of the PMLL DB to use.
 * param variableTriggerSize_p  Pointer to an area where the retrieved
 *                              size of the variable trigger is to be
 *                              stored. 
 * retval                       pmll_ok_e upon success; an error code
 *                              otherwise.  When pmll_ok_e is returned
 *                              the retrieved trigger size is returned
 *                              through the variableTriggerSize_p parameter.
 */
pmll_status_t
pmll_variable_trigger_size_get(
  unsigned int  pmllDbHandle,
  uint32_t     *variableTriggerSize_p);


/*
 * Set the size of the variable trigger.
 *
 * NOTE: An attempt to change the variable trigger size will fail if
 *       it is made wheen there are patterns defined in the PMLL DB.
 *
 * param pmllDbHandle         Handle of the PMLL DB to use.
 * param variableTriggerSize  Size to set the variable trigger to.
 * retval                     pmll_ok_e upon success; an error code
 *                            otherwise. 
 */
pmll_status_t
pmll_variable_trigger_size_set(
  unsigned int  pmllDbHandle,
  uint32_t      variableTriggerSize);


/*
 * Return a string corresponding to the passed in numeric version value.
 *
 * param version       The numeric version value to use.
 * param versionStr_p  An area where the version string is to be
 *                     stored.  The size of the area must be at least
 *                     PMLL_VERSION_STR_LENGTH bytes long.
 * retval              Pointer to the passed in version string area
 *                     (versionStr_p). 
 */
char *
pmll_version_str_get(
  uint32_t  version,
  char     *versionStr_p);









/*--------------------- Function Definitions --------------------------*/








#endif /* PMLL_H_INCLUDE */

