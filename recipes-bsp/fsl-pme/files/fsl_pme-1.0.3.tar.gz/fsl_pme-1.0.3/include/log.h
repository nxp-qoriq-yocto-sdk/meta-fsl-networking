/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : log.h
 *
 * This file defines the public interface to the logging (log) module.
 *
 ****************************************************************************/
#ifndef LOG_H_INCLUDE
#define LOG_H_INCLUDE



/**********************************************************************
 * Include Files
 **********************************************************************/

#include <libgen.h>
#include <stdio.h>
#include <generic_types.h>
#include <sys/time.h>






/**********************************************************************
 * Macro Definitions
 **********************************************************************/

/* This macro defines the abbreviated name for this module. */
#define LOG_MODULE_NAME             "LOG"


/* The next few macros define the ouput streams to be used with the
 * LOG printing function. */
#define LOG_STDOUT                  stdout
#define LOG_STDERR                  stderr


/* The next few macros define the log levels (or log masks) and the
 * strings associated with each log level. */
#define LOG_ERROR                   0x00000001
#define LOG_ERROR_STR               "ERROR"
#define LOG_WARNING                 0x00000002
#define LOG_WARNING_STR             "WARNING"

#define LOG_INFO                    0x00000004
#define LOG_INFO_STR                "INFO"
#define LOG_TEST                    0x00000008
#define LOG_TEST_STR                "TEST"
#define LOG_MUTEX                   0x00000010
#define LOG_MUTEX_STR               "MUTEX"
#define LOG_MEMORY                  0x00000020
#define LOG_MEMORY_STR              "MEMORY"

#define LOG_TMP                     0x80000000
#define LOG_TMP_STR                 "TMP"
#define LOG_ALL                     0xffffffff
#define LOG_ALL_STR                 "ALL"

/* The next few macros define the log verbosity levels (masks) */
#define LOG_VERBOSITY_DATE          0x00000001
#define LOG_VERBOSITY_FILE          0x00000002
#define LOG_VERBOSITY_LNUM          0x00000004
#define LOG_VERBOSITY_FUNC          0x00000008
#define LOG_VERBOSITY_PREFIX        0x00000010
#define LOG_VERBOSITY_LOGLVL        0x00000020
#define LOG_VERBOSITY_MULTILINE     0x00000040

#define LOG_VERBOSE_FULL            0xffffffff
#define LOG_VERBOSE_CLEAN           0x00000000

/* This macro should be used for generating string logs. */
#define LOG_STRING(level, prefix, format, ...)            \
  do {                                                    \
    log_string_log((level), __FILE__, __LINE__, __func__, \
                   prefix, format, ##__VA_ARGS__);        \
  } while (0)

/* This macro should be used to log content of memory. */
#define LOG_MEMORY_DUMP(level, prefix, memAddr, memLength)      \
  do {                                                          \
    log_memory_log((level), prefix, memAddr, memLength, true);  \
  } while (0)







/**********************************************************************
 * Type Definitions
 **********************************************************************/

/* This type defines the log level. */
typedef  uint32_t log_log_Level_t;

/* This type defines the log verbosity mask. */
typedef  uint32_t log_verbosity_t;


/* Function callback type used to get time of day. */
typedef int (* log_get_time_of_day_t)(struct timeval *tv, struct timezone *tz);





/**********************************************************************
 * Function Declarations
 **********************************************************************/

/**********************************************************************
 * Description:
 *    Generic log function.
 *
 * Parameters:
 *    logLevel        - Log level of the log to be generated.
 *    fileName_p      - Name of the file the log was generated from.
 *    lineNum         - Line number in the file the log was generated from. 
 *    functionName_p  - Name of the function the log was generated from.
 *    prefix_p        - Module prefix.
 *    format_p        - Format to use.
 *    ...             - Parameters to be used while printing.
 *
 * Return:
 *    Nothing.
 **********************************************************************/
void 
log_string_log(
  log_log_Level_t  logLevel,
  const char      *fileName_p,
  uint32_t         lineNum, 
  const char      *functionName_p,
  const char      *prefix_p, 
  const char      *format_p, 
  ...) __attribute__((format(printf, 6, 7)));  /* 6=format 7=params */


/**********************************************************************
 * Description:
 *    Dump the content of memory to the logs
 *
 * Parameters:
 *    logLevel   - Log level to use when dumping.
 *    prefix_p   - Module prefix
 *    addr_p     - Pointer to the memory to dump
 *    length     - Number of bytes to dump
 *    showString - Determine if the memory should also be dumped in ASCII
 *
 * Return:
 *    Nothing.
 **********************************************************************/
void 
log_memory_log(
  log_log_Level_t  logLevel,
  const char      *prefix_p,
  const void      *addr_p,
  int              length, 
  bool             showString);


/**********************************************************************
 * Description:
 *    Checks if the passed log level is enabled or not.
 *
 * Parameters:
 *    logLevel - Log level to check.
 *
 * Return:
 *    true if the passed log level is enabled, false otherwise.
 **********************************************************************/
bool 
log_is_log_level_enabled(
  log_log_Level_t  logLevel);


/**********************************************************************
 * Description:
 *    Sets the log mask to enable or disable the indicated log level.
 *
 * Parameters:
 *    logLevel        - The log level to be set.
 *    value           - The new mask bit for the log level;  true turns
 *                      the logs on and false turns them off. 
 *
 * Return:
 *    Nothing.
 **********************************************************************/
void 
log_level_set(
  log_log_Level_t  logLevel, 
  bool             value);


/**********************************************************************
 * Description:
 *    Retrieve the current log mask.
 *
 * Parameters:
 *    None.
 *
 * Return:
 *    Bit mask representing the log level currently set.
 **********************************************************************/
log_log_Level_t 
log_mask_get(void);


/**********************************************************************
 * Description:
 *    Set the new log mask.
 *
 * Parameters:
 *    newLogMask - New bit mask to use for log mask.
 *
 * Return:
 *    Nothing.
 **********************************************************************/
void 
log_mask_set(
  log_log_Level_t  newLogMask);


/**********************************************************************
 * Description:
 *    Generic print function.
 *
 * Parameters:
 *    logHandle       - Output device handle.
 *    format_p        - Format for printing.
 *    ...             - Parameters to be used while printing.
 *
 * Return:
 *    Whatever is returned by the vfprintf() function.
 **********************************************************************/
int 
log_printf(
  handle_t    logHandle, 
  const char *format_p, 
  ...) __attribute__((format(printf, 2, 3)));  /* 2=format 3=params */


/**********************************************************************
 * Description:
 *    Set the handel of the device the data is logged to.
 *
 * Parameters:
 *    logHandle       - Output device handle.
 *
 * Return:
 *    N/A
 **********************************************************************/
void 
log_handle_set(
  handle_t logHandle);


/**********************************************************************
 * Description:
 *    Get the handle of the device the data is logged to.
 *
 * Parameters:
 *    N/A
 *
 * Return:
 *    The value of the currently set default handle.
 **********************************************************************/
handle_t 
log_handle_get(void);


/**********************************************************************
 * Description:
 *    Set the logging handle to point to the specified file.
 *
 * Parameters:
 *    fileName_p      - Name of the file to log to.
 *
 * Return:
 *    Handle of the file to log to.
 **********************************************************************/
handle_t 
log_log_to_file(
  char *fileName_p);


/**********************************************************************
 * Description:
 *    Set an alternate function for getting time of day for logging the time.
 *    This is done by specifying a callback function for the clock source.
 *
 * Parameters:
 *    func - Pointer to the function that gets time of day.
 *
 * Return:
 *    Nothing.
 **********************************************************************/
void 
log_clock_source_set(
  log_get_time_of_day_t  func);


/**********************************************************************
 * Description:
 *    Get the current function that is getting time of day for logging.
 *
 * Parameters:
 *    None.
 *
 * Return:
 *    Handle of the file to log to.
 **********************************************************************/
log_get_time_of_day_t 
log_clock_source_get(void);


/**********************************************************************
 * Description:
 *    Get the log verbosity mask.
 *
 * Parameters:
 *    None.
 *
 * Return:
 *    Log verbosity mask.
 **********************************************************************/
log_verbosity_t 
log_verbosity_mask_get(void);

/**********************************************************************
 * Description:
 *    Set the log verbosity mask.
 *    Use macros defined in log.h.
 *
 *    Examples:
 *      log_verbosity_mask_set(LOG_VERBOSITY_DATE | LOG_VERBOSITY_FILE);
 *      log_verbosity_mask_set(LOG_VERBOSE_CLEAN);
 *      log_verbosity_mask_set(LOG_VERBOSE_FULL);
 *
 * Parameters:
 *    None.
 *
 * Return:
 *    Log verbosity mask.
 **********************************************************************/
void 
log_verbosity_mask_set(log_verbosity_t mask);






/**********************************************************************
 * Inline Function Definitions
 **********************************************************************/











#endif /* LOG_H_INCLUDE */

