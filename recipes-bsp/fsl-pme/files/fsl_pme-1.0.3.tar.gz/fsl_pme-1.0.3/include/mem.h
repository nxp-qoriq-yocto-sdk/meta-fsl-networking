/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : mem.h
 *
 *   This file defines the public interface to the MEMory (MEM)
 *   management module. 
 *
 ****************************************************************************/
#ifndef MEM_H_INCLUDE
#define MEM_H_INCLUDE




/*--------------------- Include Files -----------------------------*/

#include <stdlib.h>



#include <generic_types.h>





/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the abbreviated name for this module. */
#define MEM_MODULE_NAME                      "MEM"


/* If overall debug mode is set to on, then turn on the MEM debug
 * functionality. */
#ifdef DEV_DBG
#  define MEM_DEBUG_ENABLED
#endif
 






/*--------------------- Type Definitions---------------------------*/







/*--------------------- Private Global Data Definitions -----------*/








/*--------------------- Function Declarations ---------------------*/

/* @brief Allocate and zero an array of bytes in memory.
 *
 * @param nmemb    Number of elements in the array of bytes to be
 *                 allocated. 
 * @param size     Size of each of the elements.
 * @param retval   Pointer to the allocated memory on success; NULL upon
 *                 a failure.
 */
void *
mem_calloc(
  size_t  nmemb, 
  size_t  size);


/* 
 * @brief Free a previously allocated array of bytes in memory.
 *
 * @param pointer_p  Pointer to the previously allocated memory array
 *                   to be freed.
 */
void
mem_free(
  void *pointer_p);


/* @brief Allocate a number of bytes in memory.
 *
 * @param size     Number of bytes to be allocated.
 * @param retval   Pointer to the allocated memory on success; NULL upon
 *                 a failure.
 */
void *
mem_malloc(
  size_t  size);


/*
 * @brief Dump the indicated memory region.
 *
 * @param logHandle           Logging handle; where to send the output.
 * @param buffer_p            Where to start the dump.
 * @param size                How many bytes to dump.
 * @param lineSize            Number of bytes printed in a single line.
 * @param lineHeaderFlag      If true the line header, i.e., the memory
 *                            address is printed.
 * @param lineHeaderInHexFlag If true the line header is printed as a
 *                            hexadecimal value; otherwise the header
 *                            is printed as a decimal value. 
 * @param lineHeaderOffset_p  Offset to be subtracted from the address
 *                            printed as the line header.
 * @param lineFooterFlag      If true the character representations of the
 *                            bytes in a printed line are printed at the
 *                            end of each line. 
 */
void
mem_memory_dump(
  handle_t    logHandle,
  const void *buffer_p,
  uint32_t    size,
  uint32_t    lineSize,
  bool        lineHeaderFlag,
  bool        lineHeaderInHexFlag,
  const void *lineHeaderOffset_p,
  bool        lineFooterFlag);


/* 
 * @brief Show the currently allocated memory blocks.

 * @param logHandle           Logging handle; where to send the output.
 * @param headerStr_p         Header string to be displayed before the
 *                            allocated memory blocks.
 */
void
mem_show(
  handle_t  logHandle,
  char     *headerStr_p);










/*--------------------- Function Definitions ----------------------*/








#endif /* MEM_H_INCLUDE */

