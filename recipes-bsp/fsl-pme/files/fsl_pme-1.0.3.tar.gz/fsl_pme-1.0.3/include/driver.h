/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/

/* 
 * Include the corect driver header for user code.
 */

#ifdef __i386__
#include <fsl_pme_local.h>
#elif defined(PLATFORM_8572_ds_git)
#include <fsl_pme_local.h>
#else
#include <freescale/pm_base_device.h>
#include <freescale/pm_scanner.h>
#include <freescale/pm_database.h>
#endif
