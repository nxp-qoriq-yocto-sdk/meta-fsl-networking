/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmApps.h
 *
 * Description:
 *   This file defines the definitions shared among all Pattern Matching 
 *   applications.
 *
 **********************************************************************/
#ifndef PM_APPS_H_INCLUDE
#define PM_APPS_H_INCLUDE



/**********************************************************************
 * Include Files
 **********************************************************************/

#include <log.h>







/**********************************************************************
 * Macro Definitions
 **********************************************************************/

/* The next few macros define the common option names. */
#define PMAPP_CmdArgLongHelp_d             "--help"
#define PMAPP_CmdArgShortHelp_d            "-h"
#define PMAPP_CmdArgLongLogLevel_d         "--log-level"
#define PMAPP_CmdArgLongLogFile_d          "--log-file"
#define PMAPP_CmdArgShortLogFile_d         "-l"


/* This macro defines the default log level. */
#define PMAPP_DefaultLogLevel_d (LOG_ERROR | LOG_WARNING)






/**********************************************************************
 * Type Definitions
 **********************************************************************/






/**********************************************************************
 * Private Global Data Definitions
 **********************************************************************/






/**********************************************************************
 * Function Declarations
 **********************************************************************/







/**********************************************************************
 * Function Definitions
 **********************************************************************/






#endif /* PM_APPS_H_INCLUDE */
