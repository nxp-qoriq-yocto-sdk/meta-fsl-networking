/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __PMREC_H__
#define __PMREC_H__

#include <pm_defs.h>

/* --------------------------------------------------------------------------
 * Define error codes.
 *
 * WARNING: Do not remove error codes.
 *          Do not change error code values.
 *          All new error codes must be added to end and enumerated correctly.
 * --------------------------------------------------------------------------*/
typedef enum
{
   /* 0 - Success                                     */
   pmrec_ok_e                                    = 0,

   /* 1 - Warning                                     */
   pmrec_warnings_e                              = 1,

   /* 2 - Internal error                              */
   pmrec_internal_error_e                        = 2,

   /* 3 - No trigger found                            */
   pmrec_no_trigger_found_e                      = 3,

   /* 4 - Internal error, missing end block           */
   pmrec_missing_end_block_e                     = 4,

   /* 5 - Internal error, missing end class           */
   pmrec_missing_end_class_e                     = 5,

   /* 6 - No output file supplied                     */
   pmrec_no_output_file_e                        = 6,

   /* 7 - Nested repeat found                         */
   pmrec_nested_repeat_found_e                   = 7,

   /* 8 - Expression too large                        */
   pmrec_expression_too_large_e                  = 8,

   /* 9 - Nested capture found                        */
   pmrec_nested_capture_found_e                  = 9,

   /* 10 - Compile failed                             */
   pmrec_compile_failed_e                        = 10,

   /* 11 - Error opening input file                   */
   pmrec_input_file_open_error_e                 = 11,

   /* 12 - Internal error, invalid element size       */
   pmrec_invalid_element_size_e                  = 12,

   /* 13 - Error opening output file                  */
   pmrec_output_file_open_error_e                = 13,

   /* 14 - Error writing to output file               */
   pmrec_output_file_write_error_e               = 14,

   /* 15 - Invalid group filename                     */
   pmrec_invalid_group_filename_e                = 15,

   /* 16 - Invalid group file                         */
   pmrec_invalid_group_file_e                    = 16,

   /* 17 - Error opening group file                   */
   pmrec_group_file_open_error_e                 = 17,

   /* 18 - Max test lines exceeded                    */
   pmrec_max_test_lines_exceeded_e               = 18,

   /* 19 - No start position found                    */
   pmrec_no_start_position_found_e               = 19,

   /* 20 - Internal error, code string mismatch       */
   pmrec_code_string_mismatch_e                  = 20,

   /* 21 - Grouped duplication found, must expand     */
   pmrec_must_expand_grouped_duplication_e       = 21,

   /* 22 - Memory allocation failure                  */
   pmrec_malloc_failure_e                        = 22,

   /* 23 - Invalid option                             */
   pmrec_invalid_option_e                        = 23,

   /* 24 - Invalid group definition                   */
   pmrec_invalid_group_def_e                     = 24,

   /* 25 - Invalid equivalence definition             */
   pmrec_invalid_equiv_def_e                     = 25,

   /* 26 - Syntax error                               */
   pmrec_syntax_error_e                          = 26,

   /* Used for error detection. Do not number this one     * 
    * and leave it last.                                   */
   pmrec_last_error_code_e               /* DO NOT MOVE OR REMOVE THIS! */
} pmrec_error_codes_t;

/*
 * Debug levels
 */
typedef enum
{
   pmrec_debug_none_e         = 0x00000000,  /* Used to initialize debug level to none */
   pmrec_debug_summary_e      = 0x00000001,  /* Summary level of info */
   pmrec_debug_detailed_e     = 0x00000002,  /* Show detailed debug info */
   pmrec_debug_test_e         = 0x00000004   /* Show test info */

} pmrec_debug_levels_t;

/*
 * Character group definitions
 */
typedef enum
{
   pmrec_groups_default0_e = 0,
} pmrec_group_definition_t;

/*
 * Character equivalence definitions
 */
typedef enum
{
   pmrec_equivalence_default0_e = 0,
} pmrec_equivalence_definition_t;

/*
 * Compile options.
 *
 * debug_level            - If debugging is enabled (through configure)
 *                          then set the debug level to this value.
 *
 * group_definition       - The hardware groups various ascii characters
 *                          together into groups so that the test lines
 *                          (binary format) will be more efficient.
 *                          Future compiler versions may allow user 
 *                          definitions of these groups. For now use
 *                          'pmrec_groups_default0_e'.
 *
 * group_def_filename_p   - For future use with group_definition option.
 *
 * equivalence_definition - The hardware defines certain pairs of ascii
 *                          characters to be equivalent (for case 
 *                          insensitivity).  Future compile versions may
 *                          allow user definitions of this equivalence.
 *                          For now use 'pmrec_equivalence_default0_e'.
 *
 * equiv_def_filename_p   - For future use with equivalence_definition option.
 *
 * warnings_are_errors    - Any warnings found will result in a compile error.
 *
 * suppress_warnings      - Suppress reporting of warnings. Note that if the
 *                          option 'warnings_are_errors' is turned on, this
 *                          option will be ignored and warnings reported.
 *
 * hide_strings           - Do not include the expression/option strings in
 *                          the output binary file. Useful if distributing
 *                          binary files and you want to hide the original
 *                          expressions.
 *
 */
typedef struct pmrec_module_options
{
   pmrec_debug_levels_t            debug_level;
   pmrec_group_definition_t        group_definition;
   char                           *group_def_filename_p; // For future use - Set to NULL
   pmrec_equivalence_definition_t  equivalence_definition;
   char                           *equiv_def_filename_p; // For future use - Set to NULL
   bool                            warnings_are_errors;
   bool                            suppress_warnings;
   bool                            hide_strings;
   bool                            one_byte_triggers;
   bool                            silicon_8572_rev_1_0;
} pmrec_module_options_t;

/* =========================================================================
 *
 *                               Public APIs
 *
 * =========================================================================*/

/****************************************************************************
 * Compile a regular expression.
 *
 * Description:  Compile regular expression(s) into hardware instructions.
 *
 * Parameters:
 *   input_file_name_p  - String containing file name of input file
 *
 *   output_file_name_p - String containing file name of output file
 *
 *   options_p          - Pointer to structure of options.
 *
 *                        Optional: Use NULL for default options.
 *
 *   compile_msg_p       - Pointer to string for compile message.
 *
 *                        Optional: Use NULL for no string.
 *
 *                        NOTE    : You must free the string passed back if
 *                                  it is non-NULL.
 *
 * Returns:
 *    Error code of type pmrec_error_codes_t is returned.
 ****************************************************************************/
pmrec_error_codes_t pmrec_compile (char                    *input_file_name_p,
                                   char                    *output_file_name_p,
                                   pmrec_module_options_t  *options_p,
                                   char                   **compile_msg_p);

/****************************************************************************
 * Get the string associated with a compiler error.
 *
 * Description:  Gets the message string associated with the given error code.
 *
 * Parameters:
 *   code  - Error code of type pmrec_error_codes_t
 *
 * Returns:
 *    Pointer to a constant string containing the message.
 ****************************************************************************/
const char *pmrec_get_error_string(pmrec_error_codes_t code);

#endif /* __PMREC_H__ */
