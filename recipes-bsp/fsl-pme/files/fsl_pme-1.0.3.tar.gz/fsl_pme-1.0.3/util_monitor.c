/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"

static int usage(int verbose, int retval)
{
	fprintf(stderr, "%smonitor [options] < ctrl | channel <n> >\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose) {
		fprintf(stderr, "%s  Polls until an error is encountered, or "
			"clears (CC) errors if -r is used\n", USAGE_CLEAR);
		fprintf(stderr, "%s    -r              (clear asserted bits - "
			"only for 'ctrl')\n", USAGE_CLEAR);
		fprintf(stderr, "%s    -t <msecs>      (default 0 uses "
			"no timeout, -1 uses no blocking)\n", USAGE_CLEAR);
		fprintf(stderr, "%s    -m <mask>       (default 0 assumes no "
			"previous errors)\n", USAGE_CLEAR);
		return 0;
	}
	return retval;
}

static int miss_param(const char *s)
{
	fprintf(stderr, "ERROR, missing parameter for %s\n", s);
	return usage(1, -1);
}

static int unknown_param(const char *s)
{
	fprintf(stderr, "ERROR, unknown parameter %s\n", s);
	return usage(1, -1);
}

int monitor(int argc, char *argv[])
{
	uint32_t mask = 0, channel = 0;
	int fd, err, reset = 0, timeout = 0;
	enum {
		dev_none,
		dev_ctrl,
		dev_channel
	} d = dev_none;
	/* Rather than cleanly ascertaining the current reset counter for the
	 * channel, we use some seed value that is (almost) certainly wrong.
	 * The first ioctl will return with a changed counter, we move to that,
	 * and restart the same ioctl. */
	uint32_t uid = (uint32_t)-1;
	struct pme_channel_monitor p = {
		.reset_counter = uid
	};
	char fdpath[256];
#define ARGINC	{argc--;argv++;}

	if(argc < 0) return usage(1, 0);
	ARGINC;
	while(argc) {
		if(!strcmp(*argv, "-r"))
			reset = 1;
		else if(!strcmp(*argv, "-t")) {
			if(argc < 2) return miss_param("-t");
			ARGINC;
			if(parse_int(*argv, &timeout, "-t"))
				return usage(1, -1);
		} else if(!strcmp(*argv, "-m")) {
			if(argc < 2) return miss_param("-m");
			ARGINC;
			if(parse_uint(*argv, &mask, "-m"))
				return usage(1, -1);
		} else if(!strcmp(*argv, "ctrl")) {
			if(argc > 1) {
				fprintf(stderr, "ERROR, trailing arguments\n");
				return usage(1, -1);
			}
			d = dev_ctrl;
		} else if(!strcmp(*argv, "channel")) {
			if(argc < 2) return miss_param("channel #");
			if(argc > 2) {
				fprintf(stderr, "ERROR, trailing arguments\n");
				return usage(1, -1);
			}
			ARGINC;
			if(parse_uint(*argv, &channel, "channel #"))
				return usage(1, -1);
			d = dev_channel;
		} else
			return unknown_param(*argv);
		ARGINC;
	}
	if(d == dev_none)
		return miss_param("<device>");
	if(d == dev_ctrl)
		sprintf(fdpath, PME_CTRL_PATH);
	else {
		if(reset) {
			fprintf(stderr, "ERROR, '-r' is not valid on channel "
					"devices\n");
			return usage(1, -1);
		}
		sprintf(fdpath, PME_CHANNEL_PATH, channel);
	}
	fd = open(fdpath, O_RDONLY);
	if(fd < 0) {
		perror("opening monitor device failed");
		return -1;
	}
	if(reset) {
		p.monitor.clear_mask = ~(uint32_t)0;
		p.monitor.disable_mask = 0;
		p.monitor.block = 0;
	} else {
		p.monitor.ignore_mask = mask;
		p.monitor.clear_mask = 0;
		p.monitor.disable_mask = 0;
		p.monitor.block = ((timeout < 0) ? 0 : 1);
		p.monitor.timeout_ms = timeout;
	}
	if(d == dev_ctrl)
		err = ioctl(fd, PME_CTRL_IOCTL_MONITOR, &p.monitor);
	else {
		/* Do the ioctl first with uid==-1 to find the current reset
		 * counter, then a secont time using that uid. */
		if(!(err = ioctl(fd, PME_CHANNEL_IOCTL_MONITOR, &p))) {
			uid = p.reset_counter;
			err = ioctl(fd, PME_CHANNEL_IOCTL_MONITOR, &p);
		}
	}
	if(err < 0) {
		perror("Monitor ioctl");
		return -1;
	}
	if(err)
		printf("timeout\n");
	else {
		if(d == dev_ctrl)
			printf("0x%08x\n", p.monitor.status);
		else {
			printf("0x%08x\n", p.monitor.status);
			fprintf(stderr, "(error_code=%d)\n", p.error_code);
			fprintf(stderr, "(reset_counter=%d)\n", p.reset_counter);
		}
	}
	return 0;
}
