/************************< BEGIN COPYRIGHT >************************
 * 
 *  Copyright (c) 2005-2008 Freescale Semiconductor All Rights Reserved. 
 * 
 *   NOTICE: The information contained in this file is proprietary 
 *   to Freescale Semiconductor and is being made available to 
 *   Freescale's customers under a specific license agreement. 
 *   Use or disclosure of this information is permissible only 
 *   under the terms of the license agreement. 
 * 
 ************************< END COPYRIGHT >***************************/
#include "util.h"

static int usage(int verbose, int retval)
{
	fprintf(stderr, "%swriteback <id> <cpi|nci|fpi> <0|1>\n",
		retval ? USAGE_ERROR : USAGE_CLEAR);
	if(verbose)
		fprintf(stderr, "%s    sets or unsets writeback for cpi, nci, "
				"or fpi on channel <id>\n", USAGE_CLEAR);
	return retval;
}

int writeback(int argc, char *argv[])
{
	int fd;
	unsigned int id, onoff;
	enum {
		wb_cpi,
		wb_nci,
		wb_fpi
	} wbtype;
	char channel_str[256];

	if(argc < 0) return usage(1, 0);
	if(argc != 4) return usage(0, -1);
	if(parse_uint(argv[1], &id, "<id>"))
		return usage(0, -1);
	if(!strcmp(argv[2], "cpi"))
		wbtype = wb_cpi;
	else if(!strcmp(argv[2], "nci"))
		wbtype = wb_nci;
	else if(!strcmp(argv[2], "fpi"))
		wbtype = wb_fpi;
	else {
		fprintf(stderr, "ERROR, use 'cpi', 'nci', or 'fpi' (%s)\n",
				argv[2]);
		return usage(0, -1);
	}
	if(parse_uint(argv[3], &onoff, "<onoff>"))
		return usage(0, -1);
	snprintf(channel_str, sizeof(channel_str), PME_CHANNEL_PATH, id);
	if((fd = open(channel_str, O_RDONLY)) < 0) {
		perror("Couldn't open channel device");
		return usage(0, -1);
	}
	if(ioctl(fd, (wbtype == wb_cpi) ? PME_CHANNEL_IOCTL_CPI_BLOCK :
			(wbtype == wb_nci) ? PME_CHANNEL_IOCTL_NCI_BLOCK :
				PME_CHANNEL_IOCTL_FPI_BLOCK, &onoff)) {
		perror("Writeback setting failed");
		return usage(0, -1);
	}
	return 0;
}
