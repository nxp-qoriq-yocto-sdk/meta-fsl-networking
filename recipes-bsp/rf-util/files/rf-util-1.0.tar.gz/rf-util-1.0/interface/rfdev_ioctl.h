/*
 * RF device framework
 *
 * Author: pankaj chauhan <pankaj.chauhan@freescale.com>
 *
 * Copyright 2011 Freescale Semiconductor, Inc.
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#ifndef __RFDEV_IOCTL_H__
#define __RFDEV_IOCTL_H__

#include <linux/ioctl.h>
#include <linux/kernel.h>
#include <linux/types.h>

#define RIF_NAME_SIZE	20
#define RF_MAX_DEVS	6

enum rf_phy_band {
	LTE_BAND1,
	LTE_BAND13
};

enum rf_network_mode {
	LTE_TDD,
	LTE_FDD,
	NET_MODE_END
};

enum rf_txrxmode {
	TXRX_1T1R,
	TXRX_1T2R,
	TXRX_2T2R,
	TXRX_MODE_END
};

enum rf_band_width {
	BW_05_MHZ,
	BW_10_MHZ,
	BW_15_MHZ,
	BW_20_MHZ,
	BW_END
};
enum rf_state {
	RF_CREATED,
	RF_PHY_ATTACHED,
	RF_INITIALIZED,
	RF_TIMER_SYNC_AWAITED,
	RF_TIMER_SYNC_FAILED,
	RF_STOPPED,
	RF_READY,
	RF_DOWN,
	RF_STATE_END
};

struct rf_init_params {
	enum rf_network_mode mode;
	enum rf_txrxmode tx_rxmode;
	enum rf_band_width bw;
	enum rf_phy_band fq_band;
	unsigned int long_cp;
	unsigned int ants;
};

struct rf_dev_info {
	char controller[RIF_NAME_SIZE];
	char phy[RIF_NAME_SIZE];
	enum rf_state state;
	enum rf_network_mode net_mode;
	enum rf_txrxmode tx_rxmode;
	enum rf_band_width bw;
	unsigned int ants;
	unsigned int symbol_len;
	unsigned int long_cp;
	unsigned int cp0_len;
	unsigned int cp1_len;

};

struct rif_phy_cmd {
	__u32	cmd;
	__u32	param1;
	__u32	param2;
	__u32	param3;
};

struct rif_phy_cmd_set {
	struct rif_phy_cmd *cmds;
	unsigned int count;
};

struct rif_reg_buf {
	__u32 addr;
	void *buf;
	unsigned int count;
};

struct rif_write_reg_buf {
	__u32 addr;
	__u32 data;
};


enum rf_timer_src {
	RF_PPS_SRC_GPS,
	RF_PPS_SRC_RAW_GPS,
	RF_PPS_SRC_PTP,
	RF_PPS_SRC_NLM
};


#define RF_MAGIC 'R'
#define RIF_DEV_INIT		_IOWR(RF_MAGIC, 1, struct rf_init_params*)
#define RIF_SET_TIMER_SOURCE	_IOW(RF_MAGIC, 2, unsigned int)
#define RIF_GET_STATE		_IOR(RF_MAGIC, 3, unsigned int)
#define RIF_SET_TIMER_CORRECTION _IOW(RF_MAGIC, 4, unsigned int)
#define	RIF_RUN_PHY_CMDS	_IOW(RF_MAGIC, 5, struct rif_phy_cmd_set *)
#define RIF_READ_RSSI		_IOR(RF_MAGIC, 6, __u32)
#define RIF_READ_PHY_REGS	_IOR(RF_MAGIC, 7, struct rif_reg_buf *)
#define RIF_READ_CTRL_REGS	_IOR(RF_MAGIC, 8, struct rif_reg_buf *)
#define RIF_START		_IO(RF_MAGIC, 9)
#define RIF_STOP		_IO(RF_MAGIC, 10)
#define RIF_GET_DEV_INFO	_IOWR(RF_MAGIC, 11, struct rf_dev_info *)
#define RIF_WRITE_PHY_REGS _IOR(RF_MAGIC, 12, struct rif_write_reg_buf *)


#endif
