#ifndef __RF_IF_H__
#define __RF_IF_H__
/*
 * rf_if.h
 * Author: pankaj chauhan <pankaj.chauhan@freescale.com>
 *
 * Copyright 2011 Freescale Semiconductor, Inc.
 *
 */

#include <sys/types.h>
#include <stdint.h>
#include "rfdev_ioctl.h"

#define DEV_NAME_SIZE	30

typedef int rf_handle_t;

rf_handle_t rfdev_open(const char *if_name);
int	rfdev_get_fd(rf_handle_t rf_handle);
int	rfdev_close(rf_handle_t rf_handle);
int 	rfdev_start(rf_handle_t rf_handle);
int	rfdev_init(rf_handle_t rf_handle,
		struct rf_init_params *init_params);
int	rfdev_set_timer_source(rf_handle_t handle,
		enum rf_timer_src src);
int	rfdev_get_devinfo(rf_handle_t rf_handle,
		struct rf_dev_info *dev_info);
int	rfdev_run_phy_cmds(rf_handle_t rf_handle,
		char *phy_config_file);
int	rfdev_set_timer_correction(rf_handle_t handle,
		uint32_t val);
int	rfdev_get_ctrl_regs(rf_handle_t handle, struct rif_reg_buf *reg_buf);
int	rfdev_get_phy_regs(rf_handle_t handle, struct rif_reg_buf *reg_buf);
#endif
