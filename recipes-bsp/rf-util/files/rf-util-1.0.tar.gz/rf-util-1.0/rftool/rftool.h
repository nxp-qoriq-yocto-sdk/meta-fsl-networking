#ifndef __RIFTOOL_H__
#define __RIFTOOL_H__
/*
 * riftool.h
 * Author: pankaj chauhan <pankaj.chauhan@freescale.com>
 *
 * Copyright 2011 Freescale Semiconductor, Inc.
 *
 */

#define MAX_STRING_LEN	30
#define FILE_NAME_LEN	100
#define TTI_LOG_COUNT	100
#define VERSION	"v0.1"
#include "rf_if.h"

enum riftool_cmd {
	INIT_LTE_5_MHZ,
	INIT_LTE_10_MHZ,
	INIT_LTE_15_MHZ,
	INIT_LTE_20_MHZ,
	TEST_DL_TTI,
	DUMP_CNTRL_REGS,
	DUMP_PHY_REGS,
	DUMP_DEVINFO,
	DUMP_DEVINFO_ALL,
	WRITE_CNTRL_REGS,
	WRITE_PHY_REGS,
	RUN_PHY_SCRIPT,
	START_RF_DEV,
	PRINT_HELP,
};

struct rfdev {
	char *if_name;
	rf_handle_t if_handle;
};

struct rfdev_params {
	enum rf_txrxmode txrx_mode;
	enum rf_phy_band fq_band;
	int long_cp;
};

/*Mode strings*/
#define MODE_1T1R		"1T1R"
#define MODE_1T2R		"1T2R"
#define MODE_2T2R		"2T2R"
/*FREQUENCY BAND strings*/
#define LTE_FREQ_BAND1         "LTE_BAND1"
#define LTE_FREQ_BAND13        "LTE_BAND13"
/*cmd strings*/
#define CMD_INIT_LTE_5		"init_lte_5mhz"
#define CMD_INIT_LTE_10		"init_lte_10mhz"
#define CMD_INIT_LTE_15		"init_lte_15mhz"
#define CMD_INIT_LTE_20		"init_lte_20mhz"
#define CMD_DL_TTI_TEST		"dl_tti_test"
#endif
