/*
 * rftool.c
 * RF device configuration utility
 *
 * Radio interface device framework of kernel exposes the combination of a
 * RF interface controller and RFIC as a RF device (eg. rf0, rf1) to user
 * space for configuration. This interface is for RF PHYs for LTE/CDMA systems.
 *
 * This utility provides command line interface to:
 * 1. get information about RF deivce
 * 2. configure RF device.
 *
 * Author: pankaj chauhan <pankaj.chauhan@freescale.com>
 *
 * Copyright 2011 Freescale Semiconductor, Inc.
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include "log.h"
#include "rftool.h"
#include "rfdev_ioctl.h"
#include "rf_if.h"

int send_ioctl(struct rfdev *dev, int cmd, void *arg);
static int show_dev(struct rfdev *dev);

char *net_mode_strings[NET_MODE_END] = {
	"LTE TDD",
	"LTE FDD"
};

char *ant_txrxmode_strings[TXRX_MODE_END] = {
	"1T1R",
	"1T2R",
	"2T2R"
};

char *bandwidth_strings[BW_END] = {
	"5 Mhz",
	"10 Mhz",
	"15 Mhz",
	"20 Mhz"
};
char *state_strings[RF_STATE_END] = {
	"Created",
	"PHY attached",
	"Initialized",
	"Awaiting Timing sync",
	"Timing sync done",
	"Stopped",
	"Ready",
	"Down"
};

int dump_phy_regs(struct rfdev *dev, unsigned int start,
	unsigned int count)
{
	struct rif_reg_buf reg_buf;
	int rc = 0 , size;
	__u32 *buf = NULL;
	int i;

	/* Each register is 4 bytes wide*/
	size = 4 * count;
	buf = malloc(size);
	if (!buf) {
		DBG_ERR("%s: Failed to allocate mem for reg buf\n", dev->if_name);
		return ENOMEM;
	}

	memset(buf, 0, size);
	reg_buf.addr = start;
	reg_buf.buf = buf;
	reg_buf.count = count;
	rc = rfdev_get_phy_regs(dev->if_handle, &reg_buf);
	if (rc) {
		DBG_ERR("Failed to get PHY register dump for %s, err %d",
			dev->if_name, errno);
		goto out;
	}

	printf("PHY registers:");
	for (i = 0; i < count; i++) {
		if (!(i % 8))
			printf("\n0x%.2x: ", i);
		printf("%.2x ", buf[i]);
	}
	printf("\n");

out:
	if (buf)
		free(buf);
	return rc;
}

int dump_controller_regs(struct rfdev *dev, unsigned long start_addr, int count)
{
	struct rif_reg_buf reg_buf;
	int rc, size;
	__u32 *buf = NULL;
	int i;

	/* Each register is 4 bytes wide*/
	size = 4 * count;
	buf = malloc(size);
	if (!buf) {
		DBG_ERR("%s: Failed to allocate mem for reg buf\n", dev->if_name);
		return ENOMEM;
	}

	memset(buf, 0, size);
	reg_buf.addr = start_addr;
	reg_buf.buf = buf;
	reg_buf.count = count;
	rc = rfdev_get_ctrl_regs(dev->if_handle, &reg_buf);
	if (rc) {
		DBG_ERR("Failed to get controller register dump for %s",
			dev->if_name);
		goto out;
	}

	printf("AIC registers:\n");
	for (i = 0; i < 128; i++) {
		if (!(i % 8))
			printf("\n0x%.3x: ", (i * 4));
		printf("%.8x ", buf[i]);
	}
	printf("\n");

out:
	if (buf)
		free(buf);
	return rc;
}

int write_phy_reg(struct rfdev *dev, __u32 reg_addr, __u32 reg_val)
{
	struct rif_write_reg_buf reg_buf;
	int rc = 0;

	reg_buf.addr = reg_addr;
	reg_buf.data = reg_val;
	/* This function is using send_ioctl directly
	 * as write interface is not exported through rflib
	 */
	rc = send_ioctl(dev, RIF_WRITE_PHY_REGS, &reg_buf);
	if (rc) {
		DBG_ERR("Failed to write into phy register for %s",
			dev->if_name);
		goto out;
	}

	printf("\nWritten into Register %x value %x.\n", reg_addr, reg_val);
	printf("\n");

out:
	return rc;
}

int write_ctrl_reg(struct rfdev *dev, unsigned long write_reg_addr,
	unsigned long val_reg)
{
	return ENOSYS;
}

int show_all_devs(void)
{
	return 0;
}

int send_ioctl(struct rfdev *dev, int cmd, void *arg)
{
	int fd, rc = 0;

	fd = rfdev_get_fd(dev->if_handle);
	if (arg)
		rc = ioctl(fd, cmd, arg);
	else
		rc = ioctl(fd, cmd);

	if (rc) {
		DBG_ERR("[%s] Failed ioctl %x, err %d\n", dev->if_name, cmd, errno);
		return rc;
	}

	return rc;
}

static int show_dev(struct rfdev *dev)
{
	int rc = 0;
	struct rf_dev_info dev_info;
	char *str;

	rc = rfdev_get_devinfo(dev->if_handle, &dev_info);
	if (rc)
		return rc;

	str = state_strings[dev_info.state];
	printf("%s	state: %s\n", dev_info.controller, str);

	if (dev_info.state >= RF_PHY_ATTACHED)
		printf("	rfphy: %s\n", dev_info.phy);
	else
		printf("	rfphy: Not attached\n");

	if (dev_info.state < RF_INITIALIZED)
		return rc;

	str = net_mode_strings[dev_info.net_mode];
	printf("	%s, ", str);
	str = bandwidth_strings[dev_info.bw];
	printf("%s\n", str);
	str = ant_txrxmode_strings[dev_info.tx_rxmode];
	printf("	Antennas: %d, %s\n", dev_info.ants, str);
	if (dev_info.long_cp)
		str = "Long";
	else
		str = "Short";

	printf("	CP: %s, len: cp0 %d, cp1 %d\n", str,
		dev_info.cp0_len, dev_info.cp1_len);
	printf("	Symbol len: %d\n", dev_info.symbol_len);

	return rc;


}

int start_rf_dev(struct rfdev *dev)
{
	int rc;

	rc = rfdev_start(dev->if_handle);
	if (rc)
		DBG_ERR("%s: Failed start\n", dev->if_name);

	return rc;
}

int init_lte_params(struct rfdev *dev, enum riftool_cmd cmd,
	struct rfdev_params *dev_params)
{
	struct rf_init_params params;
	int rc  = 0;
	enum rf_timer_src time_src;

	time_src = RF_PPS_SRC_RAW_GPS;
	rc = rfdev_set_timer_source(dev->if_handle, time_src);
	if (rc) {
		DBG_ERR("%s: Failed to set time src %d\n", dev->if_name, time_src);
		goto out;
	}

	params.mode = LTE_FDD;
	params.ants = 2;
	params.tx_rxmode = dev_params->txrx_mode;
	params.long_cp = dev_params->long_cp;
	params.fq_band = dev_params->fq_band;

	switch (cmd) {
	case INIT_LTE_5_MHZ:
		params.bw = BW_05_MHZ;
		break;
	case INIT_LTE_10_MHZ:
		params.bw = BW_10_MHZ;
		break;
	case INIT_LTE_15_MHZ:
		params.bw = BW_15_MHZ;
		break;
	case INIT_LTE_20_MHZ:
		params.bw = BW_20_MHZ;
		break;
	default:
		DBG_ERR("Unspported LTE mode %d\n", cmd);
		rc = EINVAL;
		goto out;
	}

	rc = rfdev_init(dev->if_handle, &params);
	if (rc)
		DBG_ERR("%s: Failed init paramters\n", dev->if_name);

out:
	return rc;
}

int get_int_val(int argc, char *argv[], char *opt_str)
{
	int val = 0;
	char opt;

	opt = getopt(argc, argv, opt_str);

	if (opt == 's')
		sscanf(optarg, "%d", &val);
	else if (opt == 'v')
		sscanf(optarg, "%x", &val);

	return val;
}

int test_dl_tti(struct rfdev *dev)
{
	struct timeval tv[TTI_LOG_COUNT];
	unsigned int tti_count[TTI_LOG_COUNT], i = 0;
	int fd;

	fd = rfdev_get_fd(dev->if_handle);
	memset(&tv[0], 0, sizeof(tv));
	memset(&tti_count[0], 0, sizeof(tti_count));

	while (i < TTI_LOG_COUNT) {
		read(fd, &tti_count[i], sizeof(unsigned int));
		gettimeofday(&tv[i], NULL);
		i++;
	}

	for (i = 0; i < TTI_LOG_COUNT; i++) {
		printf("[%d] tti 0x%0x, time %d:%d\n", i, tti_count[i],
			(int) tv[i].tv_sec, (int) tv[i].tv_usec);
	}

	return 0;
}

enum riftool_cmd get_cmd(char *cmd_string)
{
	if (!strncasecmp(cmd_string, CMD_INIT_LTE_5, MAX_STRING_LEN))
		return INIT_LTE_5_MHZ;

	if (!strncasecmp(cmd_string, CMD_INIT_LTE_10, MAX_STRING_LEN))
		return INIT_LTE_10_MHZ;

	if (!strncasecmp(cmd_string, CMD_INIT_LTE_15, MAX_STRING_LEN))
		return INIT_LTE_15_MHZ;

	if (!strncasecmp(cmd_string, CMD_INIT_LTE_20, MAX_STRING_LEN))
		return INIT_LTE_20_MHZ;

	if (!strncasecmp(cmd_string, CMD_DL_TTI_TEST, MAX_STRING_LEN))
		return TEST_DL_TTI;

	return -1;
}

void show_usage()
{
	printf("\nriftool version %s\n", VERSION);
	printf("riftool -i rf_interface_name -<optional commands>\n");
	printf("commands:\n");
	printf("-D -s <dump_size> 	: Dumps RF controller registers\n");
	printf("-d -s <dump_size> 	: Dumps RF phy registers\n");
	printf("-W start_addr -v <val>	: write RF controller register\n");
	printf("-w start_addr -v <val>	: write RF PHY register\n");
	printf("-r <rf_sctip_name>	: Run RF PHY init script\n");
	printf("-S 			: Start RF dev\n");
	printf("-l <long_cp>		: 0 - short cp, 1 long cp\n");
	printf("-b <freq_band>\n");
	printf("         : set LTE frequency band.\n");
	printf("freq_band:\n");
	printf("          : %s\n", LTE_FREQ_BAND1);
	printf("          : %s\n", LTE_FREQ_BAND13);
	printf("-m <mode_string>	: set tx/rx mode\n");
	printf("mode_string:\n");
	printf("	  : %s\n", MODE_1T1R);
	printf("	  : %s\n", MODE_1T2R);
	printf("	  : %s\n", MODE_2T2R);
	printf("-c <cmd_string>		: Run command\n");
	printf("cmd_string:\n");
	printf("	  : %s\n", CMD_INIT_LTE_5);
	printf("	  : %s\n", CMD_INIT_LTE_10);
	printf("	  : %s\n", CMD_INIT_LTE_15);
	printf("	  : %s\n", CMD_INIT_LTE_20);
	printf("	  : %s\n", CMD_DL_TTI_TEST);
}

int main(int argc, char *argv[])
{
	int opt, rc = 0, args = 0;
	char if_name[DEV_NAME_SIZE];
	__u32 write_reg_addr, val_reg;
	struct rfdev_params dev_params;
	struct rfdev dev;
	char phy_script[FILE_NAME_LEN];
	char cmd_string[MAX_STRING_LEN];
	char opt_string[MAX_STRING_LEN] = "d:b:D:s:v:w:W:r:i:c:m:l:hS";
	enum riftool_cmd cmd = -1;
	int count, long_cp;
	__u32 start_addr;

	memset(&if_name[0], 0, DEV_NAME_SIZE);
	memset(&cmd_string[0], 0, MAX_STRING_LEN);
	memset(&phy_script[0], 0, FILE_NAME_LEN);
	memset(&dev, 0, sizeof(struct rfdev));

	/*Default is short cp, and 1T1R*/
	dev_params.txrx_mode = TXRX_1T1R;
	dev_params.long_cp = 0;
	dev_params.fq_band = LTE_BAND1;

	while ((opt = getopt(argc, argv, &opt_string[0])) != -1) {

		switch (opt) {
		case 'c':
			strncpy(&cmd_string[0], optarg, DEV_NAME_SIZE);
			cmd = get_cmd(cmd_string);
			args++;
			break;
		case 'm':
			if (!strncasecmp(optarg, MODE_1T1R, MAX_STRING_LEN))
				dev_params.txrx_mode = TXRX_1T1R;
			else if (!strncasecmp(optarg, MODE_1T2R, MAX_STRING_LEN))
				dev_params.txrx_mode = TXRX_1T2R;
			else if (!strncasecmp(optarg, MODE_2T2R, MAX_STRING_LEN))
				dev_params.txrx_mode = TXRX_2T2R;
			break;
		case 'l':
			sscanf(optarg, "%d", &long_cp);
			break;
		case 'b':
			if (!strcasecmp(optarg, LTE_FREQ_BAND1))
				dev_params.fq_band = LTE_BAND1;
			else if (!strcasecmp(optarg, LTE_FREQ_BAND13))
				dev_params.fq_band = LTE_BAND13;
			args++;
			break;
		case 'd':
			cmd = DUMP_PHY_REGS;
			sscanf(optarg, "%x", &start_addr);
			count = get_int_val(argc, argv, &opt_string[0]);
			args++;
			break;
		case 'D':
			cmd = DUMP_CNTRL_REGS;
			sscanf(optarg, "%x", &start_addr);
			count = get_int_val(argc, argv, &opt_string[0]);
			args++;
			break;
		case 'i':
			cmd = DUMP_DEVINFO;
			strncpy(&if_name[0], optarg, DEV_NAME_SIZE);
			args++;
			break;
		case 'S':
			cmd = START_RF_DEV;
			args++;
			break;
		case 'r':
			cmd = RUN_PHY_SCRIPT;
			strncpy(&phy_script[0], optarg, FILE_NAME_LEN);
			args++;
			break;
		case 'W':
			cmd = WRITE_CNTRL_REGS;
			break;
		case 'w':
			cmd = WRITE_PHY_REGS;
			sscanf(optarg, "%x", &write_reg_addr);
			val_reg = get_int_val(argc, argv, &opt_string[0]);
			args++;
			break;

		case 'h':
			show_usage();
			rc = 0;
			goto out;
		default:
			show_usage();
			rc = EINVAL;
			goto out;
		}
	}

	if (!args)
		rc = show_all_devs();

	if (!if_name[0]) {
		DBG_ERR("No Interface name!\n");
		return EINVAL;
	}

	dev.if_handle = rfdev_open(if_name);
	if (dev.if_handle < 0) {
		DBG_ERR("Failed to open rfdev %s\n", if_name);
		goto out;
	}
	dev.if_name = if_name;
	switch (cmd) {

	case DUMP_DEVINFO:
		rc = show_dev(&dev);
		break;
	case INIT_LTE_5_MHZ:
	case INIT_LTE_10_MHZ:
	case INIT_LTE_15_MHZ:
	case INIT_LTE_20_MHZ:

		if (long_cp == 1 || long_cp == 0)
			dev_params.long_cp = long_cp;
		else
			DBG_INFO("Invalid long cp %d, using default %d\n",
				long_cp, dev_params.long_cp);

		rc = init_lte_params(&dev, cmd, &dev_params);
		break;
	case START_RF_DEV:
		rc = start_rf_dev(&dev);
		break;
	case DUMP_CNTRL_REGS:
	case DUMP_PHY_REGS:
		if (!count) {
			DBG_ERR("No size argument, use '-s <reg_count>'");
			return EINVAL;
		}
		if (cmd == DUMP_CNTRL_REGS)
			rc = dump_controller_regs(&dev, start_addr, count);
		else if (cmd == DUMP_PHY_REGS)
			rc = dump_phy_regs(&dev, start_addr, count);
		break;

	case WRITE_CNTRL_REGS:
		DBG_ERR("Write controller regs not implemented\n");
		break;
	case WRITE_PHY_REGS:
		write_phy_reg(&dev, write_reg_addr, val_reg);
		break;

	case RUN_PHY_SCRIPT:
		if (!phy_script[0]) {
			DBG_ERR("No phy script name!\n");
			return EINVAL;
		}
		rc = rfdev_run_phy_cmds(dev.if_handle, phy_script);
		args++;
		break;
	case TEST_DL_TTI:
		rc = test_dl_tti(&dev);
		break;
	default:
		show_usage();
		break;
	}

out:
	if (dev.if_handle)
		rfdev_close(dev.if_handle);
	return rc;
}
