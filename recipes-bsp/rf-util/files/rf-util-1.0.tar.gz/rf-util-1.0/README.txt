1.0 PA (power arch) Instructions

1.1 COMPILATION

1.1.1 Compiling AIC in linux kernel
   - config options:

   	CONFIG_RFDEVICES=y
	CONFIG_RFDEV_CORE=y
	CONFIG_FSL_AIC=y
	CONFIG_ADI9361=y

     These options can be selected in menuconfig by selecting "RF driver support", 
     which appears towards end of drivers submenu
     
   - Compilation steps for Linux kernel
    # export CROSS_COMPILE=powerpc-linux-gnu- (this assumes you have path of this cross compiler in your $PATH)
    # export ARCH=powerpc
    # make uImage

    Linux image will be created at <linux kernel path>/arch/powerpc/boot/uImage

1.1.2. Compiling DTB file 

   #scripts/dtc/dtc -I dts -O dtb -R 8 -S0x3000 arch/powerpc/boot/dts/psc9131rdb.dts > psc9131rdb.dtb

1.1.3. Compiling rftool

   # make all
   # make install

   'rftool' binary is created in bin directory.

1.2 RUNTIME CONFIGURATION

1.2.1 Commands On u-boot prompt:

   $ run debug_halt_off

1.2.2 Commands in Linux:

   # rftool -i rf2 -r <config file, *.txt mentioned in #3 above>
   # rftool -i rf2 -c init_lte_10mhz {run this command twice}

   Last step is configuration for Lte 10mhz high band (2.14Ghz)

   Run rftool -h to check commands for other modes.

2.0 SDOS (DSP) Instructions

	- Load DSP binary for aic test (aic_test_9x31_dbg.bin) from Linux to
	  DSP core using dsp_boot (refer to dsp_boot README for details of
	  dsp_boot).
	- Store the test model data file in the path D:\AIC_Test\DL.
	- Open Code Warrior and close the welcome window.
	- Open the Test App project.
	- Go to Project and click on Build Project.
	- Load the generated .bin through Linux.
	- Go to Run and click Debug Configurations...
	- In the Debug Configurations dialog box, click on CodeWarrior Attach and 
	  press new button for creating a new configuration.
	- Change the name of the configuration as follows-
	- Project: set to aic_test_app project
    	- Application: give eld path (AIC Basic Demo 9x31 - Debug\aic_test_9x31_dbg.eld)
        - Build configuration: set build configuration (AIC Basic Demo 9x31 - Debug)
	- Create a new connection by clicking on new button in the Remote System section.
	- In the New Connection dialog box select USB connection as the new connection and press Next.
	- In the System section select PSC9131 SC RDB System as the new system and click on Next.
	- Uncheck Execute reset in the Initialization tab and click finish.
	- Click on debug on the Debug Configurations.

3.0 Board/Jumper settings

   - Make sure Jumper J13 is shorted before using RF interface, Otherwise
     rftool commands will hang.
   - For LTE connect RF card on RF interface 1 on PSC9131RDB board


