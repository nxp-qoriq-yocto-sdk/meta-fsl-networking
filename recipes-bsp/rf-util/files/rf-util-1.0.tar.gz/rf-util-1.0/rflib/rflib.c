/*
 * riflib.c
 * RF device configuration library
 *
 * Radio interface device framework of kernel exposes the combination of a
 * RF interface controller and RFIC as a RF device (eg. rf0, rf1) to user
 * space for configuration. This interface is for RF PHYs for LTE/CDMA systems.
 *
 * This library provides command line interface to:
 * 1. get information about RF deivce
 * 2. configure RF device.
 *
 * Author: pankaj chauhan <pankaj.chauhan@freescale.com>
 *
 * Copyright 2011 Freescale Semiconductor, Inc.
 *
 */

#include <sys/ioctl.h>
#include <sys/types.h>
#include <stdint.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include "rf_if.h"

extern int run_phy_script(int fd, char *script_file);

rf_handle_t rfdev_open(const char *if_name)
{
	char dev_name[DEV_NAME_SIZE] = "/dev/";

	if (!if_name)
		return -EINVAL;

	strncat(&dev_name[0], if_name, DEV_NAME_SIZE);

	return open(dev_name, O_RDWR);
}

int rfdev_get_fd(rf_handle_t rf_handle)
{
	/*This function looks idiotic currently,
	 *but idea is, rf_handle_t may be changed
	 *to structure if required, then this func
	 * will make sense.
	 */
	return (int) rf_handle;
}

int rfdev_close(rf_handle_t rf_handle)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);
	return close(fd);
}


int rfdev_init(rf_handle_t rf_handle,
	struct rf_init_params *init_params)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);

	return ioctl(fd, RIF_DEV_INIT, init_params);
}

int rfdev_set_timer_source(rf_handle_t rf_handle,

	enum rf_timer_src src)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);

	return ioctl(fd, RIF_SET_TIMER_SOURCE, &src);
}

int rfdev_start(rf_handle_t rf_handle)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);

	return ioctl(fd, RIF_START, NULL);
}

int rfdev_get_devinfo(rf_handle_t rf_handle,
	struct rf_dev_info *dev_info)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);

	return ioctl(fd, RIF_GET_DEV_INFO, dev_info);
}

int rfdev_set_timer_correction(rf_handle_t rf_handle, uint32_t val)
{
	/*Not yet implemented*/
	return ENOSYS;
}

int rfdev_run_phy_cmds(rf_handle_t rf_handle, char *phy_config_file)
{
	int fd, rc;

	fd = rfdev_get_fd(rf_handle);
	rc = run_phy_script(fd, phy_config_file);

	return rc;
}

int rfdev_get_phy_regs(rf_handle_t rf_handle,
	struct rif_reg_buf *reg_buf)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);
	return ioctl(fd, RIF_READ_PHY_REGS, reg_buf);
}

int rfdev_get_ctrl_regs(rf_handle_t rf_handle,
	struct rif_reg_buf *reg_buf)
{
	int fd;

	fd = rfdev_get_fd(rf_handle);
	return ioctl(fd, RIF_READ_CTRL_REGS, reg_buf);
}
