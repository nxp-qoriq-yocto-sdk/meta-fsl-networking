/*
 * adi_parser.c
 *
 * Parser for AD phy configuration script
 *
 * Author: Shaveta Leekha <shaveta@freescale.com>
 *
 * Copyright 2011 Freescale Semiconductor, Inc.
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include "log.h"
#include "rfdev_ioctl.h"

#define SPI_WRITE 1
#define SPI_READ 2
#define SPI_WAIT 3
#define SPI_WAIT_CALDONE 4
#define SPI_WAIT_CALDONE_BBPLL 5

#define MAX_LINE_SIZE 110
#define READ_LINE_SIZE 100
#define COMPARE_CHARS 5
#define NUM_CMDS_ALLOC	100


void print_structure(struct rif_phy_cmd *cmds, unsigned int num_cmds)
{
	int i;

	for (i = 0; i < num_cmds; i++) {
		printf("opcode read is:%d\n", cmds[i].cmd);
		printf("param1 is:%x\n", cmds[i].param1);
		printf("param2 is:%x\n", cmds[i].param2);
		printf("param3 is:%x\n", cmds[i].param3);
	}
}

int run_phy_script(int fd, char *script_file)
{
	char line[MAX_LINE_SIZE];
	char temp[10];
	char *line_ptr;
	unsigned int i = 0;
	int rc = 0;
	FILE *config_fp;
	struct rif_phy_cmd *ad_data;
	struct rif_phy_cmd_set phy_info;

	config_fp = fopen(script_file, "r");
	if (config_fp == NULL) {
		fprintf(stderr, "fopen() failed for file: %s Error: %s\n",
				script_file, strerror(errno));
		return errno;
	}

	ad_data = (struct rif_phy_cmd *)malloc(NUM_CMDS_ALLOC *
				sizeof(struct rif_phy_cmd));
	if (!ad_data) {
		DBG_ERR("Failed to allocate memory for phy commands.\n");
		fclose(config_fp);
		return -ENOMEM;
	}

	while (fgets(line, READ_LINE_SIZE, config_fp) != NULL) {
		if (!(i % NUM_CMDS_ALLOC) && i) {
#ifdef DEBUG
			print_structure(ad_data, i);
#endif
			phy_info.cmds = ad_data;
			phy_info.count = i;

			rc = ioctl(fd, RIF_RUN_PHY_CMDS, &phy_info);
			if (rc) {
				fclose(config_fp);
				free(ad_data);
				return rc;
			}
			i = 0;
		}
		line_ptr = line;

		if (!(strncmp(line, "SPIWr", COMPARE_CHARS))) {
			ad_data[i].cmd = SPI_WRITE;
			strncpy(temp, (strtok(line_ptr, "\t")), sizeof(temp));
			strncpy(temp, (strtok(NULL, ",")), sizeof(temp));
			ad_data[i].param1 = strtoul(temp, NULL, 16);
			strncpy(temp, (strtok(NULL, " ")), sizeof(temp));
			ad_data[i].param2 = strtoul(temp, NULL, 16);
			ad_data[i].param3 = 0;
			i++;
		} else if (!(strncmp(line, "SPIRe", COMPARE_CHARS))) {
			ad_data[i].cmd = SPI_READ;
			strncpy(temp, (strtok(line_ptr, "\t")), sizeof(temp));
			strncpy(temp, (strtok(NULL, "\t")), sizeof(temp));
			ad_data[i].param1 = strtoul(temp, NULL, 16);
			ad_data[i].param2 = 0;
			ad_data[i].param3 = 0;
			i++;
		} else if (!(strncmp(line, "WAIT ", COMPARE_CHARS))) {
			ad_data[i].cmd = SPI_WAIT;
			strncpy(temp, (strtok(line_ptr, "\t")), sizeof(temp));
			strncpy(temp, (strtok(NULL, "\t")), sizeof(temp));
			ad_data[i].param3 = strtoul(temp, NULL, 10);
			ad_data[i].param1 = 0;
			ad_data[i].param2 = 0;
			i++;
		} else if (!(strncmp(line, "WAIT_", COMPARE_CHARS))) {
			strncpy(temp, (strtok(line_ptr, "\t")), sizeof(temp));
			strncpy(temp, (strtok(NULL, ",")), sizeof(temp));
			if (strcmp(temp, "BBPLL"))
				ad_data[i].cmd = SPI_WAIT_CALDONE;
			else
				ad_data[i].cmd = SPI_WAIT_CALDONE_BBPLL;

			strncpy(temp, (strtok(NULL, "\t")), sizeof(temp));
			ad_data[i].param3 = strtoul(temp, NULL, 10);
			ad_data[i].param1 = 0;
			ad_data[i].param2 = 0;
			i++;
		}
	}

	fclose(config_fp);

#ifdef DEBUG
	print_structure(ad_data, i);
#endif

	phy_info.cmds = ad_data;
	phy_info.count = i;

	rc = ioctl(fd, RIF_RUN_PHY_CMDS, &phy_info);
	if (rc) {
		free(ad_data);
		return rc;
	}

	free(ad_data);

	return 0;
}
